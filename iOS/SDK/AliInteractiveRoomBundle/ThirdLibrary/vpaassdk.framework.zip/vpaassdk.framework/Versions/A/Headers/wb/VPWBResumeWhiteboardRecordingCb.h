// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 恢复白板录制回调
 */
@protocol VPWBResumeWhiteboardRecordingCb

- (void)onSuccess:(nonnull VPWBResumeWhiteboardRecordingRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */