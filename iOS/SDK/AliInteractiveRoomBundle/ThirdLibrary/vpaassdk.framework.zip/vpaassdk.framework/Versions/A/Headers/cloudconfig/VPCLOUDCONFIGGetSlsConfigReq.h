// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取Sls配置请求
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetSlsConfigReq : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCLOUDCONFIGGetSlsConfigReq;

@end
/* optimized_djinni_generated_objc_file */