// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBCreateWhiteboardReq.h>
#import <vpaassdk/wb/VPWBCreateWhiteboardRsp.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardDocReq.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardDocRsp.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardPageReq.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardPageRsp.h>
#import <vpaassdk/wb/VPWBGetWhiteboardPageInfoReq.h>
#import <vpaassdk/wb/VPWBGetWhiteboardPageInfoRsp.h>
#import <vpaassdk/wb/VPWBOpenWhiteboardReq.h>
#import <vpaassdk/wb/VPWBOpenWhiteboardRsp.h>
#import <vpaassdk/wb/VPWBPauseWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBPauseWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateReq.h>
#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateRsp.h>
#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBStartWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBStartWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBStopWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBStopWhiteboardRecordingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPWBCreateWhiteboardCb;
@protocol VPWBDeleteWhiteboardDocCb;
@protocol VPWBDeleteWhiteboardPageCb;
@protocol VPWBGetWhiteboardPageInfoCb;
@protocol VPWBOpenWhiteboardCb;
@protocol VPWBPauseWhiteboardRecordingCb;
@protocol VPWBReportWhiteboardPageOperateCb;
@protocol VPWBResumeWhiteboardRecordingCb;
@protocol VPWBStartWhiteboardRecordingCb;
@protocol VPWBStopWhiteboardRecordingCb;


@interface VPWBWbRpcInterface : NSObject

/**
 * @brief 创建白板
 */
- (void)createWhiteboard:(nonnull VPWBCreateWhiteboardReq *)req
                callback:(nullable id<VPWBCreateWhiteboardCb>)callback;

- (void)createWhiteboardWithBlock:(nonnull VPWBCreateWhiteboardReq *) req
                        onSuccess:(nullable void(^)(VPWBCreateWhiteboardRsp * _Nonnull rsp))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 打开白板
 */
- (void)openWhiteboard:(nonnull VPWBOpenWhiteboardReq *)req
              callback:(nullable id<VPWBOpenWhiteboardCb>)callback;

- (void)openWhiteboardWithBlock:(nonnull VPWBOpenWhiteboardReq *) req
                      onSuccess:(nullable void(^)(VPWBOpenWhiteboardRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 白板页码上报
 */
- (void)reportWhiteboardPageOperate:(nonnull VPWBReportWhiteboardPageOperateReq *)req
                           callback:(nullable id<VPWBReportWhiteboardPageOperateCb>)callback;

- (void)reportWhiteboardPageOperateWithBlock:(nonnull VPWBReportWhiteboardPageOperateReq *) req
                                   onSuccess:(nullable void(^)(VPWBReportWhiteboardPageOperateRsp * _Nonnull rsp))onSuccess
                                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 白板页码映射查询
 */
- (void)getWhiteboardPageInfo:(nonnull VPWBGetWhiteboardPageInfoReq *)req
                     callback:(nullable id<VPWBGetWhiteboardPageInfoCb>)callback;

- (void)getWhiteboardPageInfoWithBlock:(nonnull VPWBGetWhiteboardPageInfoReq *) req
                             onSuccess:(nullable void(^)(VPWBGetWhiteboardPageInfoRsp * _Nonnull rsp))onSuccess
                             onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 删除白板单页
 */
- (void)deleteWhiteboardPage:(nonnull VPWBDeleteWhiteboardPageReq *)req
                    callback:(nullable id<VPWBDeleteWhiteboardPageCb>)callback;

- (void)deleteWhiteboardPageWithBlock:(nonnull VPWBDeleteWhiteboardPageReq *) req
                            onSuccess:(nullable void(^)(VPWBDeleteWhiteboardPageRsp * _Nonnull rsp))onSuccess
                            onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 删除白板文档
 */
- (void)deleteWhiteboardDoc:(nonnull VPWBDeleteWhiteboardDocReq *)req
                   callback:(nullable id<VPWBDeleteWhiteboardDocCb>)callback;

- (void)deleteWhiteboardDocWithBlock:(nonnull VPWBDeleteWhiteboardDocReq *) req
                           onSuccess:(nullable void(^)(VPWBDeleteWhiteboardDocRsp * _Nonnull rsp))onSuccess
                           onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开始白板录制
 */
- (void)startWhiteboardRecording:(nonnull VPWBStartWhiteboardRecordingReq *)req
                        callback:(nullable id<VPWBStartWhiteboardRecordingCb>)callback;

- (void)startWhiteboardRecordingWithBlock:(nonnull VPWBStartWhiteboardRecordingReq *) req
                                onSuccess:(nullable void(^)(VPWBStartWhiteboardRecordingRsp * _Nonnull rsp))onSuccess
                                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 结束白板录制
 */
- (void)stopWhiteboardRecording:(nonnull VPWBStopWhiteboardRecordingReq *)req
                       callback:(nullable id<VPWBStopWhiteboardRecordingCb>)callback;

- (void)stopWhiteboardRecordingWithBlock:(nonnull VPWBStopWhiteboardRecordingReq *) req
                               onSuccess:(nullable void(^)(VPWBStopWhiteboardRecordingRsp * _Nonnull rsp))onSuccess
                               onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 暂停白板录制
 */
- (void)pauseWhiteboardRecording:(nonnull VPWBPauseWhiteboardRecordingReq *)req
                        callback:(nullable id<VPWBPauseWhiteboardRecordingCb>)callback;

- (void)pauseWhiteboardRecordingWithBlock:(nonnull VPWBPauseWhiteboardRecordingReq *) req
                                onSuccess:(nullable void(^)(VPWBPauseWhiteboardRecordingRsp * _Nonnull rsp))onSuccess
                                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 恢复白板录制
 */
- (void)resumeWhiteboardRecording:(nonnull VPWBResumeWhiteboardRecordingReq *)req
                         callback:(nullable id<VPWBResumeWhiteboardRecordingCb>)callback;

- (void)resumeWhiteboardRecordingWithBlock:(nonnull VPWBResumeWhiteboardRecordingReq *) req
                                 onSuccess:(nullable void(^)(VPWBResumeWhiteboardRecordingRsp * _Nonnull rsp))onSuccess
                                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */