// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发送弹幕请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendCommentReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                                content:(nonnull NSString *)content
                              extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPCHATSendCommentReqWithTopicId:(nonnull NSString *)topicId
                                                content:(nonnull NSString *)content
                                              extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param topic_id 话题id,聊天插件实例id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param content 发送内容
 */
@property (nonatomic, nonnull) NSString * content;

/**
 * @param extension 业务拓展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */