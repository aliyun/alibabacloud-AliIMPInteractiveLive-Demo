// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATBanCommentUser.h>
#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取禁言的用户列表响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATListBanCommentUsersRsp : NSObject
- (nonnull instancetype)initWithMuteUserModelList:(nonnull NSArray<VPCHATBanCommentUser *> *)muteUserModelList;
+ (nonnull instancetype)VPCHATListBanCommentUsersRspWithMuteUserModelList:(nonnull NSArray<VPCHATBanCommentUser *> *)muteUserModelList;

/**
 * @param mute_user_model_list 禁言用户列表
 */
@property (nonatomic, nonnull) NSArray<VPCHATBanCommentUser *> * muteUserModelList;

@end
/* optimized_djinni_generated_objc_file */