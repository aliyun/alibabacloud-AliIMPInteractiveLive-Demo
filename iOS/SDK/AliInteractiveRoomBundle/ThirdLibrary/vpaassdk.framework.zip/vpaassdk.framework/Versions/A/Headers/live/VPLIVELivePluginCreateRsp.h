// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建结束后直播插件后的返回值model
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVELivePluginCreateRsp : NSObject
- (nonnull instancetype)initWithAnchorId:(nonnull NSString *)anchorId
                                    uuid:(nonnull NSString *)uuid
                                   title:(nonnull NSString *)title
                                 playUrl:(nonnull NSString *)playUrl
                              createDate:(int64_t)createDate
                                 endDate:(int64_t)endDate
                            preStartDate:(int64_t)preStartDate
                              preEndDate:(int64_t)preEndDate
                                duration:(int64_t)duration
                                 pushUrl:(nonnull NSString *)pushUrl
                                 liveUrl:(nonnull NSString *)liveUrl
                                  status:(int32_t)status
                            introduction:(nonnull NSString *)introduction
                           enableLinkMic:(BOOL)enableLinkMic;
+ (nonnull instancetype)VPLIVELivePluginCreateRspWithAnchorId:(nonnull NSString *)anchorId
                                                         uuid:(nonnull NSString *)uuid
                                                        title:(nonnull NSString *)title
                                                      playUrl:(nonnull NSString *)playUrl
                                                   createDate:(int64_t)createDate
                                                      endDate:(int64_t)endDate
                                                 preStartDate:(int64_t)preStartDate
                                                   preEndDate:(int64_t)preEndDate
                                                     duration:(int64_t)duration
                                                      pushUrl:(nonnull NSString *)pushUrl
                                                      liveUrl:(nonnull NSString *)liveUrl
                                                       status:(int32_t)status
                                                 introduction:(nonnull NSString *)introduction
                                                enableLinkMic:(BOOL)enableLinkMic;

/**
 * @param anchor_id 主播ID
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param uuid 直播uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param title 主题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param play_url 播放url
 */
@property (nonatomic, nonnull) NSString * playUrl;

/**
 * @param create_date 创建日期，utc时间
 */
@property (nonatomic) int64_t createDate;

/**
 * @param end_date 结束日期，utc时间
 */
@property (nonatomic) int64_t endDate;

/**
 * @param pre_start_date 预计开始日期，utc时间
 */
@property (nonatomic) int64_t preStartDate;

/**
 * @param pre_end_date 预计结束日期，utc时间
 */
@property (nonatomic) int64_t preEndDate;

/**
 * @param duration 视频时长
 */
@property (nonatomic) int64_t duration;

/**
 * @param push_url 推流url
 */
@property (nonatomic, nonnull) NSString * pushUrl;

/**
 * @param live_url 拉流url
 */
@property (nonatomic, nonnull) NSString * liveUrl;

/**
 * @param status 直播状态0：未开始1：直播中2：直播结束
 */
@property (nonatomic) int32_t status;

/**
 * @param introduction 直播简介
 */
@property (nonatomic, nonnull) NSString * introduction;

/**
 * @param enable_link_mic 是否开启连麦
 */
@property (nonatomic) BOOL enableLinkMic;

@end
/* optimized_djinni_generated_objc_file */