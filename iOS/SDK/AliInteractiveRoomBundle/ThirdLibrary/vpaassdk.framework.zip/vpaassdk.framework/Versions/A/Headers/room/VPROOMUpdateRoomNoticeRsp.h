// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新房间公告响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMUpdateRoomNoticeRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPROOMUpdateRoomNoticeRsp;

@end
/* optimized_djinni_generated_objc_file */