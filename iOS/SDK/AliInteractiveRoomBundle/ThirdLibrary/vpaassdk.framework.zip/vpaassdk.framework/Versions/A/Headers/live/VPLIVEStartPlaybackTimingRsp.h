// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播回放观看开始上报响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEStartPlaybackTimingRsp : NSObject
- (nonnull instancetype)initWithSuccess:(BOOL)success
                                transId:(nonnull NSString *)transId;
+ (nonnull instancetype)VPLIVEStartPlaybackTimingRspWithSuccess:(BOOL)success
                                                        transId:(nonnull NSString *)transId;

/**
 * @param success 上报成功
 */
@property (nonatomic) BOOL success;

/**
 * @param trans_id 观看直播回放标识
 */
@property (nonatomic, nonnull) NSString * transId;

@end
/* optimized_djinni_generated_objc_file */