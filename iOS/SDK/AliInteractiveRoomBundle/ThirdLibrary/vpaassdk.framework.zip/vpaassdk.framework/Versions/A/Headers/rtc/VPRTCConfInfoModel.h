// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 会议核心模型
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCConfInfoModel : NSObject
- (nonnull instancetype)initWithTenantId:(nonnull NSString *)tenantId
                                   appId:(nonnull NSString *)appId
                                  roomId:(nonnull NSString *)roomId
                                  confId:(nonnull NSString *)confId
                                userList:(nonnull NSArray<VPRTCConfUserModel *> *)userList
                                   title:(nonnull NSString *)title
                                  status:(int32_t)status
                            preStartTime:(int64_t)preStartTime
                              preEndTime:(int64_t)preEndTime
                               startTime:(int64_t)startTime
                                 endTime:(int64_t)endTime
                                duration:(int64_t)duration
                                  source:(int32_t)source
                                sourceId:(nonnull NSString *)sourceId
                               extension:(nonnull NSString *)extension
                                anchorId:(nonnull NSString *)anchorId
                          anchorNickname:(nonnull NSString *)anchorNickname
                             playbackUrl:(nonnull NSString *)playbackUrl
                                 muteAll:(BOOL)muteAll;
+ (nonnull instancetype)VPRTCConfInfoModelWithTenantId:(nonnull NSString *)tenantId
                                                 appId:(nonnull NSString *)appId
                                                roomId:(nonnull NSString *)roomId
                                                confId:(nonnull NSString *)confId
                                              userList:(nonnull NSArray<VPRTCConfUserModel *> *)userList
                                                 title:(nonnull NSString *)title
                                                status:(int32_t)status
                                          preStartTime:(int64_t)preStartTime
                                            preEndTime:(int64_t)preEndTime
                                             startTime:(int64_t)startTime
                                               endTime:(int64_t)endTime
                                              duration:(int64_t)duration
                                                source:(int32_t)source
                                              sourceId:(nonnull NSString *)sourceId
                                             extension:(nonnull NSString *)extension
                                              anchorId:(nonnull NSString *)anchorId
                                        anchorNickname:(nonnull NSString *)anchorNickname
                                           playbackUrl:(nonnull NSString *)playbackUrl
                                               muteAll:(BOOL)muteAll;

/**
 * @param tenant_id 租户ID
 */
@property (nonatomic, nonnull) NSString * tenantId;

/**
 * @param app_id 应用ID
 */
@property (nonatomic, nonnull) NSString * appId;

/**
 * @param room_id 房间ID
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_list 用户列表
 */
@property (nonatomic, nonnull) NSArray<VPRTCConfUserModel *> * userList;

/**
 * @param title 会议主题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param status 会议状态0:未开始1:进行中2:已结束
 */
@property (nonatomic) int32_t status;

/**
 * @param pre_start_time 会议预计开始时间
 */
@property (nonatomic) int64_t preStartTime;

/**
 * @param pre_end_time 会议预计结束时间
 */
@property (nonatomic) int64_t preEndTime;

/**
 * @param start_time 会议真实开始时间
 */
@property (nonatomic) int64_t startTime;

/**
 * @param end_time 会议真实结束时间
 */
@property (nonatomic) int64_t endTime;

/**
 * @param duration 会议时长(秒)
 */
@property (nonatomic) int64_t duration;

/**
 * @param source 媒体引擎0:alirtc1:mcs
 */
@property (nonatomic) int32_t source;

/**
 * @param source_id 媒体引擎对应ID
 */
@property (nonatomic, nonnull) NSString * sourceId;

/**
 * @param extension 扩展信息
 */
@property (nonatomic, nonnull) NSString * extension;

/**
 * @param anchor_id 主播ID
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param anchor_nickname 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNickname;

/**
 * @param playback_url 回放URL
 */
@property (nonatomic, nonnull) NSString * playbackUrl;

/**
 * @param mute_all 全员禁音true:全员禁音false非全员禁音
 */
@property (nonatomic) BOOL muteAll;

@end
/* optimized_djinni_generated_objc_file */