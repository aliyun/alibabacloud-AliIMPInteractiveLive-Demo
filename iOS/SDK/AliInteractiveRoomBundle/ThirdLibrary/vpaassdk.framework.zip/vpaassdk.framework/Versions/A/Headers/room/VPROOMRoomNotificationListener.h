// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMRoomNotificationModel.h>
#import <Foundation/Foundation.h>


@protocol VPROOMRoomNotificationListener

- (void)onRoomMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onChatMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onLiveMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onRtcMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onClassSceneMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onDocMessage:(nonnull VPROOMRoomNotificationModel *)msg;

- (void)onWbMessage:(nonnull VPROOMRoomNotificationModel *)msg;

@end
/* optimized_djinni_generated_objc_file */