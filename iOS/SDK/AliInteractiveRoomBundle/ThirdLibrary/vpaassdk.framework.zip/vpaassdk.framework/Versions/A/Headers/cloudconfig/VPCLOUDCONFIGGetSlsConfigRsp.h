// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGSlsConfig.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGStsToken.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取Sls配置响应
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetSlsConfigRsp : NSObject
- (nonnull instancetype)initWithSlsConfig:(nonnull VPCLOUDCONFIGSlsConfig *)slsConfig
                                 stsToken:(nonnull VPCLOUDCONFIGStsToken *)stsToken
                        heartbeatInterval:(int32_t)heartbeatInterval
                               reportMode:(nonnull NSString *)reportMode;
+ (nonnull instancetype)VPCLOUDCONFIGGetSlsConfigRspWithSlsConfig:(nonnull VPCLOUDCONFIGSlsConfig *)slsConfig
                                                         stsToken:(nonnull VPCLOUDCONFIGStsToken *)stsToken
                                                heartbeatInterval:(int32_t)heartbeatInterval
                                                       reportMode:(nonnull NSString *)reportMode;

/**
 * @param sls_config sls配置
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGSlsConfig * slsConfig;

/**
 * @param sts_token stsToken
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGStsToken * stsToken;

/**
 * @param heartbeat_interval 心跳间隔，单位：秒
 */
@property (nonatomic) int32_t heartbeatInterval;

/**
 * @param report_mode 默认取值:sls_sdk
 */
@property (nonatomic, nonnull) NSString * reportMode;

@end
/* optimized_djinni_generated_objc_file */