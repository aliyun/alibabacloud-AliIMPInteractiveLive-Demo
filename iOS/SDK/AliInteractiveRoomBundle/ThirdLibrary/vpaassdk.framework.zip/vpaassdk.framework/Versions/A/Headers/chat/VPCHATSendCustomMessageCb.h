// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATSendCustomMessageRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 发送普通自定义消息回调
 */
@protocol VPCHATSendCustomMessageCb

- (void)onSuccess:(nonnull VPCHATSendCustomMessageRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */