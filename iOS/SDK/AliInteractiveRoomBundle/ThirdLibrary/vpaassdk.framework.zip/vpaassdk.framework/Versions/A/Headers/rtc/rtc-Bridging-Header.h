// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// rtc_Bridging_Header.h
// rtc_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for rtcBridgingHeader.
FOUNDATION_EXPORT double rtcBridgingHeaderVersionNumber;

//! Project version string for rtcBridgingHeader.
FOUNDATION_EXPORT const unsigned char rtcBridgingHeaderVersionString[];

#import <vpaassdk/rtc/VPRTCRtcModule.h>
#import <vpaassdk/rtc/VPRTCRtcExtInterface.h>
#import <vpaassdk/rtc/VPRTCGetTokenCb.h>
#import <vpaassdk/rtc/VPRTCReportJoinStatusCb.h>
#import <vpaassdk/rtc/VPRTCReportLeaveStatusCb.h>
#import <vpaassdk/rtc/VPRTCPushLiveStreamCb.h>
#import <vpaassdk/rtc/VPRTCStopLiveStreamCb.h>
#import <vpaassdk/rtc/VPRTCSetLayoutCb.h>
#import <vpaassdk/rtc/VPRTCSetCustomLayoutCb.h>
#import <vpaassdk/rtc/VPRTCAddMembersCb.h>
#import <vpaassdk/rtc/VPRTCKickMembersCb.h>
#import <vpaassdk/rtc/VPRTCGetConfDetailCb.h>
#import <vpaassdk/rtc/VPRTCApplyLinkMicCb.h>
#import <vpaassdk/rtc/VPRTCApproveLinkMicCb.h>
#import <vpaassdk/rtc/VPRTCListConfUserCb.h>
#import <vpaassdk/rtc/VPRTCListApplyLinkMicUserCb.h>
#import <vpaassdk/rtc/VPRTCStartRecordCb.h>
#import <vpaassdk/rtc/VPRTCStopRecordCb.h>
#import <vpaassdk/rtc/VPRTCReportRtcMuteCb.h>
#import <vpaassdk/rtc/VPRTCRtcMuteAllCb.h>
#import <vpaassdk/rtc/VPRTCOperateCameraCb.h>
#import <vpaassdk/rtc/VPRTCShareScreenCb.h>
#import <vpaassdk/rtc/VPRTCRtcMuteUserCb.h>
#import <vpaassdk/rtc/VPRTCCheckAllowJoinCb.h>
#import <vpaassdk/rtc/VPRTCRtcRpcInterface.h>
#import <vpaassdk/rtc/VPRTCUserStatusChangeMessage.h>
#import <vpaassdk/rtc/VPRTCConfStatusChangeMessage.h>
#import <vpaassdk/rtc/VPRTCInviteMessage.h>
#import <vpaassdk/rtc/VPRTCCommandMessage.h>
#import <vpaassdk/rtc/VPRTCStopRingingMessage.h>
#import <vpaassdk/rtc/VPRTCMuteMessage.h>
#import <vpaassdk/rtc/VPRTCCameraMessage.h>
#import <vpaassdk/rtc/VPRTCShareScreenMessage.h>
#import <vpaassdk/rtc/VPRTCPositiveMuteMicMessage.h>
#import <vpaassdk/rtc/VPRTCPassiveMuteMicMessage.h>
#import <vpaassdk/rtc/VPRTCMuteAllMicMessage.h>
#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCConfInfoModel.h>
#import <vpaassdk/rtc/VPRTCGetTokenReq.h>
#import <vpaassdk/rtc/VPRTCGetTokenRsp.h>
#import <vpaassdk/rtc/VPRTCReportJoinStatusReq.h>
#import <vpaassdk/rtc/VPRTCReportJoinStatusRsp.h>
#import <vpaassdk/rtc/VPRTCReportLeaveStatusReq.h>
#import <vpaassdk/rtc/VPRTCReportLeaveStatusRsp.h>
#import <vpaassdk/rtc/VPRTCPushLiveStreamReq.h>
#import <vpaassdk/rtc/VPRTCPushLiveStreamRsp.h>
#import <vpaassdk/rtc/VPRTCStopLiveStreamReq.h>
#import <vpaassdk/rtc/VPRTCStopLiveStreamRsp.h>
#import <vpaassdk/rtc/VPRTCSetLayoutReq.h>
#import <vpaassdk/rtc/VPRTCSetLayoutRsp.h>
#import <vpaassdk/rtc/VPRTCPane.h>
#import <vpaassdk/rtc/VPRTCSetCustomLayoutReq.h>
#import <vpaassdk/rtc/VPRTCSetCustomLayoutRsp.h>
#import <vpaassdk/rtc/VPRTCAddMembersReq.h>
#import <vpaassdk/rtc/VPRTCAddMembersRsp.h>
#import <vpaassdk/rtc/VPRTCKickMembersReq.h>
#import <vpaassdk/rtc/VPRTCKickMembersRsp.h>
#import <vpaassdk/rtc/VPRTCGetConfDetailReq.h>
#import <vpaassdk/rtc/VPRTCGetConfDetailRsp.h>
#import <vpaassdk/rtc/VPRTCApplyLinkMicReq.h>
#import <vpaassdk/rtc/VPRTCApplyLinkMicRsp.h>
#import <vpaassdk/rtc/VPRTCApproveLinkMicReq.h>
#import <vpaassdk/rtc/VPRTCApproveLinkMicRsp.h>
#import <vpaassdk/rtc/VPRTCListConfUserReq.h>
#import <vpaassdk/rtc/VPRTCListConfUserRsp.h>
#import <vpaassdk/rtc/VPRTCListApplyLinkMicUserReq.h>
#import <vpaassdk/rtc/VPRTCListApplyLinkMicUserRsp.h>
#import <vpaassdk/rtc/VPRTCStartRecordReq.h>
#import <vpaassdk/rtc/VPRTCStartRecordRsp.h>
#import <vpaassdk/rtc/VPRTCStopRecordReq.h>
#import <vpaassdk/rtc/VPRTCStopRecordRsp.h>
#import <vpaassdk/rtc/VPRTCReportRtcMuteReq.h>
#import <vpaassdk/rtc/VPRTCReportRtcMuteRsp.h>
#import <vpaassdk/rtc/VPRTCRtcMuteAllReq.h>
#import <vpaassdk/rtc/VPRTCRtcMuteAllRsp.h>
#import <vpaassdk/rtc/VPRTCOperateCameraReq.h>
#import <vpaassdk/rtc/VPRTCOperateCameraRsp.h>
#import <vpaassdk/rtc/VPRTCShareScreenReq.h>
#import <vpaassdk/rtc/VPRTCShareScreenRsp.h>
#import <vpaassdk/rtc/VPRTCRtcMuteUserReq.h>
#import <vpaassdk/rtc/VPRTCRtcMuteUserRsp.h>
#import <vpaassdk/rtc/VPRTCCheckAllowJoinReq.h>
#import <vpaassdk/rtc/VPRTCCheckAllowJoinRsp.h>
/* optimized_djinni_generated_objc_file */