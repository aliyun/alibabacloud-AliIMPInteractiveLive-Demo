// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubStsTokenModel : NSObject
- (nonnull instancetype)initWithAccessKeyId:(nonnull NSString *)accessKeyId
                            accessKeySecret:(nonnull NSString *)accessKeySecret
                              securityToken:(nonnull NSString *)securityToken
                                expireTimeS:(int32_t)expireTimeS;
+ (nonnull instancetype)VPMonitorhubStsTokenModelWithAccessKeyId:(nonnull NSString *)accessKeyId
                                                 accessKeySecret:(nonnull NSString *)accessKeySecret
                                                   securityToken:(nonnull NSString *)securityToken
                                                     expireTimeS:(int32_t)expireTimeS;

@property (nonatomic, nonnull) NSString * accessKeyId;

@property (nonatomic, nonnull) NSString * accessKeySecret;

@property (nonatomic, nonnull) NSString * securityToken;

/**
 *token 过期时间，单位：秒
 */
@property (nonatomic) int32_t expireTimeS;

@end
/* optimized_djinni_generated_objc_file */