// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetAppConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetAppConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetCloudConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetCloudConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPCLOUDCONFIGGetAppConfigCb;
@protocol VPCLOUDCONFIGGetCloudConfigCb;
@protocol VPCLOUDCONFIGGetSlsConfigCb;
@protocol VPCLOUDCONFIGGetVisibleConfigCb;


@interface VPCLOUDCONFIGCloudconfigRpcInterface : NSObject

/**
 * @brief 获取直播云控配置
 */
- (void)getCloudConfig:(nonnull VPCLOUDCONFIGGetCloudConfigReq *)req
              callback:(nullable id<VPCLOUDCONFIGGetCloudConfigCb>)callback;

- (void)getCloudConfigWithBlock:(nonnull VPCLOUDCONFIGGetCloudConfigReq *) req
                      onSuccess:(nullable void(^)(VPCLOUDCONFIGGetCloudConfigRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取租户配置
 */
- (void)getAppConfig:(nonnull VPCLOUDCONFIGGetAppConfigReq *)req
            callback:(nullable id<VPCLOUDCONFIGGetAppConfigCb>)callback;

- (void)getAppConfigWithBlock:(nonnull VPCLOUDCONFIGGetAppConfigReq *) req
                    onSuccess:(nullable void(^)(VPCLOUDCONFIGGetAppConfigRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取sls配置
 */
- (void)getSlsConfig:(nonnull VPCLOUDCONFIGGetSlsConfigReq *)req
            callback:(nullable id<VPCLOUDCONFIGGetSlsConfigCb>)callback;

- (void)getSlsConfigWithBlock:(nonnull VPCLOUDCONFIGGetSlsConfigReq *) req
                    onSuccess:(nullable void(^)(VPCLOUDCONFIGGetSlsConfigRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取租户可视化配置
 */
- (void)getVisibleConfig:(nonnull VPCLOUDCONFIGGetVisibleConfigReq *)req
                callback:(nullable id<VPCLOUDCONFIGGetVisibleConfigCb>)callback;

- (void)getVisibleConfigWithBlock:(nonnull VPCLOUDCONFIGGetVisibleConfigReq *) req
                        onSuccess:(nullable void(^)(VPCLOUDCONFIGGetVisibleConfigRsp * _Nonnull rsp))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */