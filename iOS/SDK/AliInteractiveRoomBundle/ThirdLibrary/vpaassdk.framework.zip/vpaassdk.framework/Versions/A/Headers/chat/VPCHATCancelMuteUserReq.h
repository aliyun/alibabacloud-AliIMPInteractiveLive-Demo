// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 取消禁言某位用户请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATCancelMuteUserReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                         cancelMuteUser:(nonnull NSString *)cancelMuteUser;
+ (nonnull instancetype)VPCHATCancelMuteUserReqWithTopicId:(nonnull NSString *)topicId
                                            cancelMuteUser:(nonnull NSString *)cancelMuteUser;

/**
 * @param topic_id 话题id,聊天插件实例id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param cancel_mute_user 被取消禁言的用户
 */
@property (nonatomic, nonnull) NSString * cancelMuteUser;

@end
/* optimized_djinni_generated_objc_file */