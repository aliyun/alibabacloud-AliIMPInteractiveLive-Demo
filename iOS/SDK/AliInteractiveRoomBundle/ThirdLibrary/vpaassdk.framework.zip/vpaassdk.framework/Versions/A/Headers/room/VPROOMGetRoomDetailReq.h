// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取房间详细信息请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomDetailReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId;
+ (nonnull instancetype)VPROOMGetRoomDetailReqWithRoomId:(nonnull NSString *)roomId;

/**
 * @param room_id 房间id,必传
 */
@property (nonatomic, nonnull) NSString * roomId;

@end
/* optimized_djinni_generated_objc_file */