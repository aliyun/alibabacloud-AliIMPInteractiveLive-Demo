// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板页码映射查询请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBGetWhiteboardPageInfoReq : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId
                               isGenerateUrl:(BOOL)isGenerateUrl;
+ (nonnull instancetype)VPWBGetWhiteboardPageInfoReqWithWhiteboardId:(nonnull NSString *)whiteboardId
                                                       isGenerateUrl:(BOOL)isGenerateUrl;

/**
 * @param whiteboard_id 白板文档标识（原dockey）
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

/**
 * @param is_generate_url 是否生成url地址
 */
@property (nonatomic) BOOL isGenerateUrl;

@end
/* optimized_djinni_generated_objc_file */