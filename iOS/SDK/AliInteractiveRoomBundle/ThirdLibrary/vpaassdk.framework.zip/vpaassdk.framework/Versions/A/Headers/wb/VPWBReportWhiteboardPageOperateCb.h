// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 白板页码上报回调
 */
@protocol VPWBReportWhiteboardPageOperateCb

- (void)onSuccess:(nonnull VPWBReportWhiteboardPageOperateRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */