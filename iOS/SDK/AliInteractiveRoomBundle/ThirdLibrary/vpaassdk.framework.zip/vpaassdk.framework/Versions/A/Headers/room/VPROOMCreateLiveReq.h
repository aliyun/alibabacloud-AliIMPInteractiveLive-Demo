// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateLiveReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                              anchorId:(nonnull NSString *)anchorId
                                 title:(nonnull NSString *)title
                          preStartDate:(int64_t)preStartDate
                            preEndDate:(int64_t)preEndDate
                          introduction:(nonnull NSString *)introduction
                              coverUrl:(nonnull NSString *)coverUrl
                       userDefineField:(nonnull NSString *)userDefineField;
+ (nonnull instancetype)VPROOMCreateLiveReqWithRoomId:(nonnull NSString *)roomId
                                             anchorId:(nonnull NSString *)anchorId
                                                title:(nonnull NSString *)title
                                         preStartDate:(int64_t)preStartDate
                                           preEndDate:(int64_t)preEndDate
                                         introduction:(nonnull NSString *)introduction
                                             coverUrl:(nonnull NSString *)coverUrl
                                      userDefineField:(nonnull NSString *)userDefineField;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * 主播ID
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * 主题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * 预计开始日期，utc时间
 */
@property (nonatomic) int64_t preStartDate;

/**
 * 预计结束日期，utc时间
 */
@property (nonatomic) int64_t preEndDate;

/**
 * 直播简介
 */
@property (nonatomic, nonnull) NSString * introduction;

/**
 * 封面链接
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * 用户自定义字段
 */
@property (nonatomic, nonnull) NSString * userDefineField;

@end
/* optimized_djinni_generated_objc_file */