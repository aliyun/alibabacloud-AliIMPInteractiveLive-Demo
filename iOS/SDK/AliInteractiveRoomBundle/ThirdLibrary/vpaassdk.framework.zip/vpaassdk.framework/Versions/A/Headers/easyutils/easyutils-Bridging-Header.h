// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// easyutils_Bridging_Header.h
// easyutils_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for easyutilsBridgingHeader.
FOUNDATION_EXPORT double easyutilsBridgingHeaderVersionNumber;

//! Project version string for easyutilsBridgingHeader.
FOUNDATION_EXPORT const unsigned char easyutilsBridgingHeaderVersionString[];

#import <vpaassdk/easyutils/VPEasyutilsEncryptDecryptDataResult.h>
#import <vpaassdk/easyutils/VPEasyutils.h>
/* optimized_djinni_generated_objc_file */