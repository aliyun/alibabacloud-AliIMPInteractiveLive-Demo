// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新直播请求
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEUpdateLiveReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
                               title:(nonnull NSString *)title
                        introduction:(nonnull NSString *)introduction
                            coverUrl:(nonnull NSString *)coverUrl
                     userDefineField:(nonnull NSString *)userDefineField;
+ (nonnull instancetype)VPLIVEUpdateLiveReqWithUuid:(nonnull NSString *)uuid
                                              title:(nonnull NSString *)title
                                       introduction:(nonnull NSString *)introduction
                                           coverUrl:(nonnull NSString *)coverUrl
                                    userDefineField:(nonnull NSString *)userDefineField;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param title 直播标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param introduction 直播简介
 */
@property (nonatomic, nonnull) NSString * introduction;

/**
 * @param cover_url 封面链接
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param user_define_field 用户自定义扩展字段
 */
@property (nonatomic, nonnull) NSString * userDefineField;

@end
/* optimized_djinni_generated_objc_file */