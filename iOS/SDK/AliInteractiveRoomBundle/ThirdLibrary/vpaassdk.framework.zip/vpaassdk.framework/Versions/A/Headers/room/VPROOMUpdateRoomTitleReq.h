// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新房间标题请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMUpdateRoomTitleReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                 title:(nonnull NSString *)title;
+ (nonnull instancetype)VPROOMUpdateRoomTitleReqWithRoomId:(nonnull NSString *)roomId
                                                     title:(nonnull NSString *)title;

/**
 * @param room_id 房间id,必传
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param title 房间标题
 */
@property (nonatomic, nonnull) NSString * title;

@end
/* optimized_djinni_generated_objc_file */