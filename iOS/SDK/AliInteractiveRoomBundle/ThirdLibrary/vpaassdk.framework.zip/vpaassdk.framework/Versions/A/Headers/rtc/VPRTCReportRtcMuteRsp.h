// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报单人禁音/取消禁音响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCReportRtcMuteRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCReportRtcMuteRsp;

@end
/* optimized_djinni_generated_objc_file */