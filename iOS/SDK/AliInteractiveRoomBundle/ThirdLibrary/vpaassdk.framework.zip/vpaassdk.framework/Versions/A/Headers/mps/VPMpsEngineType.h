// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * 日志级别
 */
typedef NS_ENUM(NSInteger, VPMpsEngineType)
{
    VPMpsEngineTypeMpsEngineTypeNone = 1,
    VPMpsEngineTypeMpsEngineTypeDps = 2,
    VPMpsEngineTypeMpsEngineTypeMeta = 3,
};
/* optimized_djinni_generated_objc_file */