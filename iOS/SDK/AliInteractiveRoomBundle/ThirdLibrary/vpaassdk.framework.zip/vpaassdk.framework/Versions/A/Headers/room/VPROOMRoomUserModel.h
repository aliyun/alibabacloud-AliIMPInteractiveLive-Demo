// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 房间用户信息
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMRoomUserModel : NSObject
- (nonnull instancetype)initWithUserId:(nonnull NSString *)userId
                                  nick:(nonnull NSString *)nick
                                  role:(nonnull NSString *)role
                             extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                openId:(nonnull NSString *)openId;
+ (nonnull instancetype)VPROOMRoomUserModelWithUserId:(nonnull NSString *)userId
                                                 nick:(nonnull NSString *)nick
                                                 role:(nonnull NSString *)role
                                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                               openId:(nonnull NSString *)openId;

/**
 * @param user_id 用户的id
 */
@property (nonatomic, nonnull) NSString * userId;

/**
 * @param nick 用户昵称
 */
@property (nonatomic, nonnull) NSString * nick;

/**
 * @param role 用户角色
 */
@property (nonatomic, nonnull) NSString * role;

/**
 * @param extension 用户的扩展信息
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param open_id 用户的openId
 */
@property (nonatomic, nonnull) NSString * openId;

@end
/* optimized_djinni_generated_objc_file */