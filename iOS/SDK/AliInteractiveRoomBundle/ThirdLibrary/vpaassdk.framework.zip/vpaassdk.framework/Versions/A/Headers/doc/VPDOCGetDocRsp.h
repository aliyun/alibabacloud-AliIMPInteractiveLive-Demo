// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取文档响应
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCGetDocRsp : NSObject
- (nonnull instancetype)initWithDocId:(nonnull NSString *)docId
                              docType:(nonnull NSString *)docType
                              docName:(nonnull NSString *)docName
                              urlList:(nonnull NSArray<NSString *> *)urlList
                               status:(int32_t)status
                          errorReason:(nonnull NSString *)errorReason;
+ (nonnull instancetype)VPDOCGetDocRspWithDocId:(nonnull NSString *)docId
                                        docType:(nonnull NSString *)docType
                                        docName:(nonnull NSString *)docName
                                        urlList:(nonnull NSArray<NSString *> *)urlList
                                         status:(int32_t)status
                                    errorReason:(nonnull NSString *)errorReason;

/**
 * @param doc_id 文档ID
 */
@property (nonatomic, nonnull) NSString * docId;

/**
 * @param doc_type 文档类型:ppt,pptx,pdf,png,jpg
 */
@property (nonatomic, nonnull) NSString * docType;

/**
 * @param doc_name 文档名称
 */
@property (nonatomic, nonnull) NSString * docName;

/**
 * @param url_list 文档URL列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * urlList;

/**
 * @param status 文档状态：0:文件Ready1:上传中2:转码中3:上传异常4:转码异常
 */
@property (nonatomic) int32_t status;

/**
 * @param error_reason 错误原因
 */
@property (nonatomic, nonnull) NSString * errorReason;

@end
/* optimized_djinni_generated_objc_file */