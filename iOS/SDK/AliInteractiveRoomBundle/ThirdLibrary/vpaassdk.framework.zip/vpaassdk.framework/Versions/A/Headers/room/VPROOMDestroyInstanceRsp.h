// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 销毁插件实例响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyInstanceRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPROOMDestroyInstanceRsp;

@end
/* optimized_djinni_generated_objc_file */