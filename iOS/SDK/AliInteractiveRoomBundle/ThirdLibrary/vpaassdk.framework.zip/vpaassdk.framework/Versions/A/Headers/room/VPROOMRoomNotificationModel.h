// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMRoomNotificationModel : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                             messageId:(nonnull NSString *)messageId
                                  type:(int32_t)type
                                  data:(nonnull NSString *)data;
+ (nonnull instancetype)VPROOMRoomNotificationModelWithRoomId:(nonnull NSString *)roomId
                                                    messageId:(nonnull NSString *)messageId
                                                         type:(int32_t)type
                                                         data:(nonnull NSString *)data;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * 消息ID
 */
@property (nonatomic, nonnull) NSString * messageId;

/**
 * 类型
 */
@property (nonatomic) int32_t type;

/**
 * 消息体
 */
@property (nonatomic, nonnull) NSString * data;

@end
/* optimized_djinni_generated_objc_file */