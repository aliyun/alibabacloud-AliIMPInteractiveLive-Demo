// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubStatusType : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubStatusType;

@end

extern NSString * __nonnull const VPMonitorhubStatusTypeNotStart;
extern NSString * __nonnull const VPMonitorhubStatusTypeRtcHost;
extern NSString * __nonnull const VPMonitorhubStatusTypeRtcParticipant;
extern NSString * __nonnull const VPMonitorhubStatusTypeLivePlay;
extern NSString * __nonnull const VPMonitorhubStatusTypeLivePush;
/* optimized_djinni_generated_objc_file */