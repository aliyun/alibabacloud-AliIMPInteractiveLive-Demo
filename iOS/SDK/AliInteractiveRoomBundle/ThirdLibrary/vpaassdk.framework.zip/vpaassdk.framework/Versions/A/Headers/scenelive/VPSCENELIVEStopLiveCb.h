// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVESceneStopLiveRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 关闭直播回调
 */
@protocol VPSCENELIVEStopLiveCb

- (void)onSuccess:(nonnull VPSCENELIVESceneStopLiveRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */