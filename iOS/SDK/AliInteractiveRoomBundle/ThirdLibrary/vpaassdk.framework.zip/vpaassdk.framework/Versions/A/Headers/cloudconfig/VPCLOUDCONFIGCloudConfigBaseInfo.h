// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGMobileSystemInfo.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGPcSystemInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 云控基本参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGCloudConfigBaseInfo : NSObject
- (nonnull instancetype)initWithPcSystemInfo:(nonnull VPCLOUDCONFIGPcSystemInfo *)pcSystemInfo
                            mobileSystemInfo:(nonnull VPCLOUDCONFIGMobileSystemInfo *)mobileSystemInfo;
+ (nonnull instancetype)VPCLOUDCONFIGCloudConfigBaseInfoWithPcSystemInfo:(nonnull VPCLOUDCONFIGPcSystemInfo *)pcSystemInfo
                                                        mobileSystemInfo:(nonnull VPCLOUDCONFIGMobileSystemInfo *)mobileSystemInfo;

/**
 * @param pc_system_info PC端参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGPcSystemInfo * pcSystemInfo;

/**
 * @param mobile_system_info 移动端参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGMobileSystemInfo * mobileSystemInfo;

@end
/* optimized_djinni_generated_objc_file */