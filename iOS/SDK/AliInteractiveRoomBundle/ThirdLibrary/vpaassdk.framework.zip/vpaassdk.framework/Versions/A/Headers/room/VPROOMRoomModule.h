// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPROOMRoomExtInterface;
@class VPROOMRoomModule;
@class VPROOMRoomRpcInterface;


VPROOM_OBJECTC_EXPORT
@interface VPROOMRoomModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPROOMRoomModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPROOMRoomRpcInterface *)getRpcInterface;

- (nullable VPROOMRoomExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */