// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMCreateInstanceRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 创建插件实例回调
 */
@protocol VPROOMCreateInstanceCb

- (void)onSuccess:(nonnull VPROOMCreateInstanceRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */