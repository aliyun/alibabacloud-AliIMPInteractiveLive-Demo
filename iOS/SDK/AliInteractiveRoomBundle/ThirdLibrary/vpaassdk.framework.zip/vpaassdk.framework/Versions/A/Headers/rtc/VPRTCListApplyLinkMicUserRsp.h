// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取申请连麦列表响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCListApplyLinkMicUserRsp : NSObject
- (nonnull instancetype)initWithUserList:(nonnull NSArray<VPRTCConfUserModel *> *)userList
                                 hasMore:(BOOL)hasMore
                              totalCount:(int32_t)totalCount;
+ (nonnull instancetype)VPRTCListApplyLinkMicUserRspWithUserList:(nonnull NSArray<VPRTCConfUserModel *> *)userList
                                                         hasMore:(BOOL)hasMore
                                                      totalCount:(int32_t)totalCount;

/**
 * @param user_list 申请连麦列表
 */
@property (nonatomic, nonnull) NSArray<VPRTCConfUserModel *> * userList;

/**
 * @param has_more 是否有下一页
 */
@property (nonatomic) BOOL hasMore;

/**
 * @param total_count 总人数
 */
@property (nonatomic) int32_t totalCount;

@end
/* optimized_djinni_generated_objc_file */