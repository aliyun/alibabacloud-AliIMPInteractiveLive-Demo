// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCPushLiveStreamRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 启动旁路推流回调
 */
@protocol VPRTCPushLiveStreamCb

- (void)onSuccess:(nonnull VPRTCPushLiveStreamRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */