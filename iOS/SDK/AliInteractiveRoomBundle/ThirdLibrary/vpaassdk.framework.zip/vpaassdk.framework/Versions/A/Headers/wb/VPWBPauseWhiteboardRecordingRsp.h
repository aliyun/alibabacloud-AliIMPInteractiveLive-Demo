// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 暂停白板录制响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBPauseWhiteboardRecordingRsp : NSObject
- (nonnull instancetype)initWithRequestId:(nonnull NSString *)requestId
                                pauseTime:(nonnull NSString *)pauseTime;
+ (nonnull instancetype)VPWBPauseWhiteboardRecordingRspWithRequestId:(nonnull NSString *)requestId
                                                           pauseTime:(nonnull NSString *)pauseTime;

/**
 * @param request_id 请求白板OpenAPI的请求ID（建议保留方便后续问题排查）
 */
@property (nonatomic, nonnull) NSString * requestId;

/**
 * @param pause_time 录制操作时间戳（UNIX毫秒格式）
 */
@property (nonatomic, nonnull) NSString * pauseTime;

@end
/* optimized_djinni_generated_objc_file */