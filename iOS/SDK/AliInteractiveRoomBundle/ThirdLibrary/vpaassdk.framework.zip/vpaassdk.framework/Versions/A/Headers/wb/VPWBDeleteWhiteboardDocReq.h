// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 删除白板文档请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBDeleteWhiteboardDocReq : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId
                                       docId:(nonnull NSString *)docId;
+ (nonnull instancetype)VPWBDeleteWhiteboardDocReqWithWhiteboardId:(nonnull NSString *)whiteboardId
                                                             docId:(nonnull NSString *)docId;

/**
 * @param whiteboard_id 白板Id
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

/**
 * @param doc_id 文档id
 */
@property (nonatomic, nonnull) NSString * docId;

@end
/* optimized_djinni_generated_objc_file */