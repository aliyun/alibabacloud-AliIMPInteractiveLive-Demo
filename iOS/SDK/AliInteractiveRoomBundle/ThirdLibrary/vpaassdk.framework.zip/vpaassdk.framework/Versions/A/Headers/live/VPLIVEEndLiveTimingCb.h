// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEEndLiveTimingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 结束观看直播计时回调
 */
@protocol VPLIVEEndLiveTimingCb

- (void)onSuccess:(nonnull VPLIVEEndLiveTimingRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */