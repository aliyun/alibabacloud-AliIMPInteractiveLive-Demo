// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板页码上报请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBReportWhiteboardPageOperateReq : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId
                                     operate:(nonnull NSString *)operate
                                   pageGroup:(nonnull NSString *)pageGroup
                                  pageNumber:(int32_t)pageNumber
                                    pageSize:(int32_t)pageSize
                                        type:(nonnull NSString *)type;
+ (nonnull instancetype)VPWBReportWhiteboardPageOperateReqWithWhiteboardId:(nonnull NSString *)whiteboardId
                                                                   operate:(nonnull NSString *)operate
                                                                 pageGroup:(nonnull NSString *)pageGroup
                                                                pageNumber:(int32_t)pageNumber
                                                                  pageSize:(int32_t)pageSize
                                                                      type:(nonnull NSString *)type;

/**
 * @param whiteboard_id 白板文档标识（原dockey）
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

/**
 * @param operate 操作类型（add未来可扩展del等）
 */
@property (nonatomic, nonnull) NSString * operate;

/**
 * @param page_group 添加的页所属组（自定义，建议白板页使用wb，文档页直接使用docid的值）
 */
@property (nonatomic, nonnull) NSString * pageGroup;

/**
 * @param page_number 进行操作的页码，如2
 */
@property (nonatomic) int32_t pageNumber;

/**
 * @param page_size 涉及页数，如4，默认为1
 */
@property (nonatomic) int32_t pageSize;

/**
 * @param type 插入资源类型，page对应白板新的页，img对应插入的页内资源
 */
@property (nonatomic, nonnull) NSString * type;

@end
/* optimized_djinni_generated_objc_file */