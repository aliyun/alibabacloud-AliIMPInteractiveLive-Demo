// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <vpaassdk/wb/VPWBWhiteboardAccessInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 打开白板响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBOpenWhiteboardRsp : NSObject
- (nonnull instancetype)initWithRequestId:(nonnull NSString *)requestId
                       documentAccessInfo:(nonnull VPWBWhiteboardAccessInfo *)documentAccessInfo;
+ (nonnull instancetype)VPWBOpenWhiteboardRspWithRequestId:(nonnull NSString *)requestId
                                        documentAccessInfo:(nonnull VPWBWhiteboardAccessInfo *)documentAccessInfo;

/**
 * @param request_id 请求白板OpenAPI的请求ID
 */
@property (nonatomic, nonnull) NSString * requestId;

/**
 * @param document_access_info 白板连接信息
 */
@property (nonatomic, nonnull) VPWBWhiteboardAccessInfo * documentAccessInfo;

@end
/* optimized_djinni_generated_objc_file */