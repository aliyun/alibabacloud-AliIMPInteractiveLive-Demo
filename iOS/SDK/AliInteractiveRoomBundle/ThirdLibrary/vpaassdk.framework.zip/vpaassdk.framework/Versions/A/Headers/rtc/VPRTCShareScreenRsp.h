// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 开启/结束共享桌面响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCShareScreenRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCShareScreenRsp;

@end
/* optimized_djinni_generated_objc_file */