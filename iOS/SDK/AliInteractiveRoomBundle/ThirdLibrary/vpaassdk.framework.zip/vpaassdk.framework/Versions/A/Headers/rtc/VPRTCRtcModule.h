// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPRTCRtcExtInterface;
@class VPRTCRtcModule;
@class VPRTCRtcRpcInterface;


VPRTC_OBJECTC_EXPORT
@interface VPRTCRtcModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPRTCRtcModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPRTCRtcRpcInterface *)getRpcInterface;

- (nullable VPRTCRtcExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */