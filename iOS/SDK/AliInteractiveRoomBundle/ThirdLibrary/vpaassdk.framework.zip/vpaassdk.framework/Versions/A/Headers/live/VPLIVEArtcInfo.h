// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief artc信息
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEArtcInfo : NSObject
- (nonnull instancetype)initWithArtcUrl:(nonnull NSString *)artcUrl
                              artcH5Url:(nonnull NSString *)artcH5Url;
+ (nonnull instancetype)VPLIVEArtcInfoWithArtcUrl:(nonnull NSString *)artcUrl
                                        artcH5Url:(nonnull NSString *)artcH5Url;

/**
 * @param artc_url 原画地址
 */
@property (nonatomic, nonnull) NSString * artcUrl;

/**
 * @param artc_h5_url h5转码地址
 */
@property (nonatomic, nonnull) NSString * artcH5Url;

@end
/* optimized_djinni_generated_objc_file */