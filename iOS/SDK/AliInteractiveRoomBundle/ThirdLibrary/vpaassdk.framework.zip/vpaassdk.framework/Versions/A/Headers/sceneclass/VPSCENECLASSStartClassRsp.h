// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>

VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSStartClassRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPSCENECLASSStartClassRsp;

@end
/* optimized_djinni_generated_objc_file */