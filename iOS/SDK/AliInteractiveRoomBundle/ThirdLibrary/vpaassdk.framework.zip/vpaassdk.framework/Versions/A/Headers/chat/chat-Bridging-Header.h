// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// chat_Bridging_Header.h
// chat_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for chatBridgingHeader.
FOUNDATION_EXPORT double chatBridgingHeaderVersionNumber;

//! Project version string for chatBridgingHeader.
FOUNDATION_EXPORT const unsigned char chatBridgingHeaderVersionString[];

#import <vpaassdk/chat/VPCHATChatModule.h>
#import <vpaassdk/chat/VPCHATChatExtInterface.h>
#import <vpaassdk/chat/VPCHATSendCommentCb.h>
#import <vpaassdk/chat/VPCHATSendLikeCb.h>
#import <vpaassdk/chat/VPCHATListCommentCb.h>
#import <vpaassdk/chat/VPCHATMuteAllCb.h>
#import <vpaassdk/chat/VPCHATCancelMuteAllCb.h>
#import <vpaassdk/chat/VPCHATMuteUserCb.h>
#import <vpaassdk/chat/VPCHATCancelMuteUserCb.h>
#import <vpaassdk/chat/VPCHATListBanCommentUsersCb.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageCb.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageCb.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersCb.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersCb.h>
#import <vpaassdk/chat/VPCHATGetTopicInfoCb.h>
#import <vpaassdk/chat/VPCHATChatRpcInterface.h>
#import <vpaassdk/chat/VPCHATSendCommentReq.h>
#import <vpaassdk/chat/VPCHATSendCommentRsp.h>
#import <vpaassdk/chat/VPCHATSendLikeReq.h>
#import <vpaassdk/chat/VPCHATSendLikeRsp.h>
#import <vpaassdk/chat/VPCHATListCommentReq.h>
#import <vpaassdk/chat/VPCHATListCommentRsp.h>
#import <vpaassdk/chat/VPCHATCommentModel.h>
#import <vpaassdk/chat/VPCHATMuteAllReq.h>
#import <vpaassdk/chat/VPCHATMuteAllRsp.h>
#import <vpaassdk/chat/VPCHATCancelMuteAllReq.h>
#import <vpaassdk/chat/VPCHATCancelMuteAllRsp.h>
#import <vpaassdk/chat/VPCHATMuteUserReq.h>
#import <vpaassdk/chat/VPCHATMuteUserRsp.h>
#import <vpaassdk/chat/VPCHATCancelMuteUserReq.h>
#import <vpaassdk/chat/VPCHATCancelMuteUserRsp.h>
#import <vpaassdk/chat/VPCHATListBanCommentUsersReq.h>
#import <vpaassdk/chat/VPCHATListBanCommentUsersRsp.h>
#import <vpaassdk/chat/VPCHATBanCommentUser.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageReq.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageRsp.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersReq.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersRsp.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageReq.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageRsp.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersReq.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersRsp.h>
#import <vpaassdk/chat/VPCHATGetTopicInfoReq.h>
#import <vpaassdk/chat/VPCHATGetTopicInfoRsp.h>
/* optimized_djinni_generated_objc_file */