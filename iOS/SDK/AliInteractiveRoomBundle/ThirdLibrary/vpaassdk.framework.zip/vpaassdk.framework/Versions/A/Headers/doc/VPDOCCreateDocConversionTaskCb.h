// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCCreateDocConversionTaskRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 创建转码任务回调
 */
@protocol VPDOCCreateDocConversionTaskCb

- (void)onSuccess:(nonnull VPDOCCreateDocConversionTaskRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */