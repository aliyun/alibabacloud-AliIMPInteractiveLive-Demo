// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEContinuePlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEContinuePlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEEndLiveTimingReq.h>
#import <vpaassdk/live/VPLIVEEndLiveTimingRsp.h>
#import <vpaassdk/live/VPLIVEEndPlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEEndPlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEGetLiveDetailReq.h>
#import <vpaassdk/live/VPLIVEGetLiveDetailRsp.h>
#import <vpaassdk/live/VPLIVEGetLiveStatisticsReq.h>
#import <vpaassdk/live/VPLIVEGetLiveStatisticsRsp.h>
#import <vpaassdk/live/VPLIVEGetLiveUserStatisticsReq.h>
#import <vpaassdk/live/VPLIVEGetLiveUserStatisticsRsp.h>
#import <vpaassdk/live/VPLIVEPublishLiveReq.h>
#import <vpaassdk/live/VPLIVEPublishLiveRsp.h>
#import <vpaassdk/live/VPLIVEStartLiveTimingReq.h>
#import <vpaassdk/live/VPLIVEStartLiveTimingRsp.h>
#import <vpaassdk/live/VPLIVEStartPlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEStartPlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEUpdateLiveReq.h>
#import <vpaassdk/live/VPLIVEUpdateLiveRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPLIVEContinuePlaybackTimingCb;
@protocol VPLIVEEndLiveTimingCb;
@protocol VPLIVEEndPlaybackTimingCb;
@protocol VPLIVEGetLiveDetailCb;
@protocol VPLIVEGetLiveStatisticsCb;
@protocol VPLIVEGetLiveUserStatisticsCb;
@protocol VPLIVEPublishLiveCb;
@protocol VPLIVEStartLiveTimingCb;
@protocol VPLIVEStartPlaybackTimingCb;
@protocol VPLIVEUpdateLiveCb;


@interface VPLIVELiveRpcInterface : NSObject

/**
 * @brief 发布直播
 */
- (void)publishLive:(nonnull VPLIVEPublishLiveReq *)req
           callback:(nullable id<VPLIVEPublishLiveCb>)callback;

- (void)publishLiveWithBlock:(nonnull VPLIVEPublishLiveReq *) req
                   onSuccess:(nullable void(^)(VPLIVEPublishLiveRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取直播详情
 */
- (void)getLiveDetail:(nonnull VPLIVEGetLiveDetailReq *)req
             callback:(nullable id<VPLIVEGetLiveDetailCb>)callback;

- (void)getLiveDetailWithBlock:(nonnull VPLIVEGetLiveDetailReq *) req
                     onSuccess:(nullable void(^)(VPLIVEGetLiveDetailRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 更新直播信息
 */
- (void)updateLive:(nonnull VPLIVEUpdateLiveReq *)req
          callback:(nullable id<VPLIVEUpdateLiveCb>)callback;

- (void)updateLiveWithBlock:(nonnull VPLIVEUpdateLiveReq *) req
                  onSuccess:(nullable void(^)(VPLIVEUpdateLiveRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开始观看直播计时
 */
- (void)startLiveTiming:(nonnull VPLIVEStartLiveTimingReq *)req
               callback:(nullable id<VPLIVEStartLiveTimingCb>)callback;

- (void)startLiveTimingWithBlock:(nonnull VPLIVEStartLiveTimingReq *) req
                       onSuccess:(nullable void(^)(VPLIVEStartLiveTimingRsp * _Nonnull rsp))onSuccess
                       onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 结束观看直播计时
 */
- (void)endLiveTiming:(nonnull VPLIVEEndLiveTimingReq *)req
             callback:(nullable id<VPLIVEEndLiveTimingCb>)callback;

- (void)endLiveTimingWithBlock:(nonnull VPLIVEEndLiveTimingReq *) req
                     onSuccess:(nullable void(^)(VPLIVEEndLiveTimingRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开始观看回放计时
 */
- (void)startPlaybackTiming:(nonnull VPLIVEStartPlaybackTimingReq *)req
                   callback:(nullable id<VPLIVEStartPlaybackTimingCb>)callback;

- (void)startPlaybackTimingWithBlock:(nonnull VPLIVEStartPlaybackTimingReq *) req
                           onSuccess:(nullable void(^)(VPLIVEStartPlaybackTimingRsp * _Nonnull rsp))onSuccess
                           onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 观看回放中计时打点上报，正在观看
 */
- (void)continuePlaybackTiming:(nonnull VPLIVEContinuePlaybackTimingReq *)req
                      callback:(nullable id<VPLIVEContinuePlaybackTimingCb>)callback;

- (void)continuePlaybackTimingWithBlock:(nonnull VPLIVEContinuePlaybackTimingReq *) req
                              onSuccess:(nullable void(^)(VPLIVEContinuePlaybackTimingRsp * _Nonnull rsp))onSuccess
                              onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 结束观看回放计时
 */
- (void)endPlaybackTiming:(nonnull VPLIVEEndPlaybackTimingReq *)req
                 callback:(nullable id<VPLIVEEndPlaybackTimingCb>)callback;

- (void)endPlaybackTimingWithBlock:(nonnull VPLIVEEndPlaybackTimingReq *) req
                         onSuccess:(nullable void(^)(VPLIVEEndPlaybackTimingRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取直播统计信息
 */
- (void)getLiveStatistics:(nonnull VPLIVEGetLiveStatisticsReq *)req
                 callback:(nullable id<VPLIVEGetLiveStatisticsCb>)callback;

- (void)getLiveStatisticsWithBlock:(nonnull VPLIVEGetLiveStatisticsReq *) req
                         onSuccess:(nullable void(^)(VPLIVEGetLiveStatisticsRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 按人维度获取直播统计信息
 */
- (void)getLiveUserStatistics:(nonnull VPLIVEGetLiveUserStatisticsReq *)req
                     callback:(nullable id<VPLIVEGetLiveUserStatisticsCb>)callback;

- (void)getLiveUserStatisticsWithBlock:(nonnull VPLIVEGetLiveUserStatisticsReq *) req
                             onSuccess:(nullable void(^)(VPLIVEGetLiveUserStatisticsRsp * _Nonnull rsp))onSuccess
                             onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */