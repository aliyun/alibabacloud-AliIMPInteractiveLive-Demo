// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 共享桌面消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCShareScreenMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                              userId:(nonnull NSString *)userId
                                open:(BOOL)open;
+ (nonnull instancetype)VPRTCShareScreenMessageWithType:(int32_t)type
                                                version:(int64_t)version
                                                 confId:(nonnull NSString *)confId
                                                 userId:(nonnull NSString *)userId
                                                   open:(BOOL)open;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_id 共享用户ID
 */
@property (nonatomic, nonnull) NSString * userId;

/**
 * @param open true:开始共享;false:结束共享
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */