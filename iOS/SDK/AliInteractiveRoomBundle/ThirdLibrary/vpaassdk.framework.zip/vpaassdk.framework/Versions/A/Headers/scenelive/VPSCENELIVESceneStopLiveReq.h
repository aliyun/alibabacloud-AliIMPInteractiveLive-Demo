// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 关闭直播请求
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneStopLiveReq : NSObject
- (nonnull instancetype)initWithLiveId:(nonnull NSString *)liveId
                                userId:(nonnull NSString *)userId;
+ (nonnull instancetype)VPSCENELIVESceneStopLiveReqWithLiveId:(nonnull NSString *)liveId
                                                       userId:(nonnull NSString *)userId;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param user_id 操作人id
 */
@property (nonatomic, nonnull) NSString * userId;

@end
/* optimized_djinni_generated_objc_file */