// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <vpaassdk/monitorhub/VPMonitorhubReportModel.h>
#import <vpaassdk/monitorhub/VPMonitorhubSlsConfigModel.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubReportConfig : NSObject
- (nonnull instancetype)initWithReportMode:(VPMonitorhubReportModel)reportMode
                                 slsConfig:(nonnull VPMonitorhubSlsConfigModel *)slsConfig
                        heartbeatIntervalS:(int32_t)heartbeatIntervalS;
+ (nonnull instancetype)VPMonitorhubReportConfigWithReportMode:(VPMonitorhubReportModel)reportMode
                                                     slsConfig:(nonnull VPMonitorhubSlsConfigModel *)slsConfig
                                            heartbeatIntervalS:(int32_t)heartbeatIntervalS;

@property (nonatomic) VPMonitorhubReportModel reportMode;

@property (nonatomic, nonnull) VPMonitorhubSlsConfigModel * slsConfig;

/**
 * @brief 心跳上报间隔,单位：秒
 */
@property (nonatomic) int32_t heartbeatIntervalS;

@end
/* optimized_djinni_generated_objc_file */