// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 播流地址信息
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEPlayUrl : NSObject
- (nonnull instancetype)initWithCodeLevel:(int32_t)codeLevel
                                   flvUrl:(nonnull NSString *)flvUrl
                                   hlsUrl:(nonnull NSString *)hlsUrl
                                  rtmpUrl:(nonnull NSString *)rtmpUrl;
+ (nonnull instancetype)VPLIVEPlayUrlWithCodeLevel:(int32_t)codeLevel
                                            flvUrl:(nonnull NSString *)flvUrl
                                            hlsUrl:(nonnull NSString *)hlsUrl
                                           rtmpUrl:(nonnull NSString *)rtmpUrl;

/**
 * @param code_level 码率
 */
@property (nonatomic) int32_t codeLevel;

/**
 * @param flv_url flv拉流地址
 */
@property (nonatomic, nonnull) NSString * flvUrl;

/**
 * @param hls_url hls拉流
 */
@property (nonatomic, nonnull) NSString * hlsUrl;

/**
 * @param rtmp_url rtmp拉流
 */
@property (nonatomic, nonnull) NSString * rtmpUrl;

@end
/* optimized_djinni_generated_objc_file */