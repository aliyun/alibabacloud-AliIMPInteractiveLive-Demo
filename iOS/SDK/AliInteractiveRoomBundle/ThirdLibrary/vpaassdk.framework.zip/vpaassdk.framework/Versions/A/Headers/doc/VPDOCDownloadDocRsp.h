// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCCredentials.h>
#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 下载文档响应
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCDownloadDocRsp : NSObject
- (nonnull instancetype)initWithDocId:(nonnull NSString *)docId
                            ossBucket:(nonnull NSString *)ossBucket
                            ossObject:(nonnull NSString *)ossObject
                              docType:(nonnull NSString *)docType
                          credentials:(nonnull VPDOCCredentials *)credentials;
+ (nonnull instancetype)VPDOCDownloadDocRspWithDocId:(nonnull NSString *)docId
                                           ossBucket:(nonnull NSString *)ossBucket
                                           ossObject:(nonnull NSString *)ossObject
                                             docType:(nonnull NSString *)docType
                                         credentials:(nonnull VPDOCCredentials *)credentials;

/**
 * @param doc_id 文档ID
 */
@property (nonatomic, nonnull) NSString * docId;

/**
 * @param oss_bucket OSSBucket
 */
@property (nonatomic, nonnull) NSString * ossBucket;

/**
 * @param oss_object OSSObject
 */
@property (nonatomic, nonnull) NSString * ossObject;

/**
 * @param doc_type 文档类型
 */
@property (nonatomic, nonnull) NSString * docType;

/**
 * @param credentials STSToken秘钥
 */
@property (nonatomic, nonnull) VPDOCCredentials * credentials;

@end
/* optimized_djinni_generated_objc_file */