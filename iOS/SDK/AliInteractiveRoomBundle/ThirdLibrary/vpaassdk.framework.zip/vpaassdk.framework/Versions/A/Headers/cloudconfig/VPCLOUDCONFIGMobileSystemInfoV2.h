// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 移动端参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGMobileSystemInfoV2 : NSObject
- (nonnull instancetype)initWithDeviceType:(nonnull NSString *)deviceType
                             systemVersion:(nonnull NSString *)systemVersion
                                deviceName:(nonnull NSString *)deviceName;
+ (nonnull instancetype)VPCLOUDCONFIGMobileSystemInfoV2WithDeviceType:(nonnull NSString *)deviceType
                                                        systemVersion:(nonnull NSString *)systemVersion
                                                           deviceName:(nonnull NSString *)deviceName;

/**
 * @param device_type 端的类型ios/andorid
 */
@property (nonatomic, nonnull) NSString * deviceType;

/**
 * @param system_version 系统版本
 */
@property (nonatomic, nonnull) NSString * systemVersion;

/**
 * @param device_name 设备名
 */
@property (nonatomic, nonnull) NSString * deviceName;

@end
/* optimized_djinni_generated_objc_file */