// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 删除白板文档响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBDeleteWhiteboardDocRsp : NSObject
- (nonnull instancetype)initWithStatus:(int32_t)status
                           errorReason:(nonnull NSString *)errorReason;
+ (nonnull instancetype)VPWBDeleteWhiteboardDocRspWithStatus:(int32_t)status
                                                 errorReason:(nonnull NSString *)errorReason;

/**
 * @param status 删除状态(0:失败;1:成功)
 */
@property (nonatomic) int32_t status;

/**
 * @param error_reason 错误信息
 */
@property (nonatomic, nonnull) NSString * errorReason;

@end
/* optimized_djinni_generated_objc_file */