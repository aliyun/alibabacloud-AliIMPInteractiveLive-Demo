// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>

VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSGetClassDetailRsp : NSObject
- (nonnull instancetype)initWithClassId:(nonnull NSString *)classId
                                  title:(nonnull NSString *)title
                           createUserId:(nonnull NSString *)createUserId
                         createNickname:(nonnull NSString *)createNickname
                                 status:(int32_t)status
                              startTime:(int64_t)startTime
                                endTime:(int64_t)endTime
                                 roomId:(nonnull NSString *)roomId
                                 liveId:(nonnull NSString *)liveId
                                 confId:(nonnull NSString *)confId
                           whiteboardId:(nonnull NSString *)whiteboardId
                     whiteboardRecordId:(nonnull NSString *)whiteboardRecordId
                                 chatId:(nonnull NSString *)chatId
                            adminIdList:(nonnull NSArray<NSString *> *)adminIdList;
+ (nonnull instancetype)VPSCENECLASSGetClassDetailRspWithClassId:(nonnull NSString *)classId
                                                           title:(nonnull NSString *)title
                                                    createUserId:(nonnull NSString *)createUserId
                                                  createNickname:(nonnull NSString *)createNickname
                                                          status:(int32_t)status
                                                       startTime:(int64_t)startTime
                                                         endTime:(int64_t)endTime
                                                          roomId:(nonnull NSString *)roomId
                                                          liveId:(nonnull NSString *)liveId
                                                          confId:(nonnull NSString *)confId
                                                    whiteboardId:(nonnull NSString *)whiteboardId
                                              whiteboardRecordId:(nonnull NSString *)whiteboardRecordId
                                                          chatId:(nonnull NSString *)chatId
                                                     adminIdList:(nonnull NSArray<NSString *> *)adminIdList;

/**
 * @param class_id 课ID
 */
@property (nonatomic, nonnull) NSString * classId;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param create_user_id 创建人ID，不含domain
 */
@property (nonatomic, nonnull) NSString * createUserId;

/**
 * @param create_nickname 创建人昵称
 */
@property (nonatomic, nonnull) NSString * createNickname;

/**
 * @param status 课状态，0:未开始1:上课中2:已下课
 */
@property (nonatomic) int32_t status;

/**
 * @param start_time 开始上课时间点
 */
@property (nonatomic) int64_t startTime;

/**
 * @param end_time 下课时间点
 */
@property (nonatomic) int64_t endTime;

/**
 * @param room_id 房间ID
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param live_id 直播ID
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param conf_id 连麦ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param whiteboard_id 白板ID
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

/**
 * @param whiteboard_record_id 白板录制ID
 */
@property (nonatomic, nonnull) NSString * whiteboardRecordId;

/**
 * @param chat_id 弹幕ID
 */
@property (nonatomic, nonnull) NSString * chatId;

/**
 * @param admin_id_list 管理员id列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * adminIdList;

@end
/* optimized_djinni_generated_objc_file */