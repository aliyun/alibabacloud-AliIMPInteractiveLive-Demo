// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@class VPMPSManager;


/**
 * MPSManager 创建监听
 */
@protocol VPMPSManagerCreateListener

/**
 * MPSManager 创建成功
 */
- (void)onSuccess:(nullable VPMPSManager *)manager;

/**
 * MPSManager 创建失败
 */
- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */