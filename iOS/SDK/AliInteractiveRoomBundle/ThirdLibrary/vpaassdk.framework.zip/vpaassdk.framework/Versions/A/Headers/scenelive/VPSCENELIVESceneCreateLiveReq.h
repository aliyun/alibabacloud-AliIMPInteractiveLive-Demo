// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建直播请求
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneCreateLiveReq : NSObject
- (nonnull instancetype)initWithTitle:(nonnull NSString *)title
                               notice:(nonnull NSString *)notice
                             coverUrl:(nonnull NSString *)coverUrl
                             anchorId:(nonnull NSString *)anchorId
                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                           anchorNick:(nonnull NSString *)anchorNick
                        enableLinkMic:(BOOL)enableLinkMic;
+ (nonnull instancetype)VPSCENELIVESceneCreateLiveReqWithTitle:(nonnull NSString *)title
                                                        notice:(nonnull NSString *)notice
                                                      coverUrl:(nonnull NSString *)coverUrl
                                                      anchorId:(nonnull NSString *)anchorId
                                                     extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                                    anchorNick:(nonnull NSString *)anchorNick
                                                 enableLinkMic:(BOOL)enableLinkMic;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param cover_url 封面
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param anchor_id 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param anchor_nick 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNick;

/**
 * @param enable_link_mic 是否启用连麦
 */
@property (nonatomic) BOOL enableLinkMic;

@end
/* optimized_djinni_generated_objc_file */