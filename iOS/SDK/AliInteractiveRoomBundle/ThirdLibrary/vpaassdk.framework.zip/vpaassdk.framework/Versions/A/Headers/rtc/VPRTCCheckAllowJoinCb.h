// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCCheckAllowJoinRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 检测能否入会回调
 */
@protocol VPRTCCheckAllowJoinCb

- (void)onSuccess:(nonnull VPRTCCheckAllowJoinRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */