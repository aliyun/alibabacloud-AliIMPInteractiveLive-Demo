// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <vpaassdk/room/VPROOMRoomUserModel.h>
#import <Foundation/Foundation.h>

/**
 * @brief 分页获取房间用户在线列表响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomUserListRsp : NSObject
- (nonnull instancetype)initWithTotal:(int32_t)total
                             userList:(nonnull NSArray<VPROOMRoomUserModel *> *)userList
                              hasMore:(BOOL)hasMore;
+ (nonnull instancetype)VPROOMGetRoomUserListRspWithTotal:(int32_t)total
                                                 userList:(nonnull NSArray<VPROOMRoomUserModel *> *)userList
                                                  hasMore:(BOOL)hasMore;

/**
 * @param total 总人数
 */
@property (nonatomic) int32_t total;

/**
 * @param user_list 用户id列表
 */
@property (nonatomic, nonnull) NSArray<VPROOMRoomUserModel *> * userList;

/**
 * @param has_more 是否还有更多的数据
 */
@property (nonatomic) BOOL hasMore;

@end
/* optimized_djinni_generated_objc_file */