// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取文档请求
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCGetDocReq : NSObject
- (nonnull instancetype)initWithDocId:(nonnull NSString *)docId
                               roomId:(nonnull NSString *)roomId;
+ (nonnull instancetype)VPDOCGetDocReqWithDocId:(nonnull NSString *)docId
                                         roomId:(nonnull NSString *)roomId;

/**
 * @param doc_id 必填，文档ID
 */
@property (nonatomic, nonnull) NSString * docId;

/**
 * @param room_id 可选，房间Id，用于进行房间鉴权和可靠消息发送
 */
@property (nonatomic, nonnull) NSString * roomId;

@end
/* optimized_djinni_generated_objc_file */