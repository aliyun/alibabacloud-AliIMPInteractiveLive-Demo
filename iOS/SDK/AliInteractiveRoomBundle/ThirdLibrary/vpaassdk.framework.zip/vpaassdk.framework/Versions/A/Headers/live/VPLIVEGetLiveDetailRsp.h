// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <vpaassdk/live/VPLIVELive.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取直播详情响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEGetLiveDetailRsp : NSObject
- (nonnull instancetype)initWithLive:(nonnull VPLIVELive *)live;
+ (nonnull instancetype)VPLIVEGetLiveDetailRspWithLive:(nonnull VPLIVELive *)live;

/**
 * @param live 直播详情
 */
@property (nonatomic, nonnull) VPLIVELive * live;

@end
/* optimized_djinni_generated_objc_file */