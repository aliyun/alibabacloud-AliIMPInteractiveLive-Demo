// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// cloudconfig_Bridging_Header.h
// cloudconfig_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for cloudconfigBridgingHeader.
FOUNDATION_EXPORT double cloudconfigBridgingHeaderVersionNumber;

//! Project version string for cloudconfigBridgingHeader.
FOUNDATION_EXPORT const unsigned char cloudconfigBridgingHeaderVersionString[];

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudconfigModule.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudconfigNotifyCb.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGSlsReportMode.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudconfigExtInterface.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGMobileSystemInfo.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGPcSystemInfo.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudConfigBaseInfo.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetCloudConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetCloudConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetAppConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetAppConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGSlsConfig.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGStsToken.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigReq.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGMobileSystemInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGPcSystemInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGWebSystemInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudConfigBaseInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetCloudConfigCb.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetAppConfigCb.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigCb.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigCb.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudconfigRpcInterface.h>
/* optimized_djinni_generated_objc_file */