// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 同意/拒绝申请连麦请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCApproveLinkMicReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                             calleeUid:(nonnull NSString *)calleeUid
                               approve:(BOOL)approve;
+ (nonnull instancetype)VPRTCApproveLinkMicReqWithConfId:(nonnull NSString *)confId
                                               calleeUid:(nonnull NSString *)calleeUid
                                                 approve:(BOOL)approve;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param callee_uid 被连麦用户id
 */
@property (nonatomic, nonnull) NSString * calleeUid;

/**
 * @param approve true:同意连麦，false：拒绝连麦
 */
@property (nonatomic) BOOL approve;

@end
/* optimized_djinni_generated_objc_file */