// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATCancelMuteUserRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 取消禁言某位用户回调
 */
@protocol VPCHATCancelMuteUserCb

- (void)onSuccess:(nonnull VPCHATCancelMuteUserRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */