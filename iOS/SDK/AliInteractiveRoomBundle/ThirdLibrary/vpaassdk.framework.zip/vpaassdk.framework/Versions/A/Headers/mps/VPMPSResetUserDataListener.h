// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * ResetUserData 用户目录重置监听
 */
@protocol VPMPSResetUserDataListener

/**
 * 重置成功
 */
- (void)onSuccess;

/**
 * 重置失败
 */
- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */