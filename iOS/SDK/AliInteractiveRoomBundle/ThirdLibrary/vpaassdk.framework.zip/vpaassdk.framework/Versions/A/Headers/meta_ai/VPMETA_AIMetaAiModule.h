// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPMETA_AIMetaAiExtInterface;
@class VPMETA_AIMetaAiModule;
@class VPMETA_AIMetaAiRpcInterface;


VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIMetaAiModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPMETA_AIMetaAiModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPMETA_AIMetaAiRpcInterface *)getRpcInterface;

- (nullable VPMETA_AIMetaAiExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */