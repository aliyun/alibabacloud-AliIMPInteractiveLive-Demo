// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <vpaassdk/wb/VPWBPageInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板页码映射查询响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBGetWhiteboardPageInfoRsp : NSObject
- (nonnull instancetype)initWithPageList:(nonnull NSArray<VPWBPageInfo *> *)pageList
                   intraPageResourceList:(nonnull NSArray<VPWBPageInfo *> *)intraPageResourceList;
+ (nonnull instancetype)VPWBGetWhiteboardPageInfoRspWithPageList:(nonnull NSArray<VPWBPageInfo *> *)pageList
                                           intraPageResourceList:(nonnull NSArray<VPWBPageInfo *> *)intraPageResourceList;

/**
 * @param page_list 页码信息列表
 */
@property (nonatomic, nonnull) NSArray<VPWBPageInfo *> * pageList;

/**
 * @param intra_page_resource_list 页内资源列表
 */
@property (nonatomic, nonnull) NSArray<VPWBPageInfo *> * intraPageResourceList;

@end
/* optimized_djinni_generated_objc_file */