// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 分页获取房间用户在线列表请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomUserListReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                               pageNum:(int32_t)pageNum
                              pageSize:(int32_t)pageSize;
+ (nonnull instancetype)VPROOMGetRoomUserListReqWithRoomId:(nonnull NSString *)roomId
                                                   pageNum:(int32_t)pageNum
                                                  pageSize:(int32_t)pageSize;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param page_num 分页查询的页数,从1开始，每次分页查询+1
 */
@property (nonatomic) int32_t pageNum;

/**
 * @param page_size 分页查询的size,要求大于0，最大1000
 */
@property (nonatomic) int32_t pageSize;

@end
/* optimized_djinni_generated_objc_file */