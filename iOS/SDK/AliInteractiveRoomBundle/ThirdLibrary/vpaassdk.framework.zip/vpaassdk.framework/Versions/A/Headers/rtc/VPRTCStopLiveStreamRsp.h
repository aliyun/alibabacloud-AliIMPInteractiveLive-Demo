// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 停止旁路推流响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCStopLiveStreamRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCStopLiveStreamRsp;

@end
/* optimized_djinni_generated_objc_file */