// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/easyutils/VPEASYUTILSExportDelc.h>
#import <vpaassdk/easyutils/VPEasyutilsEncryptDecryptDataResult.h>
#import <Foundation/Foundation.h>


VPEASYUTILS_OBJECTC_EXPORT
@interface VPEasyutils : NSObject

/**
 * 数据解密函数
 */
+ (nonnull VPEasyutilsEncryptDecryptDataResult *)decryptData:(nonnull NSData *)password
                                                        salt:(nonnull NSData *)salt
                                                      inData:(nonnull NSData *)inData;

@end
/* optimized_djinni_generated_objc_file */