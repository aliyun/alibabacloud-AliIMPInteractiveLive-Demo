// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * 上报事件定义
 */
typedef NS_ENUM(NSInteger, VPMonitorhubEvent)
{
    /**
     * 默认空事件
     */
    VPMonitorhubEventMhevtDefaultNoevent = 0,
    /**
     * PaasSDK-音视频-事件数据 paassdk.rtc.act
     */
    VPMonitorhubEventMhevtPaassdkRtcStartClass = 94,
    VPMonitorhubEventMhevtPaassdkRtcStopClass = 95,
    VPMonitorhubEventMhevtPaassdkRtcEnterClass = 96,
    VPMonitorhubEventMhevtPaassdkRtcExitClass = 97,
    VPMonitorhubEventMhevtPaassdkRtcShareScreenStart = 98,
    VPMonitorhubEventMhevtPaassdkRtcShareScreenEnd = 99,
    VPMonitorhubEventMhevtPaassdkRtcShowStream = 100,
    VPMonitorhubEventMhevtPaassdkRtcStopStream = 101,
    VPMonitorhubEventMhevtPaassdkRtcStartPreview = 102,
    VPMonitorhubEventMhevtPaassdkRtcStopPreview = 103,
    VPMonitorhubEventMhevtPaassdkRtcCreateRtc = 104,
    VPMonitorhubEventMhevtPaassdkRtcDestoryRtc = 105,
    VPMonitorhubEventMhevtPaassdkRtcPushLivestream = 106,
    VPMonitorhubEventMhevtPaassdkRtcGetPushstreamUrl = 107,
    VPMonitorhubEventMhevtPaassdkRtcSdkJoinChannel = 108,
    VPMonitorhubEventMhevtPaassdkRtcSdkLeaveChannel = 109,
    VPMonitorhubEventMhevtPaassdkRtcInviteJoinRtc = 110,
    VPMonitorhubEventMhevtPaassdkRtcKickMembers = 111,
    VPMonitorhubEventMhevtPaassdkRtcStartRecord = 112,
    VPMonitorhubEventMhevtPaassdkRtcStopRecord = 113,
    VPMonitorhubEventMhevtPaassdkRtcRtcError = 114,
    VPMonitorhubEventMhevtPaassdkRtcPerformanceLow = 115,
    VPMonitorhubEventMhevtPaassdkRtcPerformanceNormal = 116,
    VPMonitorhubEventMhevtPaassdkRtcNetDisconnect = 117,
    VPMonitorhubEventMhevtPaassdkRtcNetReconnect = 118,
    VPMonitorhubEventMhevtPaassdkRtcNetReconnectSuc = 119,
    VPMonitorhubEventMhevtPaassdkRtcFirstFrameRender = 120,
    VPMonitorhubEventMhevtPaassdkRtcNetChanged = 121,
    VPMonitorhubEventMhevtPaassdkRtcApplyLinkMic = 122,
    VPMonitorhubEventMhevtPaassdkRtcLiveTranscodingEvent = 123,
    VPMonitorhubEventMhevtPaassdkRtcReportPushLive = 124,
    VPMonitorhubEventMhevtPaassdkRtcReportJoinStatus = 125,
    VPMonitorhubEventMhevtPaassdkRtcReportLeaveStatus = 126,
    VPMonitorhubEventMhevtPaassdkRtcGetRtcToken = 127,
    VPMonitorhubEventMhevtPaassdkRtcShareAudioStart = 129,
    VPMonitorhubEventMhevtPaassdkRtcShareAudioEnd = 130,
    VPMonitorhubEventMhevtPaassdkRtcRemoteOffline = 131,
    /**
     * PaasSDK-音视频-事件数据 paassdk.rtc.heart
     */
    VPMonitorhubEventMhevtPaassdkRtcStats = 180,
    VPMonitorhubEventMhevtPaassdkRtcLocalVideoStats = 181,
    VPMonitorhubEventMhevtPaassdkRtcLocalAudioStats = 182,
    VPMonitorhubEventMhevtPaassdkRtcRemoteVideoStats = 183,
    VPMonitorhubEventMhevtPaassdkRtcRemoteAudioStats = 184,
    /**
     * PaasSDK-白板-事件数据 paassdk.wb.act
     */
    VPMonitorhubEventMhevtPaassdkWbCreateWhiteboard = 227,
    VPMonitorhubEventMhevtPaassdkWbDestoryWhiteboard = 228,
    VPMonitorhubEventMhevtPaassdkWbStartWhiteboardRecord = 229,
    VPMonitorhubEventMhevtPaassdkWbStopWhiteboardRecord = 230,
    VPMonitorhubEventMhevtPaassdkWbPauseWhiteboardRecord = 231,
    VPMonitorhubEventMhevtPaassdkWbResumeWhiteboardRecord = 232,
    VPMonitorhubEventMhevtPaassdkWbErrorEvent = 233,
    /**
     * PaasSDK-聊天-事件数据 paassdk.chat.act
     */
    VPMonitorhubEventMhevtPaassdkChatMuteAll = 333,
    VPMonitorhubEventMhevtPaassdkChatCancelMuteAll = 334,
    VPMonitorhubEventMhevtPaassdkChatMuteUser = 335,
    VPMonitorhubEventMhevtPaassdkChatCancelMuteUser = 336,
    /**
     * PaasSDK-房间-事件数据 paassdk.room.act
     */
    VPMonitorhubEventMhevtPaassdkRoomLogin = 437,
    VPMonitorhubEventMhevtPaassdkRoomLogout = 438,
    VPMonitorhubEventMhevtPaassdkRoomEnterRoom = 439,
    VPMonitorhubEventMhevtPaassdkRoomLeaveRoom = 440,
    VPMonitorhubEventMhevtPaassdkRoomGoBackgroud = 441,
    VPMonitorhubEventMhevtPaassdkRoomGoFrontgroud = 442,
    /**
     * 客户端-直播业务-上行-事件数据 meta.client.publish.act
     */
    VPMonitorhubEventMhevtClientPublishStartLive = 540,
    VPMonitorhubEventMhevtClientPublishRtmpConnect = 541,
    VPMonitorhubEventMhevtClientPublishRtmpClose = 542,
    VPMonitorhubEventMhevtClientPublishNetDisconnect = 543,
    VPMonitorhubEventMhevtClientPublishNetReconnectStart = 544,
    VPMonitorhubEventMhevtClientPublishPublishLive = 545,
    VPMonitorhubEventMhevtClientPublishVideoEncoderInit = 546,
    VPMonitorhubEventMhevtClientPublishAudioEncoderInit = 547,
    VPMonitorhubEventMhevtClientPublishEncoderLowFps = 548,
    VPMonitorhubEventMhevtClientPublishNetLowFps = 549,
    VPMonitorhubEventMhevtClientPublishPauseLive = 550,
    VPMonitorhubEventMhevtClientPublishStopLive = 551,
    VPMonitorhubEventMhevtClientPublishNetReconnectSucess = 552,
    VPMonitorhubEventMhevtClientPublishErrorEvent = 553,
    VPMonitorhubEventMhevtClientPublishBitrateChange = 554,
    VPMonitorhubEventMhevtClientPublishFpsChange = 555,
    /**
     * 客户端-直播业务-上行-事件数据 meta.client.publish.heart
     */
    VPMonitorhubEventMhevtClientPublishHeartBeat = 600,
    /**
     * 客户端-直播业务-下行-事件数据 meta.client.play.act
     */
    VPMonitorhubEventMhevtClientPlayLivePlay = 750,
    VPMonitorhubEventMhevtClientPlayLiveStop = 751,
    VPMonitorhubEventMhevtClientPlayLiveConnect = 752,
    VPMonitorhubEventMhevtClientPlayLiveDisconnect = 753,
    VPMonitorhubEventMhevtClientPlayLiveReconnect = 754,
    VPMonitorhubEventMhevtClientPlayVideoDecoderInit = 755,
    VPMonitorhubEventMhevtClientPlayAudioDecoderInit = 756,
    VPMonitorhubEventMhevtClientPlayStopLive = 757,
    VPMonitorhubEventMhevtClientPlayFirstFrame = 758,
    VPMonitorhubEventMhevtClientPlayDelay = 759,
    VPMonitorhubEventMhevtClientPlayLowFps = 760,
    VPMonitorhubEventMhevtClientPlayPause = 761,
    VPMonitorhubEventMhevtClientPlaySeek = 762,
    VPMonitorhubEventMhevtClientPlayErrorEvent = 763,
    VPMonitorhubEventMhevtClientPlayNetLoadingBegin = 764,
    VPMonitorhubEventMhevtClientPlayNetLoadingEnd = 765,
    /**
     * 客户端-MetaPath-链路-事件数据 metapath.client.link.act
     */
    VPMonitorhubEventMhevtMetapathClientLinkConnStateChange = 801,
    VPMonitorhubEventMhevtMetapathClientLinkLinkConnect = 802,
};
/* optimized_djinni_generated_objc_file */