// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询直播详情请求
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneGetLiveDetailReq : NSObject
- (nonnull instancetype)initWithLiveId:(nonnull NSString *)liveId;
+ (nonnull instancetype)VPSCENELIVESceneGetLiveDetailReqWithLiveId:(nonnull NSString *)liveId;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

@end
/* optimized_djinni_generated_objc_file */