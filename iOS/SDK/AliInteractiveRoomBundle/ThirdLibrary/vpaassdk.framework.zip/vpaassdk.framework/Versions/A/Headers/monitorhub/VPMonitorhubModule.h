// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <vpaassdk/monitorhub/VPMonitorhubEvent.h>
#import <vpaassdk/monitorhub/VPMonitorhubProcedure.h>
#import <vpaassdk/monitorhub/VPMonitorhubReportConfig.h>
#import <vpaassdk/monitorhub/VPMonitorhubStsTokenModel.h>
#import <vpaassdk/monitorhub/VPMonitorhubTraceType.h>
#import <Foundation/Foundation.h>
@class VPMonitorhubAppInfo;
@class VPMonitorhubExtInfo;
@class VPMonitorhubModule;
@protocol VPMonitorhubHeartbeatCallback;


/**
 * MonitorHub接口
 */
VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubModule : NSObject

/**
 * 静态方法
 * 获取monitorhub实例
 */
+ (nullable VPMonitorhubModule *)getMonitorhubModule;

/**
 * 设置当前时刻的同步后UnixTime, 单位ms. 用于上报时间打点
 */
- (void)setSyncUnixtimeNow:(int64_t)nowUnixtimeMs;

/**
 * 初始化monitorhub_module
 */
- (void)initMonitorhubModule;

/**
 * 反初始化monitorhub_module
 */
- (void)uninitMonitorhubModule;

/**
 * 设置MonitorHub上报配置
 */
- (void)setConfig:(nonnull VPMonitorhubReportConfig *)config;

/**
 * 如果使用sls_sdk上报，则需定时更新sts token
 */
- (void)updateStsToken:(nonnull VPMonitorhubStsTokenModel *)stsToke;

/**
 * 获取app_info的对象
 */
- (nullable VPMonitorhubAppInfo *)getAppInfo;

/**
 * 上报普通事件数据
 */
- (void)reportNormalEvent:(VPMonitorhubEvent)eventId
              extraFields:(nonnull NSDictionary<NSString *, NSString *> *)extraFields
                errorCode:(int64_t)errorCode
                 errorMsg:(nonnull NSString *)errorMsg;

/**
 * 创建TraceID, 用于上报过程事件数据
 */
- (nonnull NSString *)makeTraceId:(VPMonitorhubProcedure)procedureId;

/**
 * ----------------------- 上报过程事件数据 -----------------------
 * 一般来说, 一个过程(Procedure)里会触发若干个事件(Event), 事件通过 TraceID 关联到一个过程里
 * 过程(Procedure)分三个阶段, 开始, 进行中, 结束. 通过trace_type来标识, 上报时可以附带事件(Event)
 * 如果无附加事件需要上报, eventId 可传 mhevt_default_noevent
 */
- (void)reportTraceEvent:(VPMonitorhubTraceType)traceType
                 traceId:(nonnull NSString *)traceId
             procedureId:(VPMonitorhubProcedure)procedureId
                 eventId:(VPMonitorhubEvent)eventId
             extraFields:(nonnull NSDictionary<NSString *, NSString *> *)extraFields
               errorCode:(int64_t)errorCode
                errorMsg:(nonnull NSString *)errorMsg;

/**
 * 设置定时心跳回调
 * role 指角色
 */
- (void)setHeartbeatCallback:(nullable id<VPMonitorhubHeartbeatCallback>)callback;

/**
 *返回一个map结构体，这个里面的map不会被上报，但其全局可以访问，用来存储一些辅助上报的字段。
 */
- (nullable VPMonitorhubExtInfo *)getExtInfo;

@end
/* optimized_djinni_generated_objc_file */