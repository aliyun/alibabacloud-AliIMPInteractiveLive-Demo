// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 打开白板请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBOpenWhiteboardReq : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId;
+ (nonnull instancetype)VPWBOpenWhiteboardReqWithWhiteboardId:(nonnull NSString *)whiteboardId;

/**
 * @param whiteboard_id 白板Id-原DocKey
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

@end
/* optimized_djinni_generated_objc_file */