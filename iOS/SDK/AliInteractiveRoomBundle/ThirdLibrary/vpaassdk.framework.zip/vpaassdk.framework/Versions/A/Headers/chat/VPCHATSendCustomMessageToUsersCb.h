// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 指定房间用户发送普通自定义消息回调
 */
@protocol VPCHATSendCustomMessageToUsersCb

- (void)onSuccess:(nonnull VPCHATSendCustomMessageToUsersRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */