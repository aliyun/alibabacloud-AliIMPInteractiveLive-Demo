// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <vpaassdk/rtc/VPRTCPane.h>
#import <Foundation/Foundation.h>

/**
 * @brief 设置自定义布局请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCSetCustomLayoutReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                              paneList:(nonnull NSArray<VPRTCPane *> *)paneList
                                  crop:(BOOL)crop;
+ (nonnull instancetype)VPRTCSetCustomLayoutReqWithConfId:(nonnull NSString *)confId
                                                 paneList:(nonnull NSArray<VPRTCPane *> *)paneList
                                                     crop:(BOOL)crop;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param pane_list 布局格子列表
 */
@property (nonatomic, nonnull) NSArray<VPRTCPane *> * paneList;

/**
 * @param crop 是否裁剪，不填写则使用平台默认值，当前默认是裁剪
 */
@property (nonatomic) BOOL crop;

@end
/* optimized_djinni_generated_objc_file */