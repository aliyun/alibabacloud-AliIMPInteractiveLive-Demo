// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetSlsConfigRsp.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGStsToken.h>
#import <Foundation/Foundation.h>


@protocol VPCLOUDCONFIGCloudconfigNotifyCb

- (void)onGetSlsConfig:(nonnull VPCLOUDCONFIGGetSlsConfigRsp *)slsConfig;

- (void)onUpdateSlsStsToken:(nonnull VPCLOUDCONFIGStsToken *)stsToken;

@end
/* optimized_djinni_generated_objc_file */