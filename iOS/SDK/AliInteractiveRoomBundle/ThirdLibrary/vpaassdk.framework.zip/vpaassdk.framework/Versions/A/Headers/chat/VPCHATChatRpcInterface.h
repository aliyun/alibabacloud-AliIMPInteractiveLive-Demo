// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATCancelMuteAllReq.h>
#import <vpaassdk/chat/VPCHATCancelMuteAllRsp.h>
#import <vpaassdk/chat/VPCHATCancelMuteUserReq.h>
#import <vpaassdk/chat/VPCHATCancelMuteUserRsp.h>
#import <vpaassdk/chat/VPCHATGetTopicInfoReq.h>
#import <vpaassdk/chat/VPCHATGetTopicInfoRsp.h>
#import <vpaassdk/chat/VPCHATListBanCommentUsersReq.h>
#import <vpaassdk/chat/VPCHATListBanCommentUsersRsp.h>
#import <vpaassdk/chat/VPCHATListCommentReq.h>
#import <vpaassdk/chat/VPCHATListCommentRsp.h>
#import <vpaassdk/chat/VPCHATMuteAllReq.h>
#import <vpaassdk/chat/VPCHATMuteAllRsp.h>
#import <vpaassdk/chat/VPCHATMuteUserReq.h>
#import <vpaassdk/chat/VPCHATMuteUserRsp.h>
#import <vpaassdk/chat/VPCHATSendCommentReq.h>
#import <vpaassdk/chat/VPCHATSendCommentRsp.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageReq.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageRsp.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersReq.h>
#import <vpaassdk/chat/VPCHATSendCustomMessageToUsersRsp.h>
#import <vpaassdk/chat/VPCHATSendLikeReq.h>
#import <vpaassdk/chat/VPCHATSendLikeRsp.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageReq.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageRsp.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersReq.h>
#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPCHATCancelMuteAllCb;
@protocol VPCHATCancelMuteUserCb;
@protocol VPCHATGetTopicInfoCb;
@protocol VPCHATListBanCommentUsersCb;
@protocol VPCHATListCommentCb;
@protocol VPCHATMuteAllCb;
@protocol VPCHATMuteUserCb;
@protocol VPCHATSendCommentCb;
@protocol VPCHATSendCustomMessageCb;
@protocol VPCHATSendCustomMessageToUsersCb;
@protocol VPCHATSendLikeCb;
@protocol VPCHATSendSystemMessageCb;
@protocol VPCHATSendSystemMessageToUsersCb;


@interface VPCHATChatRpcInterface : NSObject

/**
 * @brief 发送弹幕
 * 完成持久化存储，并推送给在线客户端
 */
- (void)sendComment:(nonnull VPCHATSendCommentReq *)req
           callback:(nullable id<VPCHATSendCommentCb>)callback;

- (void)sendCommentWithBlock:(nonnull VPCHATSendCommentReq *) req
                   onSuccess:(nullable void(^)(VPCHATSendCommentRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 点赞
 */
- (void)sendLike:(nonnull VPCHATSendLikeReq *)req
        callback:(nullable id<VPCHATSendLikeCb>)callback;

- (void)sendLikeWithBlock:(nonnull VPCHATSendLikeReq *) req
                onSuccess:(nullable void(^)(VPCHATSendLikeRsp * _Nonnull rsp))onSuccess
                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 分页拉取弹幕
 */
- (void)listComment:(nonnull VPCHATListCommentReq *)req
           callback:(nullable id<VPCHATListCommentCb>)callback;

- (void)listCommentWithBlock:(nonnull VPCHATListCommentReq *) req
                   onSuccess:(nullable void(^)(VPCHATListCommentRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 全体禁言
 */
- (void)muteAll:(nonnull VPCHATMuteAllReq *)req
       callback:(nullable id<VPCHATMuteAllCb>)callback;

- (void)muteAllWithBlock:(nonnull VPCHATMuteAllReq *) req
               onSuccess:(nullable void(^)(VPCHATMuteAllRsp * _Nonnull rsp))onSuccess
               onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 取消全体禁言
 */
- (void)cancelMuteAll:(nonnull VPCHATCancelMuteAllReq *)req
             callback:(nullable id<VPCHATCancelMuteAllCb>)callback;

- (void)cancelMuteAllWithBlock:(nonnull VPCHATCancelMuteAllReq *) req
                     onSuccess:(nullable void(^)(VPCHATCancelMuteAllRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 禁言某位用户
 */
- (void)muteUser:(nonnull VPCHATMuteUserReq *)req
        callback:(nullable id<VPCHATMuteUserCb>)callback;

- (void)muteUserWithBlock:(nonnull VPCHATMuteUserReq *) req
                onSuccess:(nullable void(^)(VPCHATMuteUserRsp * _Nonnull rsp))onSuccess
                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 取消禁言某位用户
 */
- (void)cancelMuteUser:(nonnull VPCHATCancelMuteUserReq *)req
              callback:(nullable id<VPCHATCancelMuteUserCb>)callback;

- (void)cancelMuteUserWithBlock:(nonnull VPCHATCancelMuteUserReq *) req
                      onSuccess:(nullable void(^)(VPCHATCancelMuteUserRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取禁言的用户列表
 */
- (void)listBanCommentUsers:(nonnull VPCHATListBanCommentUsersReq *)req
                   callback:(nullable id<VPCHATListBanCommentUsersCb>)callback;

- (void)listBanCommentUsersWithBlock:(nonnull VPCHATListBanCommentUsersReq *) req
                           onSuccess:(nullable void(^)(VPCHATListBanCommentUsersRsp * _Nonnull rsp))onSuccess
                           onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 发送普通自定义消息
 */
- (void)sendCustomMessage:(nonnull VPCHATSendCustomMessageReq *)req
                 callback:(nullable id<VPCHATSendCustomMessageCb>)callback;

- (void)sendCustomMessageWithBlock:(nonnull VPCHATSendCustomMessageReq *) req
                         onSuccess:(nullable void(^)(VPCHATSendCustomMessageRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 发送系统消息，系统消息保证可靠
 */
- (void)sendSystemMessage:(nonnull VPCHATSendSystemMessageReq *)req
                 callback:(nullable id<VPCHATSendSystemMessageCb>)callback;

- (void)sendSystemMessageWithBlock:(nonnull VPCHATSendSystemMessageReq *) req
                         onSuccess:(nullable void(^)(VPCHATSendSystemMessageRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 指定房间用户发送普通自定义消息
 */
- (void)sendCustomMessageToUsers:(nonnull VPCHATSendCustomMessageToUsersReq *)req
                        callback:(nullable id<VPCHATSendCustomMessageToUsersCb>)callback;

- (void)sendCustomMessageToUsersWithBlock:(nonnull VPCHATSendCustomMessageToUsersReq *) req
                                onSuccess:(nullable void(^)(VPCHATSendCustomMessageToUsersRsp * _Nonnull rsp))onSuccess
                                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 指定房间用户发送系统消息,系统消息保证可靠
 */
- (void)sendSystemMessageToUsers:(nonnull VPCHATSendSystemMessageToUsersReq *)req
                        callback:(nullable id<VPCHATSendSystemMessageToUsersCb>)callback;

- (void)sendSystemMessageToUsersWithBlock:(nonnull VPCHATSendSystemMessageToUsersReq *) req
                                onSuccess:(nullable void(^)(VPCHATSendSystemMessageToUsersRsp * _Nonnull rsp))onSuccess
                                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取TopicInfo
 */
- (void)getTopicInfo:(nonnull VPCHATGetTopicInfoReq *)req
            callback:(nullable id<VPCHATGetTopicInfoCb>)callback;

- (void)getTopicInfoWithBlock:(nonnull VPCHATGetTopicInfoReq *) req
                    onSuccess:(nullable void(^)(VPCHATGetTopicInfoRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */