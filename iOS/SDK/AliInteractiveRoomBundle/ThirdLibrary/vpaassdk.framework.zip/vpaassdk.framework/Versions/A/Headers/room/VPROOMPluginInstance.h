// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMPluginInstance : NSObject
- (nonnull instancetype)initWithPluginId:(nonnull NSString *)pluginId
                              instanceId:(nonnull NSString *)instanceId
                              createTime:(int64_t)createTime
                               extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPROOMPluginInstanceWithPluginId:(nonnull NSString *)pluginId
                                              instanceId:(nonnull NSString *)instanceId
                                              createTime:(int64_t)createTime
                                               extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param plugin_id 插件id标识
 */
@property (nonatomic, nonnull) NSString * pluginId;

/**
 * @param instance_id 插件对应的实例id
 */
@property (nonatomic, nonnull) NSString * instanceId;

/**
 * @param create_time 创建时间戳
 */
@property (nonatomic) int64_t createTime;

/**
 * @param extension 拓展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */