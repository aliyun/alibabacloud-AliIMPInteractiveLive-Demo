// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGMobileSystemInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGPcSystemInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGWebSystemInfoV2.h>
#import <Foundation/Foundation.h>

/**
 * @brief 云控基本参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGCloudConfigBaseInfoV2 : NSObject
- (nonnull instancetype)initWithPcSystemInfo:(nonnull VPCLOUDCONFIGPcSystemInfoV2 *)pcSystemInfo
                            mobileSystemInfo:(nonnull VPCLOUDCONFIGMobileSystemInfoV2 *)mobileSystemInfo
                               webSystemInfo:(nonnull VPCLOUDCONFIGWebSystemInfoV2 *)webSystemInfo;
+ (nonnull instancetype)VPCLOUDCONFIGCloudConfigBaseInfoV2WithPcSystemInfo:(nonnull VPCLOUDCONFIGPcSystemInfoV2 *)pcSystemInfo
                                                          mobileSystemInfo:(nonnull VPCLOUDCONFIGMobileSystemInfoV2 *)mobileSystemInfo
                                                             webSystemInfo:(nonnull VPCLOUDCONFIGWebSystemInfoV2 *)webSystemInfo;

/**
 * @param pc_system_info PC端参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGPcSystemInfoV2 * pcSystemInfo;

/**
 * @param mobile_system_info 移动端参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGMobileSystemInfoV2 * mobileSystemInfo;

/**
 * @param web_system_info web端参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGWebSystemInfoV2 * webSystemInfo;

@end
/* optimized_djinni_generated_objc_file */