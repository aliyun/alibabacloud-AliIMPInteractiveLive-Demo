// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATCommentModel.h>
#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发送弹幕响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendCommentRsp : NSObject
- (nonnull instancetype)initWithComment:(nonnull VPCHATCommentModel *)comment;
+ (nonnull instancetype)VPCHATSendCommentRspWithComment:(nonnull VPCHATCommentModel *)comment;

/**
 * @param comment 弹幕信息
 */
@property (nonatomic, nonnull) VPCHATCommentModel * comment;

@end
/* optimized_djinni_generated_objc_file */