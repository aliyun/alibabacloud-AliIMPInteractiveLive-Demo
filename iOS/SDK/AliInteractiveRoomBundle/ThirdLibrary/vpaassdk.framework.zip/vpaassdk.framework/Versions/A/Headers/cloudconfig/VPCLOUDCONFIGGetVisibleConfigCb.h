// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGGetVisibleConfigRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 获取租户可视化配置回调
 */
@protocol VPCLOUDCONFIGGetVisibleConfigCb

- (void)onSuccess:(nonnull VPCLOUDCONFIGGetVisibleConfigRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */