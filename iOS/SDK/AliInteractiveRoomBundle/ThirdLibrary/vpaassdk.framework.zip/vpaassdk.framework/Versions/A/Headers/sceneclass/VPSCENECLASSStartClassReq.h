// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上课
 */
VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSStartClassReq : NSObject
- (nonnull instancetype)initWithClassId:(nonnull NSString *)classId;
+ (nonnull instancetype)VPSCENECLASSStartClassReqWithClassId:(nonnull NSString *)classId;

/**
 * @param class_id 课ID
 */
@property (nonatomic, nonnull) NSString * classId;

@end
/* optimized_djinni_generated_objc_file */