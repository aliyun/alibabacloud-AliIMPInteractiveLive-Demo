// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建直播插件时的model
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVELivePluginCreateReq : NSObject
- (nonnull instancetype)initWithAnchorId:(nonnull NSString *)anchorId
                                   title:(nonnull NSString *)title
                            preStartDate:(int64_t)preStartDate
                              preEndDate:(int64_t)preEndDate
                            introduction:(nonnull NSString *)introduction
                           enableLinkMic:(BOOL)enableLinkMic;
+ (nonnull instancetype)VPLIVELivePluginCreateReqWithAnchorId:(nonnull NSString *)anchorId
                                                        title:(nonnull NSString *)title
                                                 preStartDate:(int64_t)preStartDate
                                                   preEndDate:(int64_t)preEndDate
                                                 introduction:(nonnull NSString *)introduction
                                                enableLinkMic:(BOOL)enableLinkMic;

/**
 * @param anchor_id 主播ID
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param title 主题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param pre_start_date 预计开始日期，utc时间
 */
@property (nonatomic) int64_t preStartDate;

/**
 * @param pre_end_date 预计结束日期，utc时间
 */
@property (nonatomic) int64_t preEndDate;

/**
 * @param introduction 直播简介
 */
@property (nonatomic, nonnull) NSString * introduction;

/**
 * @param enable_link_mic 是否开启连麦
 */
@property (nonatomic) BOOL enableLinkMic;

@end
/* optimized_djinni_generated_objc_file */