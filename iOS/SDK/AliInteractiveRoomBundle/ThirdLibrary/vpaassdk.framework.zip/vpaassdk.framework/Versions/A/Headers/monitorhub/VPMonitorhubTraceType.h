// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * 过程类型
 */
typedef NS_ENUM(NSInteger, VPMonitorhubTraceType)
{
    VPMonitorhubTraceTypeMhTraceTypeStart = 1,
    VPMonitorhubTraceTypeMhTraceTypeInProcess = 2,
    VPMonitorhubTraceTypeMhTraceTypeEnd = 3,
};
/* optimized_djinni_generated_objc_file */