// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// monitorhub_Bridging_Header.h
// monitorhub_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for monitorhubBridgingHeader.
FOUNDATION_EXPORT double monitorhubBridgingHeaderVersionNumber;

//! Project version string for monitorhubBridgingHeader.
FOUNDATION_EXPORT const unsigned char monitorhubBridgingHeaderVersionString[];

#import <vpaassdk/monitorhub/VPMonitorhubAppInfo.h>
#import <vpaassdk/monitorhub/VPMonitorhubExtInfo.h>
#import <vpaassdk/monitorhub/VPMonitorhubStatusType.h>
#import <vpaassdk/monitorhub/VPMonitorhubNetType.h>
#import <vpaassdk/monitorhub/VPMonitorhubDeviceType.h>
#import <vpaassdk/monitorhub/VPMonitorhubBizType.h>
#import <vpaassdk/monitorhub/VPMonitorhubHeartbeatCallback.h>
#import <vpaassdk/monitorhub/VPMonitorhubTraceType.h>
#import <vpaassdk/monitorhub/VPMonitorhubReportModel.h>
#import <vpaassdk/monitorhub/VPMonitorhubStsTokenModel.h>
#import <vpaassdk/monitorhub/VPMonitorhubSlsConfigModel.h>
#import <vpaassdk/monitorhub/VPMonitorhubReportConfig.h>
#import <vpaassdk/monitorhub/VPMonitorhubModule.h>
#import <vpaassdk/monitorhub/VPMonitorhubMetric.h>
#import <vpaassdk/monitorhub/VPMonitorhubEvent.h>
#import <vpaassdk/monitorhub/VPMonitorhubField.h>
#import <vpaassdk/monitorhub/VPMonitorhubProcedure.h>
/* optimized_djinni_generated_objc_file */