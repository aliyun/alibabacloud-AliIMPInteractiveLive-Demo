// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建转码任务响应
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCCreateDocConversionTaskRsp : NSObject
- (nonnull instancetype)initWithTargetDocId:(nonnull NSString *)targetDocId;
+ (nonnull instancetype)VPDOCCreateDocConversionTaskRspWithTargetDocId:(nonnull NSString *)targetDocId;

/**
 * @param target_doc_id 转码目标文档ID
 */
@property (nonatomic, nonnull) NSString * targetDocId;

@end
/* optimized_djinni_generated_objc_file */