// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateChatReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId;
+ (nonnull instancetype)VPROOMCreateChatReqWithRoomId:(nonnull NSString *)roomId;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

@end
/* optimized_djinni_generated_objc_file */