// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/easyutils/VPEASYUTILSExportDelc.h>
#import <Foundation/Foundation.h>

VPEASYUTILS_OBJECTC_EXPORT
@interface VPEasyutilsEncryptDecryptDataResult : NSObject
- (nonnull instancetype)initWithOk:(BOOL)ok
                              data:(nonnull NSData *)data;
+ (nonnull instancetype)VPEasyutilsEncryptDecryptDataResultWithOk:(BOOL)ok
                                                             data:(nonnull NSData *)data;

@property (nonatomic) BOOL ok;

@property (nonatomic, nonnull) NSData * data;

@end
/* optimized_djinni_generated_objc_file */