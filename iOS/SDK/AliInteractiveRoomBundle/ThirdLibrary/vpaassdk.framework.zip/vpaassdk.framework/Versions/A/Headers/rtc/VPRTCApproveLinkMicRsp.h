// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 同意/拒绝申请连麦响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCApproveLinkMicRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCApproveLinkMicRsp;

@end
/* optimized_djinni_generated_objc_file */