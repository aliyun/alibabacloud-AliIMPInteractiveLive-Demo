// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建转码任务请求
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCCreateDocConversionTaskReq : NSObject
- (nonnull instancetype)initWithSourceDocId:(nonnull NSString *)sourceDocId
                                 targetType:(nonnull NSString *)targetType
                                 targetName:(nonnull NSString *)targetName
                                     roomId:(nonnull NSString *)roomId;
+ (nonnull instancetype)VPDOCCreateDocConversionTaskReqWithSourceDocId:(nonnull NSString *)sourceDocId
                                                            targetType:(nonnull NSString *)targetType
                                                            targetName:(nonnull NSString *)targetName
                                                                roomId:(nonnull NSString *)roomId;

/**
 * @param source_doc_id 必填，源文档ID
 */
@property (nonatomic, nonnull) NSString * sourceDocId;

/**
 * @param target_type 必填，转码类型：pdf,png,jpg
 */
@property (nonatomic, nonnull) NSString * targetType;

/**
 * @param target_name 必填，目标文档名称
 */
@property (nonatomic, nonnull) NSString * targetName;

/**
 * @param room_id 可选，房间Id，用于进行房间鉴权和可靠消息发送
 */
@property (nonatomic, nonnull) NSString * roomId;

@end
/* optimized_djinni_generated_objc_file */