// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播观看开始上报响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEStartLiveTimingRsp : NSObject
- (nonnull instancetype)initWithSuccess:(BOOL)success;
+ (nonnull instancetype)VPLIVEStartLiveTimingRspWithSuccess:(BOOL)success;

/**
 * @param success 上报成功
 */
@property (nonatomic) BOOL success;

@end
/* optimized_djinni_generated_objc_file */