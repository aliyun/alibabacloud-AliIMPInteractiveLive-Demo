// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <vpaassdk/live/VPLIVEUserLiveStatistics.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取直播观看人员信息响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEGetLiveUserStatisticsRsp : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
               userLiveStatisticList:(nonnull NSArray<VPLIVEUserLiveStatistics *> *)userLiveStatisticList
                             hasMore:(BOOL)hasMore;
+ (nonnull instancetype)VPLIVEGetLiveUserStatisticsRspWithUuid:(nonnull NSString *)uuid
                                         userLiveStatisticList:(nonnull NSArray<VPLIVEUserLiveStatistics *> *)userLiveStatisticList
                                                       hasMore:(BOOL)hasMore;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param user_live_statistic_list 用户信息列表
 */
@property (nonatomic, nonnull) NSArray<VPLIVEUserLiveStatistics *> * userLiveStatisticList;

/**
 * @param has_more 有更多用户
 */
@property (nonatomic) BOOL hasMore;

@end
/* optimized_djinni_generated_objc_file */