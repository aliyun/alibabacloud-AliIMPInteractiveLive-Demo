// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上传反馈请求
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIAnswerUploadReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
                         productName:(nonnull NSString *)productName
                           ossObject:(nonnull NSString *)ossObject
                              bucket:(nonnull NSString *)bucket
                            shelfIds:(nonnull NSArray<NSString *> *)shelfIds;
+ (nonnull instancetype)VPMETA_AIAnswerUploadReqWithUuid:(nonnull NSString *)uuid
                                             productName:(nonnull NSString *)productName
                                               ossObject:(nonnull NSString *)ossObject
                                                  bucket:(nonnull NSString *)bucket
                                                shelfIds:(nonnull NSArray<NSString *> *)shelfIds;

/**
 * @param uuid 商品uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param product_name 商品名字
 */
@property (nonatomic, nonnull) NSString * productName;

/**
 * @param oss_object bucket下object路径
 */
@property (nonatomic, nonnull) NSString * ossObject;

/**
 * @param bucket bucket
 */
@property (nonatomic, nonnull) NSString * bucket;

/**
 * @param shelf_ids 货架ID
 */
@property (nonatomic, nonnull) NSArray<NSString *> * shelfIds;

@end
/* optimized_djinni_generated_objc_file */