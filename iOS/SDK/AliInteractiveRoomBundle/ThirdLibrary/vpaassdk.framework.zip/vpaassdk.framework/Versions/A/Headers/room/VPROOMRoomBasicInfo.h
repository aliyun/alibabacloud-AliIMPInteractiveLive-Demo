// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 房间信息
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMRoomBasicInfo : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                 title:(nonnull NSString *)title
                               ownerId:(nonnull NSString *)ownerId
                                domain:(nonnull NSString *)domain;
+ (nonnull instancetype)VPROOMRoomBasicInfoWithRoomId:(nonnull NSString *)roomId
                                                title:(nonnull NSString *)title
                                              ownerId:(nonnull NSString *)ownerId
                                               domain:(nonnull NSString *)domain;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param title 房间标题名字
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param owner_id 房主的用户id
 */
@property (nonatomic, nonnull) NSString * ownerId;

/**
 * @param domain 应用ID，同appId
 */
@property (nonatomic, nonnull) NSString * domain;

@end
/* optimized_djinni_generated_objc_file */