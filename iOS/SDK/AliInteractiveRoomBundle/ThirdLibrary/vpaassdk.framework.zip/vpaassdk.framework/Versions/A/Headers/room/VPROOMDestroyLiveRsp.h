// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyLiveRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPROOMDestroyLiveRsp;

@end
/* optimized_djinni_generated_objc_file */