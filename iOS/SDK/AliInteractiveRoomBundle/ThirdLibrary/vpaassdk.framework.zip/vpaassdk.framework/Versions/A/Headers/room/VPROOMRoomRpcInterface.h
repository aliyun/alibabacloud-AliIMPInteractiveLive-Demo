// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMCreateInstanceReq.h>
#import <vpaassdk/room/VPROOMCreateInstanceRsp.h>
#import <vpaassdk/room/VPROOMDestroyInstanceReq.h>
#import <vpaassdk/room/VPROOMDestroyInstanceRsp.h>
#import <vpaassdk/room/VPROOMEnterRoomReq.h>
#import <vpaassdk/room/VPROOMEnterRoomRsp.h>
#import <vpaassdk/room/VPROOMGetRoomDetailReq.h>
#import <vpaassdk/room/VPROOMGetRoomDetailRsp.h>
#import <vpaassdk/room/VPROOMGetRoomListReq.h>
#import <vpaassdk/room/VPROOMGetRoomListRsp.h>
#import <vpaassdk/room/VPROOMGetRoomUserListReq.h>
#import <vpaassdk/room/VPROOMGetRoomUserListRsp.h>
#import <vpaassdk/room/VPROOMKickRoomUserReq.h>
#import <vpaassdk/room/VPROOMKickRoomUserRsp.h>
#import <vpaassdk/room/VPROOMLeaveRoomReq.h>
#import <vpaassdk/room/VPROOMLeaveRoomRsp.h>
#import <vpaassdk/room/VPROOMUpdateRoomNoticeReq.h>
#import <vpaassdk/room/VPROOMUpdateRoomNoticeRsp.h>
#import <vpaassdk/room/VPROOMUpdateRoomTitleReq.h>
#import <vpaassdk/room/VPROOMUpdateRoomTitleRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPROOMCreateInstanceCb;
@protocol VPROOMDestroyInstanceCb;
@protocol VPROOMEnterRoomCb;
@protocol VPROOMGetRoomDetailCb;
@protocol VPROOMGetRoomListCb;
@protocol VPROOMGetRoomUserListCb;
@protocol VPROOMKickRoomUserCb;
@protocol VPROOMLeaveRoomCb;
@protocol VPROOMUpdateRoomNoticeCb;
@protocol VPROOMUpdateRoomTitleCb;


@interface VPROOMRoomRpcInterface : NSObject

/**
 * @brief 用户进入房间
 */
- (void)enterRoom:(nonnull VPROOMEnterRoomReq *)req
         callback:(nullable id<VPROOMEnterRoomCb>)callback;

- (void)enterRoomWithBlock:(nonnull VPROOMEnterRoomReq *) req
                 onSuccess:(nullable void(^)(VPROOMEnterRoomRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 用户离开房间
 */
- (void)leaveRoom:(nonnull VPROOMLeaveRoomReq *)req
         callback:(nullable id<VPROOMLeaveRoomCb>)callback;

- (void)leaveRoomWithBlock:(nonnull VPROOMLeaveRoomReq *) req
                 onSuccess:(nullable void(^)(VPROOMLeaveRoomRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取房间详细信息
 */
- (void)getRoomDetail:(nonnull VPROOMGetRoomDetailReq *)req
             callback:(nullable id<VPROOMGetRoomDetailCb>)callback;

- (void)getRoomDetailWithBlock:(nonnull VPROOMGetRoomDetailReq *) req
                     onSuccess:(nullable void(^)(VPROOMGetRoomDetailRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 更新房间标题
 */
- (void)updateRoomTitle:(nonnull VPROOMUpdateRoomTitleReq *)req
               callback:(nullable id<VPROOMUpdateRoomTitleCb>)callback;

- (void)updateRoomTitleWithBlock:(nonnull VPROOMUpdateRoomTitleReq *) req
                       onSuccess:(nullable void(^)(VPROOMUpdateRoomTitleRsp * _Nonnull rsp))onSuccess
                       onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 更新房间公告
 */
- (void)updateRoomNotice:(nonnull VPROOMUpdateRoomNoticeReq *)req
                callback:(nullable id<VPROOMUpdateRoomNoticeCb>)callback;

- (void)updateRoomNoticeWithBlock:(nonnull VPROOMUpdateRoomNoticeReq *) req
                        onSuccess:(nullable void(^)(VPROOMUpdateRoomNoticeRsp * _Nonnull rsp))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 踢出用户
 */
- (void)kickRoomUser:(nonnull VPROOMKickRoomUserReq *)req
            callback:(nullable id<VPROOMKickRoomUserCb>)callback;

- (void)kickRoomUserWithBlock:(nonnull VPROOMKickRoomUserReq *) req
                    onSuccess:(nullable void(^)(VPROOMKickRoomUserRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 分页获取房间用户在线列表
 */
- (void)getRoomUserList:(nonnull VPROOMGetRoomUserListReq *)req
               callback:(nullable id<VPROOMGetRoomUserListCb>)callback;

- (void)getRoomUserListWithBlock:(nonnull VPROOMGetRoomUserListReq *) req
                       onSuccess:(nullable void(^)(VPROOMGetRoomUserListRsp * _Nonnull rsp))onSuccess
                       onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 分页获取房间的在线列表
 */
- (void)getRoomList:(nonnull VPROOMGetRoomListReq *)req
           callback:(nullable id<VPROOMGetRoomListCb>)callback;

- (void)getRoomListWithBlock:(nonnull VPROOMGetRoomListReq *) req
                   onSuccess:(nullable void(^)(VPROOMGetRoomListRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 创建插件实例
 */
- (void)createInstance:(nonnull VPROOMCreateInstanceReq *)req
              callback:(nullable id<VPROOMCreateInstanceCb>)callback;

- (void)createInstanceWithBlock:(nonnull VPROOMCreateInstanceReq *) req
                      onSuccess:(nullable void(^)(VPROOMCreateInstanceRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 销毁插件实例
 */
- (void)destroyInstance:(nonnull VPROOMDestroyInstanceReq *)req
               callback:(nullable id<VPROOMDestroyInstanceCb>)callback;

- (void)destroyInstanceWithBlock:(nonnull VPROOMDestroyInstanceReq *) req
                       onSuccess:(nullable void(^)(VPROOMDestroyInstanceRsp * _Nonnull rsp))onSuccess
                       onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */