// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 暂停白板录制请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBPauseWhiteboardRecordingReq : NSObject
- (nonnull instancetype)initWithDocKey:(nonnull NSString *)docKey
                              recordId:(nonnull NSString *)recordId;
+ (nonnull instancetype)VPWBPauseWhiteboardRecordingReqWithDocKey:(nonnull NSString *)docKey
                                                         recordId:(nonnull NSString *)recordId;

/**
 * @param doc_key 需要录制的白板文档标识符
 */
@property (nonatomic, nonnull) NSString * docKey;

/**
 * @param record_id 录制唯一标识
 */
@property (nonatomic, nonnull) NSString * recordId;

@end
/* optimized_djinni_generated_objc_file */