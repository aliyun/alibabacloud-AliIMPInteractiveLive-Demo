// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建插件实例请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateInstanceReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                              pluginId:(nonnull NSString *)pluginId
                             extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPROOMCreateInstanceReqWithRoomId:(nonnull NSString *)roomId
                                                 pluginId:(nonnull NSString *)pluginId
                                                extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param plugin_id 插件id
 */
@property (nonatomic, nonnull) NSString * pluginId;

/**
 * @param extension 扩展字段，这个由客户端和具体的原子能力服务端沟通
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */