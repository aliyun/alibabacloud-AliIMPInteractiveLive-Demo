// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 禁言某位用户请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATMuteUserReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                               muteUser:(nonnull NSString *)muteUser
                               muteTime:(int32_t)muteTime;
+ (nonnull instancetype)VPCHATMuteUserReqWithTopicId:(nonnull NSString *)topicId
                                            muteUser:(nonnull NSString *)muteUser
                                            muteTime:(int32_t)muteTime;

/**
 * @param topic_id 话题id,聊天插件实例id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param mute_user 需要禁言的用户列表
 */
@property (nonatomic, nonnull) NSString * muteUser;

/**
 * @param mute_time 禁言的时间，单位为s，如果不传或者传0则采用默认禁言时间
 */
@property (nonatomic) int32_t muteTime;

@end
/* optimized_djinni_generated_objc_file */