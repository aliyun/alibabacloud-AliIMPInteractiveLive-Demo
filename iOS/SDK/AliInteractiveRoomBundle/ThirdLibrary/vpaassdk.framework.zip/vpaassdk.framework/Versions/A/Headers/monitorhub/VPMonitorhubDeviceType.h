// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubDeviceType : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubDeviceType;

@end

extern NSString * __nonnull const VPMonitorhubDeviceTypeIos;
extern NSString * __nonnull const VPMonitorhubDeviceTypeAndroid;
extern NSString * __nonnull const VPMonitorhubDeviceTypeWeb;
extern NSString * __nonnull const VPMonitorhubDeviceTypeWin;
extern NSString * __nonnull const VPMonitorhubDeviceTypeMac;
/* optimized_djinni_generated_objc_file */