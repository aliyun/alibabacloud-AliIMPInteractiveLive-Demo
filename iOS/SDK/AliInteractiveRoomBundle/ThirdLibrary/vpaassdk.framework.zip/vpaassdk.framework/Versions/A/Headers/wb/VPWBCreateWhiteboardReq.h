// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建白板请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBCreateWhiteboardReq : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPWBCreateWhiteboardReq;

@end
/* optimized_djinni_generated_objc_file */