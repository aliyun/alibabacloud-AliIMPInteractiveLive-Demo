// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <vpaassdk/wb/VPWBPageInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板页码上报响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBReportWhiteboardPageOperateRsp : NSObject
- (nonnull instancetype)initWithPageList:(nonnull NSArray<VPWBPageInfo *> *)pageList
                   intraPageResourceList:(nonnull NSArray<VPWBPageInfo *> *)intraPageResourceList;
+ (nonnull instancetype)VPWBReportWhiteboardPageOperateRspWithPageList:(nonnull NSArray<VPWBPageInfo *> *)pageList
                                                 intraPageResourceList:(nonnull NSArray<VPWBPageInfo *> *)intraPageResourceList;

/**
 * @param page_list 页码信息
 */
@property (nonatomic, nonnull) NSArray<VPWBPageInfo *> * pageList;

/**
 * @param intra_page_resource_list 页内资源列表
 */
@property (nonatomic, nonnull) NSArray<VPWBPageInfo *> * intraPageResourceList;

@end
/* optimized_djinni_generated_objc_file */