// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 商品信息
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIProductInfo : NSObject
- (nonnull instancetype)initWithProductName:(nonnull NSString *)productName
                                       uuid:(nonnull NSString *)uuid
                         productDescription:(nonnull NSString *)productDescription
                              processStatus:(int32_t)processStatus
                                 createTime:(int64_t)createTime
                                 updateTime:(int64_t)updateTime;
+ (nonnull instancetype)VPMETA_AIProductInfoWithProductName:(nonnull NSString *)productName
                                                       uuid:(nonnull NSString *)uuid
                                         productDescription:(nonnull NSString *)productDescription
                                              processStatus:(int32_t)processStatus
                                                 createTime:(int64_t)createTime
                                                 updateTime:(int64_t)updateTime;

/**
 * @param product_name 商品名字
 */
@property (nonatomic, nonnull) NSString * productName;

/**
 * @param uuid 商品uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param product_description 商品描述
 */
@property (nonatomic, nonnull) NSString * productDescription;

/**
 * @param process_status 后处理状态
 */
@property (nonatomic) int32_t processStatus;

/**
 * @param create_time 创建时间
 */
@property (nonatomic) int64_t createTime;

/**
 * @param update_time 修改时间
 */
@property (nonatomic) int64_t updateTime;

@end
/* optimized_djinni_generated_objc_file */