// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AICreateModelRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 创建商品任务回调
 */
@protocol VPMETA_AICreateCb

- (void)onSuccess:(nonnull VPMETA_AICreateModelRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */