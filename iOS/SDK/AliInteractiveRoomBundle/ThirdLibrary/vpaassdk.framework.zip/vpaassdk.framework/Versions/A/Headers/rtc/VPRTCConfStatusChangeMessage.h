// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfInfoModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 会议状态变更消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCConfStatusChangeMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              status:(int32_t)status
                            confInfo:(nonnull VPRTCConfInfoModel *)confInfo;
+ (nonnull instancetype)VPRTCConfStatusChangeMessageWithType:(int32_t)type
                                                     version:(int64_t)version
                                                      status:(int32_t)status
                                                    confInfo:(nonnull VPRTCConfInfoModel *)confInfo;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param status 会议最新状态
 */
@property (nonatomic) int32_t status;

/**
 * @param conf_info 会议详情
 */
@property (nonatomic, nonnull) VPRTCConfInfoModel * confInfo;

@end
/* optimized_djinni_generated_objc_file */