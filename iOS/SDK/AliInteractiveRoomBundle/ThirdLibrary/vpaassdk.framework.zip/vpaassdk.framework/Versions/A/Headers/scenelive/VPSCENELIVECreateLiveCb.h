// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVESceneCreateLiveRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 创建直播回调
 */
@protocol VPSCENELIVECreateLiveCb

- (void)onSuccess:(nonnull VPSCENELIVESceneCreateLiveRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */