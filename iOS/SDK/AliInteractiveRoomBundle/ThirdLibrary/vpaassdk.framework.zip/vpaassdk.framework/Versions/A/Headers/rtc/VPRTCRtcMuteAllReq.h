// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 全员禁音/取消全员禁音请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCRtcMuteAllReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                                  open:(BOOL)open;
+ (nonnull instancetype)VPRTCRtcMuteAllReqWithConfId:(nonnull NSString *)confId
                                                open:(BOOL)open;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param open false:禁音，true:取消禁音
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */