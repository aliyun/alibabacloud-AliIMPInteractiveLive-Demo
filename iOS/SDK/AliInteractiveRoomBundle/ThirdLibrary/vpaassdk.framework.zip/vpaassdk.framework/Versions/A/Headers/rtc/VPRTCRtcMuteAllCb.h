// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCRtcMuteAllRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 全员禁音/取消全员禁音回调
 */
@protocol VPRTCRtcMuteAllCb

- (void)onSuccess:(nonnull VPRTCRtcMuteAllRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */