// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 销毁插件实例请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyInstanceReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                              pluginId:(nonnull NSString *)pluginId
                            instanceId:(nonnull NSString *)instanceId;
+ (nonnull instancetype)VPROOMDestroyInstanceReqWithRoomId:(nonnull NSString *)roomId
                                                  pluginId:(nonnull NSString *)pluginId
                                                instanceId:(nonnull NSString *)instanceId;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param plugin_id 插件id
 */
@property (nonatomic, nonnull) NSString * pluginId;

/**
 * @param instance_id 实例id
 */
@property (nonatomic, nonnull) NSString * instanceId;

@end
/* optimized_djinni_generated_objc_file */