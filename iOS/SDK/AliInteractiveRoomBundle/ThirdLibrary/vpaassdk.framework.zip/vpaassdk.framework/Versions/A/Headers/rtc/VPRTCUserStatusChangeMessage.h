// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 成员状态变更消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCUserStatusChangeMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                            userList:(nonnull NSArray<VPRTCConfUserModel *> *)userList;
+ (nonnull instancetype)VPRTCUserStatusChangeMessageWithType:(int32_t)type
                                                     version:(int64_t)version
                                                      confId:(nonnull NSString *)confId
                                                    userList:(nonnull NSArray<VPRTCConfUserModel *> *)userList;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_list 用户状态变更成员信息
 */
@property (nonatomic, nonnull) NSArray<VPRTCConfUserModel *> * userList;

@end
/* optimized_djinni_generated_objc_file */