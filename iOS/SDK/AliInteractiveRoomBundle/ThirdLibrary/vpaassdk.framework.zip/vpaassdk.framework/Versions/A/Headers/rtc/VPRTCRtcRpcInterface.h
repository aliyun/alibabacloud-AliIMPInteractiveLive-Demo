// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCAddMembersReq.h>
#import <vpaassdk/rtc/VPRTCAddMembersRsp.h>
#import <vpaassdk/rtc/VPRTCApplyLinkMicReq.h>
#import <vpaassdk/rtc/VPRTCApplyLinkMicRsp.h>
#import <vpaassdk/rtc/VPRTCApproveLinkMicReq.h>
#import <vpaassdk/rtc/VPRTCApproveLinkMicRsp.h>
#import <vpaassdk/rtc/VPRTCCheckAllowJoinReq.h>
#import <vpaassdk/rtc/VPRTCCheckAllowJoinRsp.h>
#import <vpaassdk/rtc/VPRTCGetConfDetailReq.h>
#import <vpaassdk/rtc/VPRTCGetConfDetailRsp.h>
#import <vpaassdk/rtc/VPRTCGetTokenReq.h>
#import <vpaassdk/rtc/VPRTCGetTokenRsp.h>
#import <vpaassdk/rtc/VPRTCKickMembersReq.h>
#import <vpaassdk/rtc/VPRTCKickMembersRsp.h>
#import <vpaassdk/rtc/VPRTCListApplyLinkMicUserReq.h>
#import <vpaassdk/rtc/VPRTCListApplyLinkMicUserRsp.h>
#import <vpaassdk/rtc/VPRTCListConfUserReq.h>
#import <vpaassdk/rtc/VPRTCListConfUserRsp.h>
#import <vpaassdk/rtc/VPRTCOperateCameraReq.h>
#import <vpaassdk/rtc/VPRTCOperateCameraRsp.h>
#import <vpaassdk/rtc/VPRTCPushLiveStreamReq.h>
#import <vpaassdk/rtc/VPRTCPushLiveStreamRsp.h>
#import <vpaassdk/rtc/VPRTCReportJoinStatusReq.h>
#import <vpaassdk/rtc/VPRTCReportJoinStatusRsp.h>
#import <vpaassdk/rtc/VPRTCReportLeaveStatusReq.h>
#import <vpaassdk/rtc/VPRTCReportLeaveStatusRsp.h>
#import <vpaassdk/rtc/VPRTCReportRtcMuteReq.h>
#import <vpaassdk/rtc/VPRTCReportRtcMuteRsp.h>
#import <vpaassdk/rtc/VPRTCRtcMuteAllReq.h>
#import <vpaassdk/rtc/VPRTCRtcMuteAllRsp.h>
#import <vpaassdk/rtc/VPRTCRtcMuteUserReq.h>
#import <vpaassdk/rtc/VPRTCRtcMuteUserRsp.h>
#import <vpaassdk/rtc/VPRTCSetCustomLayoutReq.h>
#import <vpaassdk/rtc/VPRTCSetCustomLayoutRsp.h>
#import <vpaassdk/rtc/VPRTCSetLayoutReq.h>
#import <vpaassdk/rtc/VPRTCSetLayoutRsp.h>
#import <vpaassdk/rtc/VPRTCShareScreenReq.h>
#import <vpaassdk/rtc/VPRTCShareScreenRsp.h>
#import <vpaassdk/rtc/VPRTCStartRecordReq.h>
#import <vpaassdk/rtc/VPRTCStartRecordRsp.h>
#import <vpaassdk/rtc/VPRTCStopLiveStreamReq.h>
#import <vpaassdk/rtc/VPRTCStopLiveStreamRsp.h>
#import <vpaassdk/rtc/VPRTCStopRecordReq.h>
#import <vpaassdk/rtc/VPRTCStopRecordRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPRTCAddMembersCb;
@protocol VPRTCApplyLinkMicCb;
@protocol VPRTCApproveLinkMicCb;
@protocol VPRTCCheckAllowJoinCb;
@protocol VPRTCGetConfDetailCb;
@protocol VPRTCGetTokenCb;
@protocol VPRTCKickMembersCb;
@protocol VPRTCListApplyLinkMicUserCb;
@protocol VPRTCListConfUserCb;
@protocol VPRTCOperateCameraCb;
@protocol VPRTCPushLiveStreamCb;
@protocol VPRTCReportJoinStatusCb;
@protocol VPRTCReportLeaveStatusCb;
@protocol VPRTCReportRtcMuteCb;
@protocol VPRTCRtcMuteAllCb;
@protocol VPRTCRtcMuteUserCb;
@protocol VPRTCSetCustomLayoutCb;
@protocol VPRTCSetLayoutCb;
@protocol VPRTCShareScreenCb;
@protocol VPRTCStartRecordCb;
@protocol VPRTCStopLiveStreamCb;
@protocol VPRTCStopRecordCb;


@interface VPRTCRtcRpcInterface : NSObject

/**
 * @brief 获取入会token
 */
- (void)getToken:(nonnull VPRTCGetTokenReq *)req
        callback:(nullable id<VPRTCGetTokenCb>)callback;

- (void)getTokenWithBlock:(nonnull VPRTCGetTokenReq *) req
                onSuccess:(nullable void(^)(VPRTCGetTokenRsp * _Nonnull rsp))onSuccess
                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上报入会状态
 */
- (void)reportJoinStatus:(nonnull VPRTCReportJoinStatusReq *)req
                callback:(nullable id<VPRTCReportJoinStatusCb>)callback;

- (void)reportJoinStatusWithBlock:(nonnull VPRTCReportJoinStatusReq *) req
                        onSuccess:(nullable void(^)(VPRTCReportJoinStatusRsp * _Nonnull rsp))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上报离会状态
 */
- (void)reportLeaveStatus:(nonnull VPRTCReportLeaveStatusReq *)req
                 callback:(nullable id<VPRTCReportLeaveStatusCb>)callback;

- (void)reportLeaveStatusWithBlock:(nonnull VPRTCReportLeaveStatusReq *) req
                         onSuccess:(nullable void(^)(VPRTCReportLeaveStatusRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 启动旁路推流
 */
- (void)pushLiveStream:(nonnull VPRTCPushLiveStreamReq *)req
              callback:(nullable id<VPRTCPushLiveStreamCb>)callback;

- (void)pushLiveStreamWithBlock:(nonnull VPRTCPushLiveStreamReq *) req
                      onSuccess:(nullable void(^)(VPRTCPushLiveStreamRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 停止旁路推流
 */
- (void)stopLiveStream:(nonnull VPRTCStopLiveStreamReq *)req
              callback:(nullable id<VPRTCStopLiveStreamCb>)callback;

- (void)stopLiveStreamWithBlock:(nonnull VPRTCStopLiveStreamReq *) req
                      onSuccess:(nullable void(^)(VPRTCStopLiveStreamRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 设置布局
 */
- (void)setLayout:(nonnull VPRTCSetLayoutReq *)req
         callback:(nullable id<VPRTCSetLayoutCb>)callback;

- (void)setLayoutWithBlock:(nonnull VPRTCSetLayoutReq *) req
                 onSuccess:(nullable void(^)(VPRTCSetLayoutRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 设置自定义布局
 */
- (void)setCustomLayout:(nonnull VPRTCSetCustomLayoutReq *)req
               callback:(nullable id<VPRTCSetCustomLayoutCb>)callback;

- (void)setCustomLayoutWithBlock:(nonnull VPRTCSetCustomLayoutReq *) req
                       onSuccess:(nullable void(^)(VPRTCSetCustomLayoutRsp * _Nonnull rsp))onSuccess
                       onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 邀请人
 */
- (void)addMembers:(nonnull VPRTCAddMembersReq *)req
          callback:(nullable id<VPRTCAddMembersCb>)callback;

- (void)addMembersWithBlock:(nonnull VPRTCAddMembersReq *) req
                  onSuccess:(nullable void(^)(VPRTCAddMembersRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 踢人
 */
- (void)kickMembers:(nonnull VPRTCKickMembersReq *)req
           callback:(nullable id<VPRTCKickMembersCb>)callback;

- (void)kickMembersWithBlock:(nonnull VPRTCKickMembersReq *) req
                   onSuccess:(nullable void(^)(VPRTCKickMembersRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取会议详情
 */
- (void)getConfDetail:(nonnull VPRTCGetConfDetailReq *)req
             callback:(nullable id<VPRTCGetConfDetailCb>)callback;

- (void)getConfDetailWithBlock:(nonnull VPRTCGetConfDetailReq *) req
                     onSuccess:(nullable void(^)(VPRTCGetConfDetailRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 申请/取消申请连麦
 */
- (void)applyLinkMic:(nonnull VPRTCApplyLinkMicReq *)req
            callback:(nullable id<VPRTCApplyLinkMicCb>)callback;

- (void)applyLinkMicWithBlock:(nonnull VPRTCApplyLinkMicReq *) req
                    onSuccess:(nullable void(^)(VPRTCApplyLinkMicRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 同意/拒绝申请连麦
 */
- (void)approveLinkMic:(nonnull VPRTCApproveLinkMicReq *)req
              callback:(nullable id<VPRTCApproveLinkMicCb>)callback;

- (void)approveLinkMicWithBlock:(nonnull VPRTCApproveLinkMicReq *) req
                      onSuccess:(nullable void(^)(VPRTCApproveLinkMicRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取会议成员列表
 */
- (void)listConfUser:(nonnull VPRTCListConfUserReq *)req
            callback:(nullable id<VPRTCListConfUserCb>)callback;

- (void)listConfUserWithBlock:(nonnull VPRTCListConfUserReq *) req
                    onSuccess:(nullable void(^)(VPRTCListConfUserRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取申请连麦成员列表
 */
- (void)listApplyLinkMicUser:(nonnull VPRTCListApplyLinkMicUserReq *)req
                    callback:(nullable id<VPRTCListApplyLinkMicUserCb>)callback;

- (void)listApplyLinkMicUserWithBlock:(nonnull VPRTCListApplyLinkMicUserReq *) req
                            onSuccess:(nullable void(^)(VPRTCListApplyLinkMicUserRsp * _Nonnull rsp))onSuccess
                            onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开始录制
 */
- (void)startRecord:(nonnull VPRTCStartRecordReq *)req
           callback:(nullable id<VPRTCStartRecordCb>)callback;

- (void)startRecordWithBlock:(nonnull VPRTCStartRecordReq *) req
                   onSuccess:(nullable void(^)(VPRTCStartRecordRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 停止录制
 */
- (void)stopRecord:(nonnull VPRTCStopRecordReq *)req
          callback:(nullable id<VPRTCStopRecordCb>)callback;

- (void)stopRecordWithBlock:(nonnull VPRTCStopRecordReq *) req
                  onSuccess:(nullable void(^)(VPRTCStopRecordRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上报单人禁音/取消禁音
 */
- (void)reportRtcMute:(nonnull VPRTCReportRtcMuteReq *)req
             callback:(nullable id<VPRTCReportRtcMuteCb>)callback;

- (void)reportRtcMuteWithBlock:(nonnull VPRTCReportRtcMuteReq *) req
                     onSuccess:(nullable void(^)(VPRTCReportRtcMuteRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 全员禁音/取消全员禁音
 */
- (void)rtcMuteAll:(nonnull VPRTCRtcMuteAllReq *)req
          callback:(nullable id<VPRTCRtcMuteAllCb>)callback;

- (void)rtcMuteAllWithBlock:(nonnull VPRTCRtcMuteAllReq *) req
                  onSuccess:(nullable void(^)(VPRTCRtcMuteAllRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开启/关闭摄像头
 */
- (void)operateCamera:(nonnull VPRTCOperateCameraReq *)req
             callback:(nullable id<VPRTCOperateCameraCb>)callback;

- (void)operateCameraWithBlock:(nonnull VPRTCOperateCameraReq *) req
                     onSuccess:(nullable void(^)(VPRTCOperateCameraRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 开启/结束共享桌面
 */
- (void)shareScreen:(nonnull VPRTCShareScreenReq *)req
           callback:(nullable id<VPRTCShareScreenCb>)callback;

- (void)shareScreenWithBlock:(nonnull VPRTCShareScreenReq *) req
                   onSuccess:(nullable void(^)(VPRTCShareScreenRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 命令单人禁音/取消禁音
 */
- (void)rtcMuteUser:(nonnull VPRTCRtcMuteUserReq *)req
           callback:(nullable id<VPRTCRtcMuteUserCb>)callback;

- (void)rtcMuteUserWithBlock:(nonnull VPRTCRtcMuteUserReq *) req
                   onSuccess:(nullable void(^)(VPRTCRtcMuteUserRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 检测能否入会
 */
- (void)checkAllowJoin:(nonnull VPRTCCheckAllowJoinReq *)req
              callback:(nullable id<VPRTCCheckAllowJoinCb>)callback;

- (void)checkAllowJoinWithBlock:(nonnull VPRTCCheckAllowJoinReq *) req
                      onSuccess:(nullable void(^)(VPRTCCheckAllowJoinRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */