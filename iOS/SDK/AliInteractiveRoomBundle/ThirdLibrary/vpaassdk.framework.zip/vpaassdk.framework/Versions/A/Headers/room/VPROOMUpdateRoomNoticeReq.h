// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新房间公告请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMUpdateRoomNoticeReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                notice:(nonnull NSString *)notice;
+ (nonnull instancetype)VPROOMUpdateRoomNoticeReqWithRoomId:(nonnull NSString *)roomId
                                                     notice:(nonnull NSString *)notice;

/**
 * @param room_id 房间id,必传
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param notice 房间公告
 */
@property (nonatomic, nonnull) NSString * notice;

@end
/* optimized_djinni_generated_objc_file */