// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// wb_Bridging_Header.h
// wb_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for wbBridgingHeader.
FOUNDATION_EXPORT double wbBridgingHeaderVersionNumber;

//! Project version string for wbBridgingHeader.
FOUNDATION_EXPORT const unsigned char wbBridgingHeaderVersionString[];

#import <vpaassdk/wb/VPWBWbModule.h>
#import <vpaassdk/wb/VPWBWbExtInterface.h>
#import <vpaassdk/wb/VPWBCreateWhiteboardCb.h>
#import <vpaassdk/wb/VPWBOpenWhiteboardCb.h>
#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateCb.h>
#import <vpaassdk/wb/VPWBGetWhiteboardPageInfoCb.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardPageCb.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardDocCb.h>
#import <vpaassdk/wb/VPWBStartWhiteboardRecordingCb.h>
#import <vpaassdk/wb/VPWBStopWhiteboardRecordingCb.h>
#import <vpaassdk/wb/VPWBPauseWhiteboardRecordingCb.h>
#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingCb.h>
#import <vpaassdk/wb/VPWBWbRpcInterface.h>
#import <vpaassdk/wb/VPWBCreateWhiteboardReq.h>
#import <vpaassdk/wb/VPWBCreateWhiteboardRsp.h>
#import <vpaassdk/wb/VPWBOpenWhiteboardReq.h>
#import <vpaassdk/wb/VPWBOpenWhiteboardRsp.h>
#import <vpaassdk/wb/VPWBWhiteboardAccessInfo.h>
#import <vpaassdk/wb/VPWBWhiteboardUserInfo.h>
#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateReq.h>
#import <vpaassdk/wb/VPWBReportWhiteboardPageOperateRsp.h>
#import <vpaassdk/wb/VPWBGetWhiteboardPageInfoReq.h>
#import <vpaassdk/wb/VPWBGetWhiteboardPageInfoRsp.h>
#import <vpaassdk/wb/VPWBPageInfo.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardPageReq.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardPageRsp.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardDocReq.h>
#import <vpaassdk/wb/VPWBDeleteWhiteboardDocRsp.h>
#import <vpaassdk/wb/VPWBStartWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBStartWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBStopWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBStopWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBPauseWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBPauseWhiteboardRecordingRsp.h>
#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingReq.h>
#import <vpaassdk/wb/VPWBResumeWhiteboardRecordingRsp.h>
/* optimized_djinni_generated_objc_file */