// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateRtcReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                              anchorId:(nonnull NSString *)anchorId
                        anchorNickname:(nonnull NSString *)anchorNickname
                                 title:(nonnull NSString *)title
                          preStartTime:(int64_t)preStartTime
                            preEndTime:(int64_t)preEndTime
                             extension:(nonnull NSString *)extension;
+ (nonnull instancetype)VPROOMCreateRtcReqWithRoomId:(nonnull NSString *)roomId
                                            anchorId:(nonnull NSString *)anchorId
                                      anchorNickname:(nonnull NSString *)anchorNickname
                                               title:(nonnull NSString *)title
                                        preStartTime:(int64_t)preStartTime
                                          preEndTime:(int64_t)preEndTime
                                           extension:(nonnull NSString *)extension;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNickname;

/**
 * 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * 预计开始时间,秒
 */
@property (nonatomic) int64_t preStartTime;

/**
 * 预计结束时间,秒
 */
@property (nonatomic) int64_t preEndTime;

/**
 *扩展信息
 */
@property (nonatomic, nonnull) NSString * extension;

@end
/* optimized_djinni_generated_objc_file */