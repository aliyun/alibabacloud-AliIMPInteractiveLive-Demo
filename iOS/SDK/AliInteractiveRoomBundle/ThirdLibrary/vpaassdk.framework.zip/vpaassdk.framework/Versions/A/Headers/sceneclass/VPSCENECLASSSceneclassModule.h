// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPSCENECLASSSceneclassExtInterface;
@class VPSCENECLASSSceneclassModule;
@class VPSCENECLASSSceneclassRpcInterface;


VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSSceneclassModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPSCENECLASSSceneclassModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPSCENECLASSSceneclassRpcInterface *)getRpcInterface;

- (nullable VPSCENECLASSSceneclassExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */