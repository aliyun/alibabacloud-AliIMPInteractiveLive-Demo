// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板用户信息
 */
VPWB_OBJECTC_EXPORT
@interface VPWBWhiteboardUserInfo : NSObject
- (nonnull instancetype)initWithUserId:(nonnull NSString *)userId
                             avatarUrl:(nonnull NSString *)avatarUrl
                                  nick:(nonnull NSString *)nick
                            nickPinyin:(nonnull NSString *)nickPinyin;
+ (nonnull instancetype)VPWBWhiteboardUserInfoWithUserId:(nonnull NSString *)userId
                                               avatarUrl:(nonnull NSString *)avatarUrl
                                                    nick:(nonnull NSString *)nick
                                              nickPinyin:(nonnull NSString *)nickPinyin;

/**
 * @param user_id 用户ID
 */
@property (nonatomic, nonnull) NSString * userId;

/**
 * @param avatar_url 头像图片地址
 */
@property (nonatomic, nonnull) NSString * avatarUrl;

/**
 * @param nick 昵称
 */
@property (nonatomic, nonnull) NSString * nick;

/**
 * @param nick_pinyin 昵称拼音
 */
@property (nonatomic, nonnull) NSString * nickPinyin;

@end
/* optimized_djinni_generated_objc_file */