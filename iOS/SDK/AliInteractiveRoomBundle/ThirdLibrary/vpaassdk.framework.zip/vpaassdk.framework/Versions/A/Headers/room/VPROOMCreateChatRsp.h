// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateChatRsp : NSObject
- (nonnull instancetype)initWithChatId:(nonnull NSString *)chatId;
+ (nonnull instancetype)VPROOMCreateChatRspWithChatId:(nonnull NSString *)chatId;

/**
 *chat id
 */
@property (nonatomic, nonnull) NSString * chatId;

@end
/* optimized_djinni_generated_objc_file */