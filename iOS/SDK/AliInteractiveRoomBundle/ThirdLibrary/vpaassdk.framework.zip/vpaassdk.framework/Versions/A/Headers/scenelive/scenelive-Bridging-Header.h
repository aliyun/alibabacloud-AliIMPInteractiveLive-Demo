// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// scenelive_Bridging_Header.h
// scenelive_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for sceneliveBridgingHeader.
FOUNDATION_EXPORT double sceneliveBridgingHeaderVersionNumber;

//! Project version string for sceneliveBridgingHeader.
FOUNDATION_EXPORT const unsigned char sceneliveBridgingHeaderVersionString[];

#import <vpaassdk/scenelive/VPSCENELIVESceneliveModule.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneliveExtInterface.h>
#import <vpaassdk/scenelive/VPSCENELIVECreateLiveCb.h>
#import <vpaassdk/scenelive/VPSCENELIVEStopLiveCb.h>
#import <vpaassdk/scenelive/VPSCENELIVEUpdateLiveCb.h>
#import <vpaassdk/scenelive/VPSCENELIVEGetLiveDetailCb.h>
#import <vpaassdk/scenelive/VPSCENELIVEGetLiveListCb.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneliveRpcInterface.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneCreateLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneCreateLiveRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVEPluginInstanceInfo.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneStopLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneStopLiveRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneUpdateLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneUpdateLiveRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveDetailReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveDetailRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVEArtcInfo.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveListReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveListRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneLiveInfoModel.h>
/* optimized_djinni_generated_objc_file */