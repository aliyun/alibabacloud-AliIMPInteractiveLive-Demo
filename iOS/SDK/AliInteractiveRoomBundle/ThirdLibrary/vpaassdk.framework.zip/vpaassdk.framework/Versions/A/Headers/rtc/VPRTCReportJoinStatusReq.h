// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报入会状态请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCReportJoinStatusReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                              sourceId:(nonnull NSString *)sourceId
                              nickname:(nonnull NSString *)nickname
                            joinStatus:(int32_t)joinStatus
                             errorCode:(nonnull NSString *)errorCode
                          cameraStatus:(int32_t)cameraStatus
                        micphoneStatus:(int32_t)micphoneStatus;
+ (nonnull instancetype)VPRTCReportJoinStatusReqWithConfId:(nonnull NSString *)confId
                                                  sourceId:(nonnull NSString *)sourceId
                                                  nickname:(nonnull NSString *)nickname
                                                joinStatus:(int32_t)joinStatus
                                                 errorCode:(nonnull NSString *)errorCode
                                              cameraStatus:(int32_t)cameraStatus
                                            micphoneStatus:(int32_t)micphoneStatus;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param source_id 底层媒体用户ID
 */
@property (nonatomic, nonnull) NSString * sourceId;

/**
 * @param nickname 用户昵称
 */
@property (nonatomic, nonnull) NSString * nickname;

/**
 * @param join_status 入会状态，3：成功，4:失败
 */
@property (nonatomic) int32_t joinStatus;

/**
 * @param error_code 失败错误码
 */
@property (nonatomic, nonnull) NSString * errorCode;

/**
 * @param camera_status camera状态，服务端透传，0：关闭，1：打开
 */
@property (nonatomic) int32_t cameraStatus;

/**
 * @param micphone_status mic状态，服务端透传，0：关闭，1：打开
 */
@property (nonatomic) int32_t micphoneStatus;

@end
/* optimized_djinni_generated_objc_file */