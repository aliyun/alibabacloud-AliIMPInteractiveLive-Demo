// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建商品请求
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AICreateModelReq : NSObject
- (nonnull instancetype)initWithProductName:(nonnull NSString *)productName;
+ (nonnull instancetype)VPMETA_AICreateModelReqWithProductName:(nonnull NSString *)productName;

/**
 * @param product_name 商品名
 */
@property (nonatomic, nonnull) NSString * productName;

@end
/* optimized_djinni_generated_objc_file */