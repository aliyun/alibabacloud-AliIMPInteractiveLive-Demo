// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * 上报字段定义
 */
VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubField : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubField;

@end

/**
 * MonitorHub内部保留关键字段 
 */
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyMetricName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyIts;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyTraceType;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyTraceId;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyEventName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyProcedureName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyErrorCode;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldMonitorhubKeyErrorMsg;
/**
 * 通用字段
 */
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonAppid;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonAppName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonAppVer;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonUid;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonOsName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonOsVer;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonDeviceId;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonDeviceType;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonDeviceName;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonRoomId;
extern NSString * __nonnull const VPMonitorhubFieldMhfieldCommonPaassdkVer;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonBizType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonBizId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonNetType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonTargetUid;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonCdnIp;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPushUrl;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPullUrl;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonEncodec;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonEncoder;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonDecodec;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonDecoder;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonCostTime;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonExtParam;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonSample;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonProfile;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonChannel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonCLASS;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonLIVE;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRTC;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRTMP;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonHLS;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonFLV;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRTS;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonVOD;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonNOTSTART;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPLATFORMWIN;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPLATFORMMAC;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPLATFORMWEB;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPLATFORMIOS;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPLATFORMANDROID;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonReason;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonInfo;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonModule;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonDuration;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonStatus;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonProtoType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonTraceId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonLiveUrl;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonPlayType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonContentId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonEngine;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonCode;
/**
 * rtc 扩展字段定义，主要用于RTC 心中的内容上报
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcChannelId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcCallDuration;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcLastmileDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcRcvdBytes;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcRcvdExpectedPkts;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcRcvdKBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcRcvdLossPkts;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcRcvdLossRate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcSentBytes;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcSentExpectedPkts;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcSentKBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcSentLossPkts;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcSentLossRate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoRcvdKBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoSentKBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoSentFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoDecodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoFrozenTimes;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcVideoRenderFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioInputLevel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioNumChannel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioSentSamplerate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioLossRate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioJitterBufferDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioNetworkTransportDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioQuality;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioRcvdBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldCommonRtcAudioTotalFrozenTimes;
/**
 * PaasSDK-系统信息-心跳数据 paassdk.sysinfo.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoCpuName;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoCpuCores;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoCpuUsageSys;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoCpuUsageProc;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoGpuName;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoSysMemSize;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoSysMem;
extern NSString * __nonnull const VPMonitorhubFieldMffieldSysinfoAppMem;
/**
 * PaasSDK-音视频-事件数据 paassdk.rtc.act
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcActShareAudio;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcActRtcId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcUserList;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcJoinStatus;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcLiveId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcLiveStatus;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcApply;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcSourceType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcLiveTranscodingState;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcLiveTranscodingErrorCode;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcUpQuality;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkRtcDownQuality;
/**
 * PaasSDK-白板-事件数据 paassdk.wb.act
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActWhiteboardId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActRecordId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActRequestId;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActStartTime;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActPauseTime;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActStopTime;
extern NSString * __nonnull const VPMonitorhubFieldMffieldPaassdkWbActResumeTime;
/**
 * 互动直播-主播-心跳数据   live.anchor.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoCaptureFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoSendFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoSendBuffer;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoDropFrames;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoSkipFrames;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoQp;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartVideoPsnr;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartAudioEncodeBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartAudioSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAnchorHeartAudioVolume;
/**
 *互动直播-观众-心跳数据   live.audience.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoCaptureFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoSendFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoSendBuffer;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoDropFrames;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoSkipFrames;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoQp;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartVideoPsnr;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartAudioEncodeBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartAudioSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteVideoWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteVideoHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteVideoRenderFrames;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteVideoRenderFramesAvg;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioQuality;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioNetworkTransportDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioJitterBufferDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioLossRate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioRcvdBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldLiveAudienceHeartRemoteAudioTotalFrozenTimes;
/**
 *互动课堂-学生-心跳数据   class.student.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraSentFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartCameraCaptureFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenSentFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartScreenCaptureFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioEncodeBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioSendFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioAudioSentSamplerate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioNumChannel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioInputLevel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartAudioDesktopAudio;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteVideoWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteVideoHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteVideoDecodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteVideoRenderFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteVideoFrozenTimes;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioQuality;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioNetworkTransportDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioJitterBufferDelay;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioLossRate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioRcvdBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassStudentHeartRemoteAudioTotalFrozenTimes;
/**
 *互动课堂-老师-心跳数据  class.teacher.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartCameraWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartCameraHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartCameraSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartCameraSentFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartCameraEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartScreenWidth;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartScreenHeight;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartScreenSentBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartScreenSentFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartScreenEncodeFps;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioEncodeBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioSendBitrate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioAudioSentSamplerate;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioNumChannel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioInputLevel;
extern NSString * __nonnull const VPMonitorhubFieldMffieldClassTeacherHeartAudioDesktopAudio;
/**
 * 客户端-MetaPath-链路-事件数据 metapath.client.link.act
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActConnState;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActEngineType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActNetType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActLinkType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActEndpoint;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActDstIp;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActDstPort;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActTTotal;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActTUsed;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActTryCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT1;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT2;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT3;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT4;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT5;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT6;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT7;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT8;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT9;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActT10;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkActEvtCnt;
/**
 *客户端-MetaPath-链路-心跳数据 metapath.client.link.heart
 */
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartLinkType;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcTaskCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcOkCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcFailCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcFailUrl;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcFailCode;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcApiFailCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcApiFailUrl;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcReqCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcRspCnt;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcAvgTime;
extern NSString * __nonnull const VPMonitorhubFieldMffieldMetapathClientLinkHeartRpcMaxUseTime;
/* optimized_djinni_generated_objc_file */