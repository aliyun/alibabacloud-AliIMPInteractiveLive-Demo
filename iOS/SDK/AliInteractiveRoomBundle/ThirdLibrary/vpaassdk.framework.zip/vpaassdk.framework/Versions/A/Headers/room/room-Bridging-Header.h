// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// room_Bridging_Header.h
// room_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for roomBridgingHeader.
FOUNDATION_EXPORT double roomBridgingHeaderVersionNumber;

//! Project version string for roomBridgingHeader.
FOUNDATION_EXPORT const unsigned char roomBridgingHeaderVersionString[];

#import <vpaassdk/room/VPROOMRoomModule.h>
#import <vpaassdk/room/VPROOMCreateLiveCb.h>
#import <vpaassdk/room/VPROOMDestroyLiveCb.h>
#import <vpaassdk/room/VPROOMCreateRtcCb.h>
#import <vpaassdk/room/VPROOMDestroyRtcCb.h>
#import <vpaassdk/room/VPROOMCreateChatCb.h>
#import <vpaassdk/room/VPROOMDestroyChatCb.h>
#import <vpaassdk/room/VPROOMCreateWhiteboardCb.h>
#import <vpaassdk/room/VPROOMDestroyWhiteboardCb.h>
#import <vpaassdk/room/VPROOMRoomExtInterface.h>
#import <vpaassdk/room/VPROOMRoomNotificationModel.h>
#import <vpaassdk/room/VPROOMRoomNotificationListener.h>
#import <vpaassdk/room/VPROOMCreateLiveReq.h>
#import <vpaassdk/room/VPROOMCreateLiveRsp.h>
#import <vpaassdk/room/VPROOMDestroyLiveReq.h>
#import <vpaassdk/room/VPROOMDestroyLiveRsp.h>
#import <vpaassdk/room/VPROOMCreateRtcReq.h>
#import <vpaassdk/room/VPROOMCreateRtcRsp.h>
#import <vpaassdk/room/VPROOMDestroyRtcReq.h>
#import <vpaassdk/room/VPROOMDestroyRtcRsp.h>
#import <vpaassdk/room/VPROOMCreateChatReq.h>
#import <vpaassdk/room/VPROOMCreateChatRsp.h>
#import <vpaassdk/room/VPROOMDestroyChatReq.h>
#import <vpaassdk/room/VPROOMDestroyChatRsp.h>
#import <vpaassdk/room/VPROOMCreateWhiteboardReq.h>
#import <vpaassdk/room/VPROOMCreateWhiteboardRsp.h>
#import <vpaassdk/room/VPROOMDestroyWhiteboardReq.h>
#import <vpaassdk/room/VPROOMDestroyWhiteboardRsp.h>
#import <vpaassdk/room/VPROOMEnterRoomCb.h>
#import <vpaassdk/room/VPROOMLeaveRoomCb.h>
#import <vpaassdk/room/VPROOMGetRoomDetailCb.h>
#import <vpaassdk/room/VPROOMUpdateRoomTitleCb.h>
#import <vpaassdk/room/VPROOMUpdateRoomNoticeCb.h>
#import <vpaassdk/room/VPROOMKickRoomUserCb.h>
#import <vpaassdk/room/VPROOMGetRoomUserListCb.h>
#import <vpaassdk/room/VPROOMGetRoomListCb.h>
#import <vpaassdk/room/VPROOMCreateInstanceCb.h>
#import <vpaassdk/room/VPROOMDestroyInstanceCb.h>
#import <vpaassdk/room/VPROOMRoomRpcInterface.h>
#import <vpaassdk/room/VPROOMEnterRoomReq.h>
#import <vpaassdk/room/VPROOMEnterRoomRsp.h>
#import <vpaassdk/room/VPROOMLeaveRoomReq.h>
#import <vpaassdk/room/VPROOMLeaveRoomRsp.h>
#import <vpaassdk/room/VPROOMUpdateRoomTitleReq.h>
#import <vpaassdk/room/VPROOMUpdateRoomTitleRsp.h>
#import <vpaassdk/room/VPROOMUpdateRoomNoticeReq.h>
#import <vpaassdk/room/VPROOMUpdateRoomNoticeRsp.h>
#import <vpaassdk/room/VPROOMGetRoomDetailReq.h>
#import <vpaassdk/room/VPROOMPluginInstance.h>
#import <vpaassdk/room/VPROOMGetRoomDetailRsp.h>
#import <vpaassdk/room/VPROOMKickRoomUserReq.h>
#import <vpaassdk/room/VPROOMKickRoomUserRsp.h>
#import <vpaassdk/room/VPROOMGetRoomUserListReq.h>
#import <vpaassdk/room/VPROOMGetRoomUserListRsp.h>
#import <vpaassdk/room/VPROOMRoomUserModel.h>
#import <vpaassdk/room/VPROOMGetRoomListRsp.h>
#import <vpaassdk/room/VPROOMGetRoomListReq.h>
#import <vpaassdk/room/VPROOMRoomBasicInfo.h>
#import <vpaassdk/room/VPROOMCreateInstanceReq.h>
#import <vpaassdk/room/VPROOMCreateInstanceRsp.h>
#import <vpaassdk/room/VPROOMDestroyInstanceReq.h>
#import <vpaassdk/room/VPROOMDestroyInstanceRsp.h>
/* optimized_djinni_generated_objc_file */