// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 命令消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCCommandMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                         commandType:(int32_t)commandType
                      commandContent:(nonnull NSString *)commandContent
                         commandUser:(nonnull VPRTCConfUserModel *)commandUser;
+ (nonnull instancetype)VPRTCCommandMessageWithType:(int32_t)type
                                            version:(int64_t)version
                                             confId:(nonnull NSString *)confId
                                        commandType:(int32_t)commandType
                                     commandContent:(nonnull NSString *)commandContent
                                        commandUser:(nonnull VPRTCConfUserModel *)commandUser;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param command_type 命令类型
 */
@property (nonatomic) int32_t commandType;

/**
 * @param command_content 命令内容
 */
@property (nonatomic, nonnull) NSString * commandContent;

/**
 * @param command_user 接收命令人员信息
 */
@property (nonatomic, nonnull) VPRTCConfUserModel * commandUser;

@end
/* optimized_djinni_generated_objc_file */