// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 禁言某位用户响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATMuteUserRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCHATMuteUserRsp;

@end
/* optimized_djinni_generated_objc_file */