// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 用户进入房间请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMEnterRoomReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                  nick:(nonnull NSString *)nick
                                  role:(nonnull NSString *)role
                             extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                               context:(nonnull NSDictionary<NSString *, NSString *> *)context;
+ (nonnull instancetype)VPROOMEnterRoomReqWithRoomId:(nonnull NSString *)roomId
                                                nick:(nonnull NSString *)nick
                                                role:(nonnull NSString *)role
                                           extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                             context:(nonnull NSDictionary<NSString *, NSString *> *)context;

/**
 * @param room_id 房间id,必传
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param nick 用户昵称,必传
 */
@property (nonatomic, nonnull) NSString * nick;

/**
 * @param role 用户角色，不传默认为观众
 */
@property (nonatomic, nonnull) NSString * role;

/**
 * @param extension 扩展字段，提供给客户使用
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param context 上下文字段，内部使用，不暴露给客户
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * context;

@end
/* optimized_djinni_generated_objc_file */