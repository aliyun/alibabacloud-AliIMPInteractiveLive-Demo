// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfInfoModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报入会状态响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCReportJoinStatusRsp : NSObject
- (nonnull instancetype)initWithConfInfo:(nonnull VPRTCConfInfoModel *)confInfo
                                 version:(int64_t)version
                   heartBeatPeriodMillis:(int64_t)heartBeatPeriodMillis;
+ (nonnull instancetype)VPRTCReportJoinStatusRspWithConfInfo:(nonnull VPRTCConfInfoModel *)confInfo
                                                     version:(int64_t)version
                                       heartBeatPeriodMillis:(int64_t)heartBeatPeriodMillis;

/**
 * @param conf_info 会议中成员列表
 */
@property (nonatomic, nonnull) VPRTCConfInfoModel * confInfo;

/**
 * @param version 会议状态信息版本号，用于解决客户端和服务器之间会议状态信息的版本不一致问题，会议本身状态变更及成员状态变更等会引起该版本号增长
 */
@property (nonatomic) int64_t version;

/**
 * @param heart_beat_period_millis 端上心跳间隔
 */
@property (nonatomic) int64_t heartBeatPeriodMillis;

@end
/* optimized_djinni_generated_objc_file */