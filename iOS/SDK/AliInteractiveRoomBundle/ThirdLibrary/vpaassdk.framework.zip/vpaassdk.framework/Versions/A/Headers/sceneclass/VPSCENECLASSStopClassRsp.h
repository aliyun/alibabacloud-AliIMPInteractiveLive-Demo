// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>

VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSStopClassRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPSCENECLASSStopClassRsp;

@end
/* optimized_djinni_generated_objc_file */