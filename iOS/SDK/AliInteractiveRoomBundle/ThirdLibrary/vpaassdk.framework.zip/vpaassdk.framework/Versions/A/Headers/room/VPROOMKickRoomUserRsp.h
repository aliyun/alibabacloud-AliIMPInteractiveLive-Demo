// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 踢出用户响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMKickRoomUserRsp : NSObject
- (nonnull instancetype)initWithInterval:(int32_t)interval;
+ (nonnull instancetype)VPROOMKickRoomUserRspWithInterval:(int32_t)interval;

/**
 * @param interval 禁止再次加入的时间
 */
@property (nonatomic) int32_t interval;

@end
/* optimized_djinni_generated_objc_file */