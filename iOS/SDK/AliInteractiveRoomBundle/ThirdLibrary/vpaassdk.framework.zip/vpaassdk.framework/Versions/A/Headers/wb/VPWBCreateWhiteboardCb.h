// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBCreateWhiteboardRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 创建白板回调
 */
@protocol VPWBCreateWhiteboardCb

- (void)onSuccess:(nonnull VPWBCreateWhiteboardRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */