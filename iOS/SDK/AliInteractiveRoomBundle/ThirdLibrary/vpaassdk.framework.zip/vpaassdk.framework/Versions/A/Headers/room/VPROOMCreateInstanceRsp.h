// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建插件实例响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateInstanceRsp : NSObject
- (nonnull instancetype)initWithInstanceId:(nonnull NSString *)instanceId
                                 extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPROOMCreateInstanceRspWithInstanceId:(nonnull NSString *)instanceId
                                                    extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param instance_id 实例id
 */
@property (nonatomic, nonnull) NSString * instanceId;

/**
 * @param extension 扩展属性
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */