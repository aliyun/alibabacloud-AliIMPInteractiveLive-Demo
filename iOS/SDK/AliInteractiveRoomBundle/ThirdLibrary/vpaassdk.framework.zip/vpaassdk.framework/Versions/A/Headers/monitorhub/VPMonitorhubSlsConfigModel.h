// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <vpaassdk/monitorhub/VPMonitorhubStsTokenModel.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubSlsConfigModel : NSObject
- (nonnull instancetype)initWithEndpoint:(nonnull NSString *)endpoint
                                 project:(nonnull NSString *)project
                                logStore:(nonnull NSString *)logStore
                                stsToken:(nonnull VPMonitorhubStsTokenModel *)stsToken;
+ (nonnull instancetype)VPMonitorhubSlsConfigModelWithEndpoint:(nonnull NSString *)endpoint
                                                       project:(nonnull NSString *)project
                                                      logStore:(nonnull NSString *)logStore
                                                      stsToken:(nonnull VPMonitorhubStsTokenModel *)stsToken;

@property (nonatomic, nonnull) NSString * endpoint;

@property (nonatomic, nonnull) NSString * project;

@property (nonatomic, nonnull) NSString * logStore;

/**
 * 如果使用SLS_SDK上报则需要ak/sk。
 */
@property (nonatomic, nonnull) VPMonitorhubStsTokenModel * stsToken;

@end
/* optimized_djinni_generated_objc_file */