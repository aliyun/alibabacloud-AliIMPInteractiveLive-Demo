// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 踢人请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCKickMembersReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                        kickedUserList:(nonnull NSArray<NSString *> *)kickedUserList;
+ (nonnull instancetype)VPRTCKickMembersReqWithConfId:(nonnull NSString *)confId
                                       kickedUserList:(nonnull NSArray<NSString *> *)kickedUserList;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param kicked_user_list 踢人列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * kickedUserList;

@end
/* optimized_djinni_generated_objc_file */