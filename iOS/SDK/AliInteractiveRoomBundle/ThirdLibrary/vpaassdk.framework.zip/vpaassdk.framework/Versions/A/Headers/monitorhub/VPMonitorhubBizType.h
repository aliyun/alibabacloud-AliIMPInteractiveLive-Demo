// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubBizType : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubBizType;

@end

extern NSString * __nonnull const VPMonitorhubBizTypeStandardClass;
extern NSString * __nonnull const VPMonitorhubBizTypeStandardLive;
extern NSString * __nonnull const VPMonitorhubBizTypeBasicSdk;
/* optimized_djinni_generated_objc_file */