// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// mps_Bridging_Header.h
// mps_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for mpsBridgingHeader.
FOUNDATION_EXPORT double mpsBridgingHeaderVersionNumber;

//! Project version string for mpsBridgingHeader.
FOUNDATION_EXPORT const unsigned char mpsBridgingHeaderVersionString[];

#import <vpaassdk/mps/VPMPSManager.h>
#import <vpaassdk/mps/VPMPSAuthTokenCallback.h>
#import <vpaassdk/mps/VPMPSSettingService.h>
#import <vpaassdk/mps/VPMPSEngineListener.h>
#import <vpaassdk/mps/VPMPSEngineStartListener.h>
#import <vpaassdk/mps/VPMPSManagerCreateListener.h>
#import <vpaassdk/mps/VPMPSReleaseManagerListener.h>
#import <vpaassdk/mps/VPMPSLogLevel.h>
#import <vpaassdk/mps/VPMPSLogHandler.h>
#import <vpaassdk/mps/VPMPSResetUserDataListener.h>
#import <vpaassdk/mps/VPMpsEngineType.h>
#import <vpaassdk/mps/VPMPSStatis.h>
#import <vpaassdk/mps/VPMPSEngine.h>
/* optimized_djinni_generated_objc_file */