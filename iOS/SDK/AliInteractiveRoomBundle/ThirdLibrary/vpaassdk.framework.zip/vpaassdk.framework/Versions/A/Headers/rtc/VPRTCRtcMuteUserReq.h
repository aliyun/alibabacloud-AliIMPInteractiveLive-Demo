// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 命令单人禁音/取消禁音请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCRtcMuteUserReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                                userId:(nonnull NSString *)userId
                                  open:(BOOL)open;
+ (nonnull instancetype)VPRTCRtcMuteUserReqWithConfId:(nonnull NSString *)confId
                                               userId:(nonnull NSString *)userId
                                                 open:(BOOL)open;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_id 目标UserId
 */
@property (nonatomic, nonnull) NSString * userId;

/**
 * @param open false:禁音，true:取消禁音
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */