// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新直播响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEUpdateLiveRsp : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid;
+ (nonnull instancetype)VPLIVEUpdateLiveRspWithUuid:(nonnull NSString *)uuid;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

@end
/* optimized_djinni_generated_objc_file */