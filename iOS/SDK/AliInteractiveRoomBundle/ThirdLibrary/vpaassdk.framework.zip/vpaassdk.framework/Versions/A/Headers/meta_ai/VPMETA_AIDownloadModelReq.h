// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 下载任务请求
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIDownloadModelReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid;
+ (nonnull instancetype)VPMETA_AIDownloadModelReqWithUuid:(nonnull NSString *)uuid;

/**
 * @param uuid bucket下object完整路径
 */
@property (nonatomic, nonnull) NSString * uuid;

@end
/* optimized_djinni_generated_objc_file */