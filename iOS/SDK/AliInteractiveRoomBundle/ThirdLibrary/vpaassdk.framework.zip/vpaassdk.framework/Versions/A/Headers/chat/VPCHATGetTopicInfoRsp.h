// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取TopicInfo响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATGetTopicInfoRsp : NSObject
- (nonnull instancetype)initWithLikeCount:(int32_t)likeCount
                             commentCount:(int32_t)commentCount
                                     mute:(BOOL)mute
                     sendCommentMaxLength:(int32_t)sendCommentMaxLength
                      sendCommentInterval:(int32_t)sendCommentInterval
                                  muteAll:(BOOL)muteAll;
+ (nonnull instancetype)VPCHATGetTopicInfoRspWithLikeCount:(int32_t)likeCount
                                              commentCount:(int32_t)commentCount
                                                      mute:(BOOL)mute
                                      sendCommentMaxLength:(int32_t)sendCommentMaxLength
                                       sendCommentInterval:(int32_t)sendCommentInterval
                                                   muteAll:(BOOL)muteAll;

/**
 * @param like_count 点赞数
 */
@property (nonatomic) int32_t likeCount;

/**
 * @param comment_count 评论数，暂未实现,返回0
 */
@property (nonatomic) int32_t commentCount;

/**
 * @param mute 请求用户是否被禁言
 */
@property (nonatomic) BOOL mute;

/**
 * @param send_comment_max_length 发送弹幕的最大长度
 */
@property (nonatomic) int32_t sendCommentMaxLength;

/**
 * @param send_comment_interval 发送弹幕的间隔时间(单位:ms)
 */
@property (nonatomic) int32_t sendCommentInterval;

/**
 * @param mute_all 是否受到全体禁言的影响(true:开启了全员禁言false:未开启全员禁言，目前仅有普通观众会被全体禁言)
 */
@property (nonatomic) BOOL muteAll;

@end
/* optimized_djinni_generated_objc_file */