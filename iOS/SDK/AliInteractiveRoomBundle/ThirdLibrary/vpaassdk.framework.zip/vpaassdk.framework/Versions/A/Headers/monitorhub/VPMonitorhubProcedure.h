// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * 上报过程定义
 */
typedef NS_ENUM(NSInteger, VPMonitorhubProcedure)
{
    /**
     * PaasSDK-音视频-事件数据 paassdk.rtc.act
     */
    VPMonitorhubProcedureMfprocPaassdkRtcActTest = 100,
};
/* optimized_djinni_generated_objc_file */