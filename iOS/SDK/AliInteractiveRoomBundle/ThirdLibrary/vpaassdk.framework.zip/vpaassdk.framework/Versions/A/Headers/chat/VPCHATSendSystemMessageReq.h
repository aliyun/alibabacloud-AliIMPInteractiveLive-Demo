// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发送系统消息请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendSystemMessageReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                                   body:(nonnull NSString *)body;
+ (nonnull instancetype)VPCHATSendSystemMessageReqWithTopicId:(nonnull NSString *)topicId
                                                         body:(nonnull NSString *)body;

/**
 * @param topic_id 话题id,聊天插件实例id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param body 消息体
 */
@property (nonatomic, nonnull) NSString * body;

@end
/* optimized_djinni_generated_objc_file */