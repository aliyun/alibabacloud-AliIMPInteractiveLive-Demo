// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取租户配置响应
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetAppConfigRsp : NSObject
- (nonnull instancetype)initWithConfigMap:(nonnull NSString *)configMap;
+ (nonnull instancetype)VPCLOUDCONFIGGetAppConfigRspWithConfigMap:(nonnull NSString *)configMap;

/**
 * @param config_map 租户配置，是一个json串
 */
@property (nonatomic, nonnull) NSString * configMap;

@end
/* optimized_djinni_generated_objc_file */