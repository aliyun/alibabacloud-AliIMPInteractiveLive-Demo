// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateWhiteboardRsp : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId;
+ (nonnull instancetype)VPROOMCreateWhiteboardRspWithWhiteboardId:(nonnull NSString *)whiteboardId;

/**
 * whiteboard id
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

@end
/* optimized_djinni_generated_objc_file */