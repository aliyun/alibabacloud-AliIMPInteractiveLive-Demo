// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 拉取商品请求
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIListModelReq : NSObject
- (nonnull instancetype)initWithShelfIds:(nonnull NSArray<NSString *> *)shelfIds;
+ (nonnull instancetype)VPMETA_AIListModelReqWithShelfIds:(nonnull NSArray<NSString *> *)shelfIds;

/**
 * @param shelf_ids 货架ID
 */
@property (nonatomic, nonnull) NSArray<NSString *> * shelfIds;

@end
/* optimized_djinni_generated_objc_file */