// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取直播详情请求
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEGetLiveDetailReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid;
+ (nonnull instancetype)VPLIVEGetLiveDetailReqWithUuid:(nonnull NSString *)uuid;

/**
 * @param uuid 直播uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

@end
/* optimized_djinni_generated_objc_file */