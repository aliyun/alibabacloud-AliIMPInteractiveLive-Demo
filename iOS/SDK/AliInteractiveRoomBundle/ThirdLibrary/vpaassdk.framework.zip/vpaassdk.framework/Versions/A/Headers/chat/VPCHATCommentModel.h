// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 弹幕数据
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATCommentModel : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                              commentId:(nonnull NSString *)commentId
                                   type:(int32_t)type
                              creatorId:(nonnull NSString *)creatorId
                            creatorNick:(nonnull NSString *)creatorNick
                                content:(nonnull NSString *)content
                               createAt:(int64_t)createAt
                              extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPCHATCommentModelWithTopicId:(nonnull NSString *)topicId
                                            commentId:(nonnull NSString *)commentId
                                                 type:(int32_t)type
                                            creatorId:(nonnull NSString *)creatorId
                                          creatorNick:(nonnull NSString *)creatorNick
                                              content:(nonnull NSString *)content
                                             createAt:(int64_t)createAt
                                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param topic_id 话题Id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param comment_id 弹幕Id
 */
@property (nonatomic, nonnull) NSString * commentId;

/**
 * @param type 弹幕类型，目前仅为0-普通文本弹幕
 */
@property (nonatomic) int32_t type;

/**
 * @param creator_id 弹幕发送者的id
 */
@property (nonatomic, nonnull) NSString * creatorId;

/**
 * @param creator_nick 弹幕发送者的昵称
 */
@property (nonatomic, nonnull) NSString * creatorNick;

/**
 * @param content 弹幕内容
 */
@property (nonatomic, nonnull) NSString * content;

/**
 * @param create_at 弹幕的创建时间
 */
@property (nonatomic) int64_t createAt;

/**
 * @param extension 发送的时候附带的扩展字段信息
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */