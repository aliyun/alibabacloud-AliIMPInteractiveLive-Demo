// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 布局模式
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCPane : NSObject
- (nonnull instancetype)initWithX:(float)x
                                y:(float)y
                            width:(float)width
                           height:(float)height
                           zOrder:(int32_t)zOrder
                           userId:(nonnull NSString *)userId;
+ (nonnull instancetype)VPRTCPaneWithX:(float)x
                                     y:(float)y
                                 width:(float)width
                                height:(float)height
                                zOrder:(int32_t)zOrder
                                userId:(nonnull NSString *)userId;

/**
 * @param x 必填，格子左上角x坐标，归一化后的百分比值,举例：对于宽为720像素，x=0.1，代表左上角x坐标为720*0.1=72像素
 */
@property (nonatomic) float x;

/**
 * @param y 必填，格子左上角y坐标，归一化后的百分比值
 */
@property (nonatomic) float y;

/**
 * @param width 必填，格子宽，归一化后的百分比值
 */
@property (nonatomic) float width;

/**
 * @param height 必填，格子高，归一化后的百分比值
 */
@property (nonatomic) float height;

/**
 * @param z_order 必填，格子zOrder，值越大，越在前
 */
@property (nonatomic) int32_t zOrder;

/**
 * @param user_id 可选，此格子展示用户，不填则会显示黑色
 */
@property (nonatomic, nonnull) NSString * userId;

@end
/* optimized_djinni_generated_objc_file */