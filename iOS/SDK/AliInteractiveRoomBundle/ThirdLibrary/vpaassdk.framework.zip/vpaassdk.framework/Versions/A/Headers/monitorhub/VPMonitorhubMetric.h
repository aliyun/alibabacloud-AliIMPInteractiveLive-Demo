// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * 上报项目名
 */
VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubMetric : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubMetric;

@end

/**
 * PaasSDK-音视频-事件数据 paassdk.rtc.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnPaassdkRtcAct;
/**
 * PaasSDK-音视频-心跳数据 paassdk.rtc.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnPaassdkRtcHeart;
/**
 * PaasSDK-白板-事件数据 paassdk.wb.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnPaassdkWbAct;
/**
 * PaasSDK-聊天-事件数据 paassdk.chat.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnPaassdkChatAct;
/**
 * PaasSDK-房间-事件数据 paassdk.room.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnPaassdkRoomAct;
/**
 * 客户端-直播业务-上行-事件数据 meta.client.publish.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaClientPublishAct;
/**
 * 客户端-直播业务-下行-事件数据 meta.client.play.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaClientPlayAct;
/**
 * 客户端-MetaPath-链路-事件数据 metapath.client.link.act
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetapathClientLinkAct;
/**
 *客户端-MetaPath-链路-心跳数据 metapath.client.link.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetapathClientLinkHeart;
/**
 *互动课堂-老师-心跳数据  class.teacher.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaClassTeacherHeart;
/**
 *互动课堂-学生-心跳数据  class.student.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaClassStudentHeart;
/**
 *互动直播-主播-心跳数据   live.anchor.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaLiveAnchorHeart;
/**
 *互动直播-观众-心跳数据   live.audience.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaLiveAudienceHeart;
/**
 *基础sdk-心跳数据    basic.sdk.heart
 */
extern NSString * __nonnull const VPMonitorhubMetricMhmnMetaBasicSdkHeart;
/* optimized_djinni_generated_objc_file */