// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报单人禁音/取消禁音请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCReportRtcMuteReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                                  open:(BOOL)open;
+ (nonnull instancetype)VPRTCReportRtcMuteReqWithConfId:(nonnull NSString *)confId
                                                   open:(BOOL)open;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param open false:禁音，true:取消禁音
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */