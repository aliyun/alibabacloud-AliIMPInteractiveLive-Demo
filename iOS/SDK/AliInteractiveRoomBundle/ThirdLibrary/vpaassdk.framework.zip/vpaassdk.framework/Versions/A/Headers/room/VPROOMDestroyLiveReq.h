// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyLiveReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                liveId:(nonnull NSString *)liveId;
+ (nonnull instancetype)VPROOMDestroyLiveReqWithRoomId:(nonnull NSString *)roomId
                                                liveId:(nonnull NSString *)liveId;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * 直播uuid
 */
@property (nonatomic, nonnull) NSString * liveId;

@end
/* optimized_djinni_generated_objc_file */