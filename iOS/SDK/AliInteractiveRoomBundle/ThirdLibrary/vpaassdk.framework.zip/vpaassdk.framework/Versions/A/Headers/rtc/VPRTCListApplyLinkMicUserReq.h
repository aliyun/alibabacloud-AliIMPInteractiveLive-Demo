// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取申请连麦列表请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCListApplyLinkMicUserReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                             pageIndex:(int32_t)pageIndex
                              pageSize:(int32_t)pageSize;
+ (nonnull instancetype)VPRTCListApplyLinkMicUserReqWithConfId:(nonnull NSString *)confId
                                                     pageIndex:(int32_t)pageIndex
                                                      pageSize:(int32_t)pageSize;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param page_index 页数下标，从1开始
 */
@property (nonatomic) int32_t pageIndex;

/**
 * @param page_size 每页的数据条数
 */
@property (nonatomic) int32_t pageSize;

@end
/* optimized_djinni_generated_objc_file */