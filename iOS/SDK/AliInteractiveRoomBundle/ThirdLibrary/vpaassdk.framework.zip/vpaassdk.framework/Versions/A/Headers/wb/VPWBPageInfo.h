// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 页码信息
 */
VPWB_OBJECTC_EXPORT
@interface VPWBPageInfo : NSObject
- (nonnull instancetype)initWithGroup:(nonnull NSString *)group
                       whiteboardPage:(int32_t)whiteboardPage
                            groupPage:(int32_t)groupPage
                                 type:(nonnull NSString *)type
                                  url:(nonnull NSString *)url;
+ (nonnull instancetype)VPWBPageInfoWithGroup:(nonnull NSString *)group
                               whiteboardPage:(int32_t)whiteboardPage
                                    groupPage:(int32_t)groupPage
                                         type:(nonnull NSString *)type
                                          url:(nonnull NSString *)url;

/**
 * @param group 页码所属分组
 */
@property (nonatomic, nonnull) NSString * group;

/**
 * @param whiteboard_page 白板页码
 */
@property (nonatomic) int32_t whiteboardPage;

/**
 * @param group_page 分组页码
 */
@property (nonatomic) int32_t groupPage;

/**
 * @param type 资源类型，page对应白板新的页，img对应插入的页内资源
 */
@property (nonatomic, nonnull) NSString * type;

/**
 * @param url 资源地址
 */
@property (nonatomic, nonnull) NSString * url;

@end
/* optimized_djinni_generated_objc_file */