// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneLiveInfoModel.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询直播列表响应
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneGetLiveListRsp : NSObject
- (nonnull instancetype)initWithLiveList:(nonnull NSArray<VPSCENELIVESceneLiveInfoModel *> *)liveList
                              totalCount:(int32_t)totalCount
                                 hasMore:(BOOL)hasMore
                               pageTotal:(int32_t)pageTotal;
+ (nonnull instancetype)VPSCENELIVESceneGetLiveListRspWithLiveList:(nonnull NSArray<VPSCENELIVESceneLiveInfoModel *> *)liveList
                                                        totalCount:(int32_t)totalCount
                                                           hasMore:(BOOL)hasMore
                                                         pageTotal:(int32_t)pageTotal;

/**
 * @param live_list 直播列表
 */
@property (nonatomic, nonnull) NSArray<VPSCENELIVESceneLiveInfoModel *> * liveList;

/**
 * @param total_count 直播总数
 */
@property (nonatomic) int32_t totalCount;

/**
 * @param has_more 是否还有下一页直播列表
 */
@property (nonatomic) BOOL hasMore;

/**
 * @param page_total 直播总页数
 */
@property (nonatomic) int32_t pageTotal;

@end
/* optimized_djinni_generated_objc_file */