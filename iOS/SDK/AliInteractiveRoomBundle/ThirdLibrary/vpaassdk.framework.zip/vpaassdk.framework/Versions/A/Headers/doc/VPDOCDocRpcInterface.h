// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCCreateDocConversionTaskReq.h>
#import <vpaassdk/doc/VPDOCCreateDocConversionTaskRsp.h>
#import <vpaassdk/doc/VPDOCCreateDocReq.h>
#import <vpaassdk/doc/VPDOCCreateDocRsp.h>
#import <vpaassdk/doc/VPDOCDownloadDocReq.h>
#import <vpaassdk/doc/VPDOCDownloadDocRsp.h>
#import <vpaassdk/doc/VPDOCGetDocReq.h>
#import <vpaassdk/doc/VPDOCGetDocRsp.h>
#import <vpaassdk/doc/VPDOCReportUploadStatusReq.h>
#import <vpaassdk/doc/VPDOCReportUploadStatusRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPDOCCreateDocCb;
@protocol VPDOCCreateDocConversionTaskCb;
@protocol VPDOCDownloadDocCb;
@protocol VPDOCGetDocCb;
@protocol VPDOCReportUploadStatusCb;


@interface VPDOCDocRpcInterface : NSObject

/**
 * @brief 创建文档
 */
- (void)createDoc:(nonnull VPDOCCreateDocReq *)req
         callback:(nullable id<VPDOCCreateDocCb>)callback;

- (void)createDocWithBlock:(nonnull VPDOCCreateDocReq *) req
                 onSuccess:(nullable void(^)(VPDOCCreateDocRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上报上传状态
 */
- (void)reportUploadStatus:(nonnull VPDOCReportUploadStatusReq *)req
                  callback:(nullable id<VPDOCReportUploadStatusCb>)callback;

- (void)reportUploadStatusWithBlock:(nonnull VPDOCReportUploadStatusReq *) req
                          onSuccess:(nullable void(^)(VPDOCReportUploadStatusRsp * _Nonnull rsp))onSuccess
                          onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取文档
 */
- (void)getDoc:(nonnull VPDOCGetDocReq *)req
      callback:(nullable id<VPDOCGetDocCb>)callback;

- (void)getDocWithBlock:(nonnull VPDOCGetDocReq *) req
              onSuccess:(nullable void(^)(VPDOCGetDocRsp * _Nonnull rsp))onSuccess
              onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 创建转码任务
 */
- (void)createDocConversionTask:(nonnull VPDOCCreateDocConversionTaskReq *)req
                       callback:(nullable id<VPDOCCreateDocConversionTaskCb>)callback;

- (void)createDocConversionTaskWithBlock:(nonnull VPDOCCreateDocConversionTaskReq *) req
                               onSuccess:(nullable void(^)(VPDOCCreateDocConversionTaskRsp * _Nonnull rsp))onSuccess
                               onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 下载文档
 */
- (void)downloadDoc:(nonnull VPDOCDownloadDocReq *)req
           callback:(nullable id<VPDOCDownloadDocCb>)callback;

- (void)downloadDocWithBlock:(nonnull VPDOCDownloadDocReq *) req
                   onSuccess:(nullable void(^)(VPDOCDownloadDocRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */