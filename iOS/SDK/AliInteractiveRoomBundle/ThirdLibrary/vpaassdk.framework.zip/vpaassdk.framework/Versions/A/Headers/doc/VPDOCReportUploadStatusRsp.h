// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报上传状态响应
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCReportUploadStatusRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPDOCReportUploadStatusRsp;

@end
/* optimized_djinni_generated_objc_file */