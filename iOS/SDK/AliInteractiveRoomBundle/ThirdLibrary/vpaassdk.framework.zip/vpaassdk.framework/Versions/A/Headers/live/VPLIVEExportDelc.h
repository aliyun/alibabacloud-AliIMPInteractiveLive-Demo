#if defined(VPLIVE_OBJECTC_EXPORT_ENABLE)
#define VPLIVE_OBJECTC_EXPORT  __attribute__((visibility("default")))
#else
#define VPLIVE_OBJECTC_EXPORT 
#endif/* optimized_djinni_generated_objc_file */