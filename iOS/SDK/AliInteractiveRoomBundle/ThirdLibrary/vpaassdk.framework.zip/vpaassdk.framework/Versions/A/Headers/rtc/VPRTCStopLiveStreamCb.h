// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCStopLiveStreamRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 停止旁路推流回调
 */
@protocol VPRTCStopLiveStreamCb

- (void)onSuccess:(nonnull VPRTCStopLiveStreamRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */