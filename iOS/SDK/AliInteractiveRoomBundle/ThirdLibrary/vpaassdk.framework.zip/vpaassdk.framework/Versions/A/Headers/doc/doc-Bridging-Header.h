// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// doc_Bridging_Header.h
// doc_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for docBridgingHeader.
FOUNDATION_EXPORT double docBridgingHeaderVersionNumber;

//! Project version string for docBridgingHeader.
FOUNDATION_EXPORT const unsigned char docBridgingHeaderVersionString[];

#import <vpaassdk/doc/VPDOCDocModule.h>
#import <vpaassdk/doc/VPDOCDocExtInterface.h>
#import <vpaassdk/doc/VPDOCCreateDocCb.h>
#import <vpaassdk/doc/VPDOCReportUploadStatusCb.h>
#import <vpaassdk/doc/VPDOCGetDocCb.h>
#import <vpaassdk/doc/VPDOCCreateDocConversionTaskCb.h>
#import <vpaassdk/doc/VPDOCDownloadDocCb.h>
#import <vpaassdk/doc/VPDOCDocRpcInterface.h>
#import <vpaassdk/doc/VPDOCCredentials.h>
#import <vpaassdk/doc/VPDOCCreateDocReq.h>
#import <vpaassdk/doc/VPDOCCreateDocRsp.h>
#import <vpaassdk/doc/VPDOCReportUploadStatusReq.h>
#import <vpaassdk/doc/VPDOCReportUploadStatusRsp.h>
#import <vpaassdk/doc/VPDOCGetDocReq.h>
#import <vpaassdk/doc/VPDOCGetDocRsp.h>
#import <vpaassdk/doc/VPDOCCreateDocConversionTaskReq.h>
#import <vpaassdk/doc/VPDOCCreateDocConversionTaskRsp.h>
#import <vpaassdk/doc/VPDOCDownloadDocReq.h>
#import <vpaassdk/doc/VPDOCDownloadDocRsp.h>
/* optimized_djinni_generated_objc_file */