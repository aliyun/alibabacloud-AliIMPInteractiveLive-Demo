// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上传反馈响应
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AIAnswerUploadRsp : NSObject
- (nonnull instancetype)initWithSuccess:(BOOL)success
                           errorMessage:(nonnull NSString *)errorMessage;
+ (nonnull instancetype)VPMETA_AIAnswerUploadRspWithSuccess:(BOOL)success
                                               errorMessage:(nonnull NSString *)errorMessage;

/**
 * @param success 创建成功
 */
@property (nonatomic) BOOL success;

/**
 * @param error_message 错误码
 */
@property (nonatomic, nonnull) NSString * errorMessage;

@end
/* optimized_djinni_generated_objc_file */