// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateRtcRsp : NSObject
- (nonnull instancetype)initWithConferenceId:(nonnull NSString *)conferenceId
                                 mediaConfig:(nonnull NSString *)mediaConfig
                                      source:(nonnull NSString *)source
                                    sourceId:(nonnull NSString *)sourceId;
+ (nonnull instancetype)VPROOMCreateRtcRspWithConferenceId:(nonnull NSString *)conferenceId
                                               mediaConfig:(nonnull NSString *)mediaConfig
                                                    source:(nonnull NSString *)source
                                                  sourceId:(nonnull NSString *)sourceId;

/**
 *会议id
 */
@property (nonatomic, nonnull) NSString * conferenceId;

/**
 *媒体sdk配置
 */
@property (nonatomic, nonnull) NSString * mediaConfig;

/**
 *引擎类型, alirtc/mcs
 */
@property (nonatomic, nonnull) NSString * source;

/**
 *引擎id
 */
@property (nonatomic, nonnull) NSString * sourceId;

@end
/* optimized_djinni_generated_objc_file */