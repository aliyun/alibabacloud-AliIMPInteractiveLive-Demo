// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfInfoModel.h>
#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 邀请消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCInviteMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              callee:(nonnull NSString *)callee
                              caller:(nonnull VPRTCConfUserModel *)caller
                            confInfo:(nonnull VPRTCConfInfoModel *)confInfo;
+ (nonnull instancetype)VPRTCInviteMessageWithType:(int32_t)type
                                           version:(int64_t)version
                                            callee:(nonnull NSString *)callee
                                            caller:(nonnull VPRTCConfUserModel *)caller
                                          confInfo:(nonnull VPRTCConfInfoModel *)confInfo;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param callee 被邀请者ID
 */
@property (nonatomic, nonnull) NSString * callee;

/**
 * @param caller 邀请者信息
 */
@property (nonatomic, nonnull) VPRTCConfUserModel * caller;

/**
 * @param conf_info 会议详情
 */
@property (nonatomic, nonnull) VPRTCConfInfoModel * confInfo;

@end
/* optimized_djinni_generated_objc_file */