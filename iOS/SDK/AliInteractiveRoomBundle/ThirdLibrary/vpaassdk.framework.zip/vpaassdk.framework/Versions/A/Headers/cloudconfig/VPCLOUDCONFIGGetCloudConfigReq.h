// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudConfigBaseInfo.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取云控配置请求
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetCloudConfigReq : NSObject
- (nonnull instancetype)initWithKeyList:(nonnull NSArray<NSString *> *)keyList
                               baseInfo:(nonnull VPCLOUDCONFIGCloudConfigBaseInfo *)baseInfo;
+ (nonnull instancetype)VPCLOUDCONFIGGetCloudConfigReqWithKeyList:(nonnull NSArray<NSString *> *)keyList
                                                         baseInfo:(nonnull VPCLOUDCONFIGCloudConfigBaseInfo *)baseInfo;

/**
 * @param key_list 请求云控的key列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * keyList;

/**
 * @param base_info 云控基本参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGCloudConfigBaseInfo * baseInfo;

@end
/* optimized_djinni_generated_objc_file */