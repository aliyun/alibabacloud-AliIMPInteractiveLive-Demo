// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATListBanCommentUsersRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 获取禁言的用户列表回调
 */
@protocol VPCHATListBanCommentUsersCb

- (void)onSuccess:(nonnull VPCHATListBanCommentUsersRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */