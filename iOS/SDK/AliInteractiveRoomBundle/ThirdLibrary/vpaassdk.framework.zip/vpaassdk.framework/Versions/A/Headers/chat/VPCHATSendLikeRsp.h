// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 点赞响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendLikeRsp : NSObject
- (nonnull instancetype)initWithInterval:(int32_t)interval
                               likeCount:(int32_t)likeCount;
+ (nonnull instancetype)VPCHATSendLikeRspWithInterval:(int32_t)interval
                                            likeCount:(int32_t)likeCount;

/**
 * @param interval 客户端多少秒聚合一次点赞发送的时间
 */
@property (nonatomic) int32_t interval;

/**
 * @param like_count 当前房间的点赞数
 */
@property (nonatomic) int32_t likeCount;

@end
/* optimized_djinni_generated_objc_file */