// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 踢出用户请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMKickRoomUserReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                              kickUser:(nonnull NSString *)kickUser
                             blockTime:(int32_t)blockTime;
+ (nonnull instancetype)VPROOMKickRoomUserReqWithRoomId:(nonnull NSString *)roomId
                                               kickUser:(nonnull NSString *)kickUser
                                              blockTime:(int32_t)blockTime;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param kick_user 被踢掉的用户id
 */
@property (nonatomic, nonnull) NSString * kickUser;

/**
 * @param block_time 被踢后允许再次进入房间时间间隔
 */
@property (nonatomic) int32_t blockTime;

@end
/* optimized_djinni_generated_objc_file */