// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMDestroyInstanceRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 销毁插件实例回调
 */
@protocol VPROOMDestroyInstanceCb

- (void)onSuccess:(nonnull VPROOMDestroyInstanceRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */