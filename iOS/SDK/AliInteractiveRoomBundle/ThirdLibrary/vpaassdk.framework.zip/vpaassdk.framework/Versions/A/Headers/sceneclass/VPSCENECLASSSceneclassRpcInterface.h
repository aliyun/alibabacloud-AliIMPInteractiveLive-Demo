// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSCreateClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSCreateClassRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSGetClassDetailReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSGetClassDetailRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStartClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStartClassRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStopClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStopClassRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPSCENECLASSCreateClassCb;
@protocol VPSCENECLASSGetClassDetailCb;
@protocol VPSCENECLASSStartClassCb;
@protocol VPSCENECLASSStopClassCb;


@interface VPSCENECLASSSceneclassRpcInterface : NSObject

/**
 * @brief 创建课
 */
- (void)createClass:(nonnull VPSCENECLASSCreateClassReq *)req
           callback:(nullable id<VPSCENECLASSCreateClassCb>)callback;

- (void)createClassWithBlock:(nonnull VPSCENECLASSCreateClassReq *) req
                   onSuccess:(nullable void(^)(VPSCENECLASSCreateClassRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 获取课详情
 */
- (void)getClassDetail:(nonnull VPSCENECLASSGetClassDetailReq *)req
              callback:(nullable id<VPSCENECLASSGetClassDetailCb>)callback;

- (void)getClassDetailWithBlock:(nonnull VPSCENECLASSGetClassDetailReq *) req
                      onSuccess:(nullable void(^)(VPSCENECLASSGetClassDetailRsp * _Nonnull rsp))onSuccess
                      onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上课
 */
- (void)startClass:(nonnull VPSCENECLASSStartClassReq *)req
          callback:(nullable id<VPSCENECLASSStartClassCb>)callback;

- (void)startClassWithBlock:(nonnull VPSCENECLASSStartClassReq *) req
                  onSuccess:(nullable void(^)(VPSCENECLASSStartClassRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 下课
 */
- (void)stopClass:(nonnull VPSCENECLASSStopClassReq *)req
         callback:(nullable id<VPSCENECLASSStopClassCb>)callback;

- (void)stopClassWithBlock:(nonnull VPSCENECLASSStopClassReq *) req
                 onSuccess:(nullable void(^)(VPSCENECLASSStopClassRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */