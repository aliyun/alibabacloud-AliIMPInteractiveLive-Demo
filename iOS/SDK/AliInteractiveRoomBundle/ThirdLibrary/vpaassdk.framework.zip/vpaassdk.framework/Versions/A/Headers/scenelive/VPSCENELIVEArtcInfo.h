// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief artc信息
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVEArtcInfo : NSObject
- (nonnull instancetype)initWithArtcUrl:(nonnull NSString *)artcUrl
                              artcH5Url:(nonnull NSString *)artcH5Url;
+ (nonnull instancetype)VPSCENELIVEArtcInfoWithArtcUrl:(nonnull NSString *)artcUrl
                                             artcH5Url:(nonnull NSString *)artcH5Url;

/**
 * @param artc_url RTS原码流地址，推荐移动端使用
 */
@property (nonatomic, nonnull) NSString * artcUrl;

/**
 * @param artc_h5_url RTS原码流地址，推荐web端使用
 */
@property (nonatomic, nonnull) NSString * artcH5Url;

@end
/* optimized_djinni_generated_objc_file */