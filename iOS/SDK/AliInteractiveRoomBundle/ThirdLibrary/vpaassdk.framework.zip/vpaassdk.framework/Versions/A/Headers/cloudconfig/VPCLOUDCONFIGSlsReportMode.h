// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGSlsReportMode : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCLOUDCONFIGSlsReportMode;

@end

extern NSString * __nonnull const VPCLOUDCONFIGSlsReportModeWebtracking;
extern NSString * __nonnull const VPCLOUDCONFIGSlsReportModeSdk;
/* optimized_djinni_generated_objc_file */