// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 全员静音消息模型
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCMuteAllMicMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                             muteAll:(BOOL)muteAll;
+ (nonnull instancetype)VPRTCMuteAllMicMessageWithType:(int32_t)type
                                               version:(int64_t)version
                                                confId:(nonnull NSString *)confId
                                               muteAll:(BOOL)muteAll;

/**
 * @param type 消息类型，取值：16
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param mute_all true：全员静音；false：取消全员静音
 */
@property (nonatomic) BOOL muteAll;

@end
/* optimized_djinni_generated_objc_file */