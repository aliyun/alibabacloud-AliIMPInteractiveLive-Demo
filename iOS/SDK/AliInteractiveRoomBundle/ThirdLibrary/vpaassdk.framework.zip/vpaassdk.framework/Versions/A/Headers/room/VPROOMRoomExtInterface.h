// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMCreateChatReq.h>
#import <vpaassdk/room/VPROOMCreateChatRsp.h>
#import <vpaassdk/room/VPROOMCreateLiveReq.h>
#import <vpaassdk/room/VPROOMCreateLiveRsp.h>
#import <vpaassdk/room/VPROOMCreateRtcReq.h>
#import <vpaassdk/room/VPROOMCreateRtcRsp.h>
#import <vpaassdk/room/VPROOMCreateWhiteboardReq.h>
#import <vpaassdk/room/VPROOMCreateWhiteboardRsp.h>
#import <vpaassdk/room/VPROOMDestroyChatReq.h>
#import <vpaassdk/room/VPROOMDestroyChatRsp.h>
#import <vpaassdk/room/VPROOMDestroyLiveReq.h>
#import <vpaassdk/room/VPROOMDestroyLiveRsp.h>
#import <vpaassdk/room/VPROOMDestroyRtcReq.h>
#import <vpaassdk/room/VPROOMDestroyRtcRsp.h>
#import <vpaassdk/room/VPROOMDestroyWhiteboardReq.h>
#import <vpaassdk/room/VPROOMDestroyWhiteboardRsp.h>
#import <vpaassdk/room/VPROOMRoomNotificationModel.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPROOMCreateChatCb;
@protocol VPROOMCreateLiveCb;
@protocol VPROOMCreateRtcCb;
@protocol VPROOMCreateWhiteboardCb;
@protocol VPROOMDestroyChatCb;
@protocol VPROOMDestroyLiveCb;
@protocol VPROOMDestroyRtcCb;
@protocol VPROOMDestroyWhiteboardCb;
@protocol VPROOMRoomNotificationListener;


@interface VPROOMRoomExtInterface : NSObject

/**
 * 设置事件监听对象
 */
- (void)setListener:(nonnull NSString *)roomId
           listener:(nullable id<VPROOMRoomNotificationListener>)listener;

/**
 * 创建直播 
 */
- (void)createLive:(nonnull VPROOMCreateLiveReq *)req
          callback:(nullable id<VPROOMCreateLiveCb>)callback;

- (void)createLiveWithBlock:(nonnull VPROOMCreateLiveReq *) req
                  onSuccess:(nullable void(^)(VPROOMCreateLiveRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 销毁直播
 */
- (void)destroyLive:(nonnull VPROOMDestroyLiveReq *)req
           callback:(nullable id<VPROOMDestroyLiveCb>)callback;

- (void)destroyLiveWithBlock:(nonnull VPROOMDestroyLiveReq *) req
                   onSuccess:(nullable void(^)(VPROOMDestroyLiveRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 创建rtc
 */
- (void)createRtc:(nonnull VPROOMCreateRtcReq *)req
         callback:(nullable id<VPROOMCreateRtcCb>)callback;

- (void)createRtcWithBlock:(nonnull VPROOMCreateRtcReq *) req
                 onSuccess:(nullable void(^)(VPROOMCreateRtcRsp * _Nonnull rsp))onSuccess
                 onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 销毁rtc
 */
- (void)destroyRtc:(nonnull VPROOMDestroyRtcReq *)req
          callback:(nullable id<VPROOMDestroyRtcCb>)callback;

- (void)destroyRtcWithBlock:(nonnull VPROOMDestroyRtcReq *) req
                  onSuccess:(nullable void(^)(VPROOMDestroyRtcRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 创建chat
 */
- (void)createChat:(nonnull VPROOMCreateChatReq *)req
          callback:(nullable id<VPROOMCreateChatCb>)callback;

- (void)createChatWithBlock:(nonnull VPROOMCreateChatReq *) req
                  onSuccess:(nullable void(^)(VPROOMCreateChatRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 销毁chat
 */
- (void)destroyChat:(nonnull VPROOMDestroyChatReq *)req
           callback:(nullable id<VPROOMDestroyChatCb>)callback;

- (void)destroyChatWithBlock:(nonnull VPROOMDestroyChatReq *) req
                   onSuccess:(nullable void(^)(VPROOMDestroyChatRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 创建白板
 */
- (void)createWhiteboard:(nonnull VPROOMCreateWhiteboardReq *)req
                callback:(nullable id<VPROOMCreateWhiteboardCb>)callback;

- (void)createWhiteboardWithBlock:(nonnull VPROOMCreateWhiteboardReq *) req
                        onSuccess:(nullable void(^)(VPROOMCreateWhiteboardRsp * _Nonnull rsp))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 销毁白板
 */
- (void)destroyWhiteboard:(nonnull VPROOMDestroyWhiteboardReq *)req
                 callback:(nullable id<VPROOMDestroyWhiteboardCb>)callback;

- (void)destroyWhiteboardWithBlock:(nonnull VPROOMDestroyWhiteboardReq *) req
                         onSuccess:(nullable void(^)(VPROOMDestroyWhiteboardRsp * _Nonnull rsp))onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 获取Queen-lite密钥
 */
- (nonnull NSString *)getQueenLiteSecret;

/**
 * 获取Queen-pro密钥
 */
- (nonnull NSString *)getQueenProSecret;

@end
/* optimized_djinni_generated_objc_file */