// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGCloudConfigBaseInfoV2.h>
#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取云控配置请求，包含可视化配置
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetVisibleConfigReq : NSObject
- (nonnull instancetype)initWithBaseInfo:(nonnull VPCLOUDCONFIGCloudConfigBaseInfoV2 *)baseInfo
                              appVersion:(nonnull NSString *)appVersion
                                 keyList:(nonnull NSArray<NSString *> *)keyList;
+ (nonnull instancetype)VPCLOUDCONFIGGetVisibleConfigReqWithBaseInfo:(nonnull VPCLOUDCONFIGCloudConfigBaseInfoV2 *)baseInfo
                                                          appVersion:(nonnull NSString *)appVersion
                                                             keyList:(nonnull NSArray<NSString *> *)keyList;

/**
 * @param base_info 配置基本参数
 */
@property (nonatomic, nonnull) VPCLOUDCONFIGCloudConfigBaseInfoV2 * baseInfo;

/**
 * @param app_version app版本e.g."1.8.0"
 */
@property (nonatomic, nonnull) NSString * appVersion;

/**
 * @param key_list 请求的key列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * keyList;

@end
/* optimized_djinni_generated_objc_file */