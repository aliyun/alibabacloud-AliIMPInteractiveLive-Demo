// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取直播统计信息响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEGetLiveStatisticsRsp : NSObject
- (nonnull instancetype)initWithDuration:(int64_t)duration
                                coverUrl:(nonnull NSString *)coverUrl
                                   title:(nonnull NSString *)title
                               watchTime:(int64_t)watchTime;
+ (nonnull instancetype)VPLIVEGetLiveStatisticsRspWithDuration:(int64_t)duration
                                                      coverUrl:(nonnull NSString *)coverUrl
                                                         title:(nonnull NSString *)title
                                                     watchTime:(int64_t)watchTime;

/**
 * @param duration 直播时长
 */
@property (nonatomic) int64_t duration;

/**
 * @param cover_url 封面图
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param watch_time 总的观看时长
 */
@property (nonatomic) int64_t watchTime;

@end
/* optimized_djinni_generated_objc_file */