// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 插件信息
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVEPluginInstanceInfo : NSObject
- (nonnull instancetype)initWithPluginId:(nonnull NSString *)pluginId
                              instanceId:(nonnull NSString *)instanceId
                              createTime:(int64_t)createTime
                               extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPSCENELIVEPluginInstanceInfoWithPluginId:(nonnull NSString *)pluginId
                                                       instanceId:(nonnull NSString *)instanceId
                                                       createTime:(int64_t)createTime
                                                        extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param plugin_id 插件id
 */
@property (nonatomic, nonnull) NSString * pluginId;

/**
 * @param instance_id 插件实例id
 */
@property (nonatomic, nonnull) NSString * instanceId;

/**
 * @param create_time 创建事件戳，单位：毫秒
 */
@property (nonatomic) int64_t createTime;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */