// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 开启/结束共享桌面请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCShareScreenReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                                  open:(BOOL)open;
+ (nonnull instancetype)VPRTCShareScreenReqWithConfId:(nonnull NSString *)confId
                                                 open:(BOOL)open;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param open true:打开;false:关闭
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */