// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATSendSystemMessageToUsersRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 指定房间用户发送系统消息,系统消息保证可靠回调
 */
@protocol VPCHATSendSystemMessageToUsersCb

- (void)onSuccess:(nonnull VPCHATSendSystemMessageToUsersRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */