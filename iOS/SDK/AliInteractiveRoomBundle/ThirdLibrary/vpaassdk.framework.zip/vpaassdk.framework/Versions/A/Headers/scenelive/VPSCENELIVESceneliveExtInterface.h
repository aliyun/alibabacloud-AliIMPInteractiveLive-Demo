// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>


@interface VPSCENELIVESceneliveExtInterface : NSObject

@end
/* optimized_djinni_generated_objc_file */