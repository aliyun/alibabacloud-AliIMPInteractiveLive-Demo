// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATSendSystemMessageRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 发送系统消息，系统消息保证可靠回调
 */
@protocol VPCHATSendSystemMessageCb

- (void)onSuccess:(nonnull VPCHATSendSystemMessageRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */