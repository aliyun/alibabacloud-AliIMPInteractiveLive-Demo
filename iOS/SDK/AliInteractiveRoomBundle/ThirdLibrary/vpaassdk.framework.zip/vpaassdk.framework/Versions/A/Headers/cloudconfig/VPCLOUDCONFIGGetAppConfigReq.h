// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取租户配置请求
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetAppConfigReq : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCLOUDCONFIGGetAppConfigReq;

@end
/* optimized_djinni_generated_objc_file */