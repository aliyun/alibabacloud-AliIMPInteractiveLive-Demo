// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCCredentials.h>
#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建文档响应
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCCreateDocRsp : NSObject
- (nonnull instancetype)initWithDocId:(nonnull NSString *)docId
                            ossBucket:(nonnull NSString *)ossBucket
                            ossObject:(nonnull NSString *)ossObject
                          credentials:(nonnull VPDOCCredentials *)credentials;
+ (nonnull instancetype)VPDOCCreateDocRspWithDocId:(nonnull NSString *)docId
                                         ossBucket:(nonnull NSString *)ossBucket
                                         ossObject:(nonnull NSString *)ossObject
                                       credentials:(nonnull VPDOCCredentials *)credentials;

/**
 * @param doc_id 文档ID
 */
@property (nonatomic, nonnull) NSString * docId;

/**
 * @param oss_bucket OSSBucket
 */
@property (nonatomic, nonnull) NSString * ossBucket;

/**
 * @param oss_object OSSObject
 */
@property (nonatomic, nonnull) NSString * ossObject;

/**
 * @param credentials STSToken秘钥
 */
@property (nonatomic, nonnull) VPDOCCredentials * credentials;

@end
/* optimized_djinni_generated_objc_file */