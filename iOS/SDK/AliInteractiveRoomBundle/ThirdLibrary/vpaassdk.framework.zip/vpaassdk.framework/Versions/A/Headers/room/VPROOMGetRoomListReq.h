// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 分页获取房间的在线列表请求
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomListReq : NSObject
- (nonnull instancetype)initWithDomain:(nonnull NSString *)domain
                               pageNum:(int32_t)pageNum
                              pageSize:(int32_t)pageSize;
+ (nonnull instancetype)VPROOMGetRoomListReqWithDomain:(nonnull NSString *)domain
                                               pageNum:(int32_t)pageNum
                                              pageSize:(int32_t)pageSize;

/**
 * @param domain 租户
 */
@property (nonatomic, nonnull) NSString * domain;

/**
 * @param page_num 页码，从1开始
 */
@property (nonatomic) int32_t pageNum;

/**
 * @param page_size 当前页面房间数量
 */
@property (nonatomic) int32_t pageSize;

@end
/* optimized_djinni_generated_objc_file */