// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

/**
 * 日志级别
 */
typedef NS_ENUM(NSInteger, VPMPSLogLevel)
{
    VPMPSLogLevelMPSLOGLEVELDEBUG = 0,
    VPMPSLogLevelMPSLOGLEVELINFO = 1,
    VPMPSLogLevelMPSLOGLEVELWARNING = 2,
    VPMPSLogLevelMPSLOGLEVELERROR = 3,
    VPMPSLogLevelMPSLOGLEVELFATAL = 4,
};
/* optimized_djinni_generated_objc_file */