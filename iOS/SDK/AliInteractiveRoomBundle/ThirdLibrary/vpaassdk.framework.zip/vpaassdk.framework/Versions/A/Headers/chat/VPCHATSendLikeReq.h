// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 点赞请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendLikeReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                                  count:(int32_t)count;
+ (nonnull instancetype)VPCHATSendLikeReqWithTopicId:(nonnull NSString *)topicId
                                               count:(int32_t)count;

/**
 * @param topic_id 话题Id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param count 点赞数
 */
@property (nonatomic) int32_t count;

@end
/* optimized_djinni_generated_objc_file */