// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 设置自定义布局响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCSetCustomLayoutRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCSetCustomLayoutRsp;

@end
/* optimized_djinni_generated_objc_file */