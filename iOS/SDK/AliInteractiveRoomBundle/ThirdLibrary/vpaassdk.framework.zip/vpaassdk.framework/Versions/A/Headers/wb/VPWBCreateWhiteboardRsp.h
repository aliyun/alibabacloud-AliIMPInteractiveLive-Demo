// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建白板响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBCreateWhiteboardRsp : NSObject
- (nonnull instancetype)initWithRequestId:(nonnull NSString *)requestId
                             whiteboardId:(nonnull NSString *)whiteboardId;
+ (nonnull instancetype)VPWBCreateWhiteboardRspWithRequestId:(nonnull NSString *)requestId
                                                whiteboardId:(nonnull NSString *)whiteboardId;

/**
 * @param request_id 请求白板OpenAPI的请求ID
 */
@property (nonatomic, nonnull) NSString * requestId;

/**
 * @param whiteboard_id 白板Id-原DocKey
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

@end
/* optimized_djinni_generated_objc_file */