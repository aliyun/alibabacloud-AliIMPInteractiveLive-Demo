// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/mps/VPMPSExportDelc.h>
#import <vpaassdk/mps/VPMPSLogLevel.h>
#import <vpaassdk/mps/VPMpsEngineType.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
#import <libdps/DPSModuleInfo.h>
@class VPMPSEngine;
@class VPMPSManager;
@class VPMPSSettingService;
@class VPMPSStatis;
@protocol VPMPSEngineListener;
@protocol VPMPSEngineStartListener;
@protocol VPMPSLogHandler;
@protocol VPMPSManagerCreateListener;
@protocol VPMPSReleaseManagerListener;
@protocol VPMPSResetUserDataListener;


/**
 * MPS Engine
 */
VPMPS_OBJECTC_EXPORT
@interface VPMPSEngine : NSObject

/**
 * 创建MPSEngine,如果已经有实例存在,会返回已创建的MPSEngine
 */
+ (nullable VPMPSEngine *)createMPSEngine:(VPMpsEngineType)type;

/**
 * 获取MPSEngine
 */
+ (nullable VPMPSEngine *)getMPSEngine;

/**
 * 获取mps_engine_type
 */
+ (VPMpsEngineType)getEngineType;

/**
 * 获取MPSStatis
 */
+ (nullable VPMPSStatis *)getMPSStatis;

/**
 * 设置log处理函数,处理函数可能会在多个线程调用,处理函数不能长时间阻塞
 * @param minLogLevel 需要输出的最低日志级别（日志级别大于等于这个值才会输出）
 * @param handler 日志处理函数
 */
+ (void)setLogHandler:(VPMPSLogLevel)minLogLevel
              handler:(nullable id<VPMPSLogHandler>)handler;

/**
 * 释放MPSEngine
 */
+ (void)releaseMPSEngine;

/**
 * 清理用户数据接口，可通过该接口清理用户数据，本地存储的消息/会话等数据将被清空
 * @param dataPath 数据存储路径，与之前设置到MPSSettingService内的DataPath一致
 * @param userId 需清理的账号
 * @param appId 账号关联的appID
 * @param onSuccess 重置成功
 * @param onFailure 重置失败，部分文件无法删除
 * 注意事项：
 * 1. 需在user_id 对应MPSManager启动之前进行该操作
 * 2. 部分文件由于io错误，或被其他应用使用，可能导致无法删除
 */
+ (void)resetUserData:(nonnull NSString *)dataPath
               userId:(nonnull NSString *)userId
                appId:(nonnull NSString *)appId
             listener:(nullable id<VPMPSResetUserDataListener>)listener;

+ (void)resetUserDataWithBlock:(nonnull NSString *) dataPath
                        userId:(nonnull NSString *) userId
                         appId:(nonnull NSString *) appId
                     onSuccess:(nullable void(^)())onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 注册service
 */
- (nonnull DPSError *)registerModule:(nullable DPSModuleInfo *)serviceInfo;

/**
 * App切到后台后通知SDK
 */
- (void)onAppDidEnterBackground;

/**
 * App切到前台前通知SDK
 */
- (void)onAppWillEnterForeground;

/**
 * 获取设置服务
 */
- (nullable VPMPSSettingService *)getSettingService;

/**
 * 获取引擎是否启动
 */
- (BOOL)isStarted;

/**
 * 启动
 * @param listener Engine Start回调
 */
- (void)start:(nullable id<VPMPSEngineStartListener>)listener;

- (void)startWithBlock:(nullable void(^)())onSuccess
             onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 设置事件监听器
 * @param listener 监听器
 */
- (void)setListener:(nullable id<VPMPSEngineListener>)listener;

/**
 * 获取所有当前存在的MPSUserId
 */
- (nonnull NSArray<NSString *> *)getUserIds;

/**
 * 创建Manager,注意只允许同时存在MAX_MANAGER_NUM以下的Manager实例
 * @param userId 登录帐号
 * @param listener 监听器
 */
- (void)createMPSManager:(nonnull NSString *)userId
                listener:(nullable id<VPMPSManagerCreateListener>)listener;

- (void)createMPSManagerWithBlock:(nonnull NSString *) userId
                        onSuccess:(nullable void(^)(VPMPSManager * _Nullable manager))onSuccess
                        onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 获取MPSManager
 * @param userId 登录帐号
 */
- (nullable VPMPSManager *)getMPSManager:(nonnull NSString *)userId;

/**
 * 释放MPSManager
 * @param userId 登录帐号
 */
- (void)releaseMPSManager:(nonnull NSString *)userId
                 listener:(nullable id<VPMPSReleaseManagerListener>)listener;

- (void)releaseMPSManagerWithBlock:(nonnull NSString *) userId
                         onSuccess:(nullable void(^)())onSuccess
                         onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * 获取服务端时钟
 * @return 单位毫秒，如果获取失败，返回-1
 */
- (int64_t)getServerTimeClock;

@end
/* optimized_djinni_generated_objc_file */