// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 启动旁路推流响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCPushLiveStreamRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPRTCPushLiveStreamRsp;

@end
/* optimized_djinni_generated_objc_file */