// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新直播信息响应
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneUpdateLiveRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPSCENELIVESceneUpdateLiveRsp;

@end
/* optimized_djinni_generated_objc_file */