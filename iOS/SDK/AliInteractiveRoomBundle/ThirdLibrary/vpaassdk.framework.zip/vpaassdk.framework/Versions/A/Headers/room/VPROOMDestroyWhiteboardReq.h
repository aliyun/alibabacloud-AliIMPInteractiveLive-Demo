// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyWhiteboardReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                          whiteboardId:(nonnull NSString *)whiteboardId;
+ (nonnull instancetype)VPROOMDestroyWhiteboardReqWithRoomId:(nonnull NSString *)roomId
                                                whiteboardId:(nonnull NSString *)whiteboardId;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * whiteboard id
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

@end
/* optimized_djinni_generated_objc_file */