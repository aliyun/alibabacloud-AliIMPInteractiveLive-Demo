// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 开始录制请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCStartRecordReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                        resolutionType:(int32_t)resolutionType;
+ (nonnull instancetype)VPRTCStartRecordReqWithConfId:(nonnull NSString *)confId
                                       resolutionType:(int32_t)resolutionType;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param resolution_type 分辨率类型宽x高,1:1280x720(横屏,默认值),2:720x1280(竖屏),3:1920x1080(横屏),4:1080x1920(竖屏)
 */
@property (nonatomic) int32_t resolutionType;

@end
/* optimized_djinni_generated_objc_file */