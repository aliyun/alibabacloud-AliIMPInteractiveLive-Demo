// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 移动端参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGMobileSystemInfo : NSObject
- (nonnull instancetype)initWithProcessorName:(nonnull NSString *)processorName
                                   deviceType:(int32_t)deviceType
                                deviceVersion:(int32_t)deviceVersion
                                   iOSVersion:(int32_t)iOSVersion
                                   deviceName:(nonnull NSString *)deviceName
                                        cores:(int32_t)cores
                                 cpuFrequency:(int32_t)cpuFrequency;
+ (nonnull instancetype)VPCLOUDCONFIGMobileSystemInfoWithProcessorName:(nonnull NSString *)processorName
                                                            deviceType:(int32_t)deviceType
                                                         deviceVersion:(int32_t)deviceVersion
                                                            iOSVersion:(int32_t)iOSVersion
                                                            deviceName:(nonnull NSString *)deviceName
                                                                 cores:(int32_t)cores
                                                          cpuFrequency:(int32_t)cpuFrequency;

/**
 * @param processor_name 处理器名，Android需要
 */
@property (nonatomic, nonnull) NSString * processorName;

/**
 * @param device_type 0iPhone,1iPad
 */
@property (nonatomic) int32_t deviceType;

/**
 * @param device_version 设备版本
 */
@property (nonatomic) int32_t deviceVersion;

/**
 * @param i_o_s_version iOS系统版本
 */
@property (nonatomic) int32_t iOSVersion;

/**
 * @param device_name 设备名（Android黑名单用）
 */
@property (nonatomic, nonnull) NSString * deviceName;

/**
 * @param cores CPU核数
 */
@property (nonatomic) int32_t cores;

/**
 * @param cpu_frequency CPU主频，单位MHZ
 */
@property (nonatomic) int32_t cpuFrequency;

@end
/* optimized_djinni_generated_objc_file */