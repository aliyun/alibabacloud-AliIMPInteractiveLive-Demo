// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVESceneCreateLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneCreateLiveRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveDetailReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveDetailRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveListReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveListRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneStopLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneStopLiveRsp.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneUpdateLiveReq.h>
#import <vpaassdk/scenelive/VPSCENELIVESceneUpdateLiveRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPSCENELIVECreateLiveCb;
@protocol VPSCENELIVEGetLiveDetailCb;
@protocol VPSCENELIVEGetLiveListCb;
@protocol VPSCENELIVEStopLiveCb;
@protocol VPSCENELIVEUpdateLiveCb;


@interface VPSCENELIVESceneliveRpcInterface : NSObject

/**
 * @brief 创建直播
 */
- (void)createLive:(nonnull VPSCENELIVESceneCreateLiveReq *)req
          callback:(nullable id<VPSCENELIVECreateLiveCb>)callback;

- (void)createLiveWithBlock:(nonnull VPSCENELIVESceneCreateLiveReq *) req
                  onSuccess:(nullable void(^)(VPSCENELIVESceneCreateLiveRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 关闭直播
 */
- (void)stopLive:(nonnull VPSCENELIVESceneStopLiveReq *)req
        callback:(nullable id<VPSCENELIVEStopLiveCb>)callback;

- (void)stopLiveWithBlock:(nonnull VPSCENELIVESceneStopLiveReq *) req
                onSuccess:(nullable void(^)(VPSCENELIVESceneStopLiveRsp * _Nonnull rsp))onSuccess
                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 更新直播信息
 */
- (void)updateLive:(nonnull VPSCENELIVESceneUpdateLiveReq *)req
          callback:(nullable id<VPSCENELIVEUpdateLiveCb>)callback;

- (void)updateLiveWithBlock:(nonnull VPSCENELIVESceneUpdateLiveReq *) req
                  onSuccess:(nullable void(^)(VPSCENELIVESceneUpdateLiveRsp * _Nonnull rsp))onSuccess
                  onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 查询直播详情
 */
- (void)getLiveDetail:(nonnull VPSCENELIVESceneGetLiveDetailReq *)req
             callback:(nullable id<VPSCENELIVEGetLiveDetailCb>)callback;

- (void)getLiveDetailWithBlock:(nonnull VPSCENELIVESceneGetLiveDetailReq *) req
                     onSuccess:(nullable void(^)(VPSCENELIVESceneGetLiveDetailRsp * _Nonnull rsp))onSuccess
                     onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 查询直播列表
 */
- (void)getLiveList:(nonnull VPSCENELIVESceneGetLiveListReq *)req
           callback:(nullable id<VPSCENELIVEGetLiveListCb>)callback;

- (void)getLiveListWithBlock:(nonnull VPSCENELIVESceneGetLiveListReq *) req
                   onSuccess:(nullable void(^)(VPSCENELIVESceneGetLiveListRsp * _Nonnull rsp))onSuccess
                   onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */