// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfInfoModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取会议详情响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCGetConfDetailRsp : NSObject
- (nonnull instancetype)initWithConfInfo:(nonnull VPRTCConfInfoModel *)confInfo
                                 version:(int64_t)version;
+ (nonnull instancetype)VPRTCGetConfDetailRspWithConfInfo:(nonnull VPRTCConfInfoModel *)confInfo
                                                  version:(int64_t)version;

/**
 * @param conf_info 会议中成员列表
 */
@property (nonatomic, nonnull) VPRTCConfInfoModel * confInfo;

/**
 * @param version 会议状态信息版本号，用于解决客户端和服务器之间会议状态信息的版本不一致问题，会议本身状态变更及成员状态变更等会引起该版本号增长
 */
@property (nonatomic) int64_t version;

@end
/* optimized_djinni_generated_objc_file */