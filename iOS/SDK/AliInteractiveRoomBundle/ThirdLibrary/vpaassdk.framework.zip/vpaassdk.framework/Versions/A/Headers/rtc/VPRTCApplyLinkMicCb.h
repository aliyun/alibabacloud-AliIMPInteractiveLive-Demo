// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCApplyLinkMicRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 申请/取消申请连麦回调
 */
@protocol VPRTCApplyLinkMicCb

- (void)onSuccess:(nonnull VPRTCApplyLinkMicRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */