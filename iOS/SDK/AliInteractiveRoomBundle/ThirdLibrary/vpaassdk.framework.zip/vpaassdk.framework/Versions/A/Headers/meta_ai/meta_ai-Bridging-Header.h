// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// meta_ai_Bridging_Header.h
// meta_ai_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for meta_aiBridgingHeader.
FOUNDATION_EXPORT double meta_aiBridgingHeaderVersionNumber;

//! Project version string for meta_aiBridgingHeader.
FOUNDATION_EXPORT const unsigned char meta_aiBridgingHeaderVersionString[];

#import <vpaassdk/meta_ai/VPMETA_AIMetaAiModule.h>
#import <vpaassdk/meta_ai/VPMETA_AIMetaAiExtInterface.h>
#import <vpaassdk/meta_ai/VPMETA_AICreateCb.h>
#import <vpaassdk/meta_ai/VPMETA_AIListCb.h>
#import <vpaassdk/meta_ai/VPMETA_AIAnswerUploadCb.h>
#import <vpaassdk/meta_ai/VPMETA_AIDownloadCb.h>
#import <vpaassdk/meta_ai/VPMETA_AIMetaAiRpcInterface.h>
#import <vpaassdk/meta_ai/VPMETA_AICreateModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AICreateModelRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIAnswerUploadReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIAnswerUploadRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIListModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIListModelRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIDownloadModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIDownloadModelRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIProductInfo.h>
/* optimized_djinni_generated_objc_file */