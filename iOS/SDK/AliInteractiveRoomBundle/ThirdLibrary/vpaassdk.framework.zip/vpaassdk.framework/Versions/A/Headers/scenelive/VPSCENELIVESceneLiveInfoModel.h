// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播信息
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneLiveInfoModel : NSObject
- (nonnull instancetype)initWithAppId:(nonnull NSString *)appId
                               liveId:(nonnull NSString *)liveId
                               status:(int32_t)status
                               roomId:(nonnull NSString *)roomId
                               chatId:(nonnull NSString *)chatId
                                title:(nonnull NSString *)title
                               notice:(nonnull NSString *)notice
                             coverUrl:(nonnull NSString *)coverUrl
                             anchorId:(nonnull NSString *)anchorId
                                   uv:(int32_t)uv
                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                           anchorNick:(nonnull NSString *)anchorNick
                        enableLinkMic:(BOOL)enableLinkMic
                               confId:(nonnull NSString *)confId;
+ (nonnull instancetype)VPSCENELIVESceneLiveInfoModelWithAppId:(nonnull NSString *)appId
                                                        liveId:(nonnull NSString *)liveId
                                                        status:(int32_t)status
                                                        roomId:(nonnull NSString *)roomId
                                                        chatId:(nonnull NSString *)chatId
                                                         title:(nonnull NSString *)title
                                                        notice:(nonnull NSString *)notice
                                                      coverUrl:(nonnull NSString *)coverUrl
                                                      anchorId:(nonnull NSString *)anchorId
                                                            uv:(int32_t)uv
                                                     extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                                    anchorNick:(nonnull NSString *)anchorNick
                                                 enableLinkMic:(BOOL)enableLinkMic
                                                        confId:(nonnull NSString *)confId;

/**
 * @param app_id 应用id
 */
@property (nonatomic, nonnull) NSString * appId;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param status 直播状态，0-在播1-下播
 */
@property (nonatomic) int32_t status;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param chat_id 聊天id
 */
@property (nonatomic, nonnull) NSString * chatId;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param cover_url 封面
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param anchor_id 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param uv 访问数
 */
@property (nonatomic) int32_t uv;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param anchor_nick 主播id
 */
@property (nonatomic, nonnull) NSString * anchorNick;

/**
 * @param enable_link_mic 是否启用连麦
 */
@property (nonatomic) BOOL enableLinkMic;

/**
 * @param conf_id RTC/会议id
 */
@property (nonatomic, nonnull) NSString * confId;

@end
/* optimized_djinni_generated_objc_file */