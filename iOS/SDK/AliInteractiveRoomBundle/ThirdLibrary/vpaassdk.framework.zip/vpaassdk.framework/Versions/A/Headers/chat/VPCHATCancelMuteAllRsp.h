// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 取消全体禁言响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATCancelMuteAllRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCHATCancelMuteAllRsp;

@end
/* optimized_djinni_generated_objc_file */