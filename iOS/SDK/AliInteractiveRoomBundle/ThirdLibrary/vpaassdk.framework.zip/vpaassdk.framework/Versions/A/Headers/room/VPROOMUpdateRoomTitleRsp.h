// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新房间标题响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMUpdateRoomTitleRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPROOMUpdateRoomTitleRsp;

@end
/* optimized_djinni_generated_objc_file */