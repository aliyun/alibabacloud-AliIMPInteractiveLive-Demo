// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播观看开始上报请求
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEStartLiveTimingReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid;
+ (nonnull instancetype)VPLIVEStartLiveTimingReqWithUuid:(nonnull NSString *)uuid;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

@end
/* optimized_djinni_generated_objc_file */