// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 用户主动关闭麦克风消息模型
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCPositiveMuteMicMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                            userList:(nonnull NSArray<NSString *> *)userList
                        positiveMute:(BOOL)positiveMute;
+ (nonnull instancetype)VPRTCPositiveMuteMicMessageWithType:(int32_t)type
                                                    version:(int64_t)version
                                                     confId:(nonnull NSString *)confId
                                                   userList:(nonnull NSArray<NSString *> *)userList
                                               positiveMute:(BOOL)positiveMute;

/**
 * @param type 消息类型，取值：14
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_list 麦克风状态变更的用户ID列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * userList;

/**
 * @param positive_mute true：主动关闭麦克风；false：主动取消关闭
 */
@property (nonatomic) BOOL positiveMute;

@end
/* optimized_djinni_generated_objc_file */