// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 检测能否入会响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCCheckAllowJoinRsp : NSObject
- (nonnull instancetype)initWithAllow:(BOOL)allow
                                 code:(nonnull NSString *)code
                               reason:(nonnull NSString *)reason;
+ (nonnull instancetype)VPRTCCheckAllowJoinRspWithAllow:(BOOL)allow
                                                   code:(nonnull NSString *)code
                                                 reason:(nonnull NSString *)reason;

/**
 * @param allow false:禁止;true:允许
 */
@property (nonatomic) BOOL allow;

/**
 * @param code 禁止状态下，错误码
 */
@property (nonatomic, nonnull) NSString * code;

/**
 * @param reason 禁止状态下，错误原因
 */
@property (nonatomic, nonnull) NSString * reason;

@end
/* optimized_djinni_generated_objc_file */