// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取云控配置响应
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGGetCloudConfigRsp : NSObject
- (nonnull instancetype)initWithKeyConfigMap:(nonnull NSDictionary<NSString *, NSString *> *)keyConfigMap;
+ (nonnull instancetype)VPCLOUDCONFIGGetCloudConfigRspWithKeyConfigMap:(nonnull NSDictionary<NSString *, NSString *> *)keyConfigMap;

/**
 * @param key_config_map 云控key对应的value
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * keyConfigMap;

@end
/* optimized_djinni_generated_objc_file */