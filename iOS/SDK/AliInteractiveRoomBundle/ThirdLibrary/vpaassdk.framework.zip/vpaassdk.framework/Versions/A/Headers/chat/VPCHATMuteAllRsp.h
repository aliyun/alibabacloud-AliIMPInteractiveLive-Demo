// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 全体禁言响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATMuteAllRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPCHATMuteAllRsp;

@end
/* optimized_djinni_generated_objc_file */