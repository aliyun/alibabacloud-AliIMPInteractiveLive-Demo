// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/mps/VPMPSLogLevel.h>
#import <Foundation/Foundation.h>


/**
 * Log 监听
 */
@protocol VPMPSLogHandler

- (void)onLog:(VPMPSLogLevel)logLevel
   logContent:(nonnull NSString *)logContent;

@end
/* optimized_djinni_generated_objc_file */