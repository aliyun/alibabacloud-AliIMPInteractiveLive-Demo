// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取直播观看人员信息请求
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEGetLiveUserStatisticsReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
                            pageSize:(int32_t)pageSize
                                page:(int32_t)page;
+ (nonnull instancetype)VPLIVEGetLiveUserStatisticsReqWithUuid:(nonnull NSString *)uuid
                                                      pageSize:(int32_t)pageSize
                                                          page:(int32_t)page;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param page_size 每页容量
 */
@property (nonatomic) int32_t pageSize;

/**
 * @param page 页码
 */
@property (nonatomic) int32_t page;

@end
/* optimized_djinni_generated_objc_file */