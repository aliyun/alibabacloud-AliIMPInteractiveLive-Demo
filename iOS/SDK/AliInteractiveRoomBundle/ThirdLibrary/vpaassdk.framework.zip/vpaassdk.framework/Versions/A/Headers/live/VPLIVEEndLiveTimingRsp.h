// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播观看结束上报响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEEndLiveTimingRsp : NSObject
- (nonnull instancetype)initWithSuccess:(BOOL)success;
+ (nonnull instancetype)VPLIVEEndLiveTimingRspWithSuccess:(BOOL)success;

/**
 * @param success 上报成功
 */
@property (nonatomic) BOOL success;

@end
/* optimized_djinni_generated_objc_file */