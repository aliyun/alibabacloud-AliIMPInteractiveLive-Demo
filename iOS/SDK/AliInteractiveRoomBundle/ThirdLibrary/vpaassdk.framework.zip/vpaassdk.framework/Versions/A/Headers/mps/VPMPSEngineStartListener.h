// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * Engine 启动监听
 */
@protocol VPMPSEngineStartListener

/**
 * Enigne 启动成功
 */
- (void)onSuccess;

/**
 * Engine 启动失败
 */
- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */