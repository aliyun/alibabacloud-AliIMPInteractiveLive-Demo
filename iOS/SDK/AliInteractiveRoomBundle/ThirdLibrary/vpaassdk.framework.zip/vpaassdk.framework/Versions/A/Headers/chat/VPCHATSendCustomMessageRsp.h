// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发送普通自定义消息响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendCustomMessageRsp : NSObject
- (nonnull instancetype)initWithMessageId:(nonnull NSString *)messageId;
+ (nonnull instancetype)VPCHATSendCustomMessageRspWithMessageId:(nonnull NSString *)messageId;

/**
 * @param message_id 消息唯一ID标识
 */
@property (nonatomic, nonnull) NSString * messageId;

@end
/* optimized_djinni_generated_objc_file */