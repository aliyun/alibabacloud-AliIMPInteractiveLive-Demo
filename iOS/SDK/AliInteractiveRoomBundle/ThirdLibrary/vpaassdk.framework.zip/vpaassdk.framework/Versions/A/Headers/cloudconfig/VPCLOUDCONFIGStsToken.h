// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief stsToken
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGStsToken : NSObject
- (nonnull instancetype)initWithAccessKeyId:(nonnull NSString *)accessKeyId
                            accessKeySecret:(nonnull NSString *)accessKeySecret
                              securityToken:(nonnull NSString *)securityToken
                                 expireTime:(int32_t)expireTime;
+ (nonnull instancetype)VPCLOUDCONFIGStsTokenWithAccessKeyId:(nonnull NSString *)accessKeyId
                                             accessKeySecret:(nonnull NSString *)accessKeySecret
                                               securityToken:(nonnull NSString *)securityToken
                                                  expireTime:(int32_t)expireTime;

/**
 * @param access_key_id ak
 */
@property (nonatomic, nonnull) NSString * accessKeyId;

/**
 * @param access_key_secret sk
 */
@property (nonatomic, nonnull) NSString * accessKeySecret;

/**
 * @param security_token token
 */
@property (nonatomic, nonnull) NSString * securityToken;

/**
 * @param expire_time token过期时间，单位：秒
 */
@property (nonatomic) int32_t expireTime;

@end
/* optimized_djinni_generated_objc_file */