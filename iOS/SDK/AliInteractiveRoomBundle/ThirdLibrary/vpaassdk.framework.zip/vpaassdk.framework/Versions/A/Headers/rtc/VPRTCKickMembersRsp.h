// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 踢人响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCKickMembersRsp : NSObject
- (nonnull instancetype)initWithVersion:(int64_t)version;
+ (nonnull instancetype)VPRTCKickMembersRspWithVersion:(int64_t)version;

/**
 * @param version 会议状态信息版本号
 */
@property (nonatomic) int64_t version;

@end
/* optimized_djinni_generated_objc_file */