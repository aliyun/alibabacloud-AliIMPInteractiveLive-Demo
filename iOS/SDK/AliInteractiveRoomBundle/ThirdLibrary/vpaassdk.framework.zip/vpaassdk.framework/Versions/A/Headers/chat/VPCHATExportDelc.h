#if defined(VPCHAT_OBJECTC_EXPORT_ENABLE)
#define VPCHAT_OBJECTC_EXPORT  __attribute__((visibility("default")))
#else
#define VPCHAT_OBJECTC_EXPORT 
#endif/* optimized_djinni_generated_objc_file */