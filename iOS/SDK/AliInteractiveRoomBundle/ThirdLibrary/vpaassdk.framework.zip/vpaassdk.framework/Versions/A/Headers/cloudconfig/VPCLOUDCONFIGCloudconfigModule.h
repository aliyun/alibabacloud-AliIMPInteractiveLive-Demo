// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPCLOUDCONFIGCloudconfigExtInterface;
@class VPCLOUDCONFIGCloudconfigModule;
@class VPCLOUDCONFIGCloudconfigRpcInterface;


VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGCloudconfigModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPCLOUDCONFIGCloudconfigModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPCLOUDCONFIGCloudconfigRpcInterface *)getRpcInterface;

- (nullable VPCLOUDCONFIGCloudconfigExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */