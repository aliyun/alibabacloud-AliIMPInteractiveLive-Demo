// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPCHATChatExtInterface;
@class VPCHATChatModule;
@class VPCHATChatRpcInterface;


VPCHAT_OBJECTC_EXPORT
@interface VPCHATChatModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPCHATChatModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPCHATChatRpcInterface *)getRpcInterface;

- (nullable VPCHATChatExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */