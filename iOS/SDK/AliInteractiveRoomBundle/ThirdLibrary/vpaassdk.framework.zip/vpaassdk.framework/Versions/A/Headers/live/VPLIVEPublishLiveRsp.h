// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发布直播响应
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEPublishLiveRsp : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
                             pushUrl:(nonnull NSString *)pushUrl
                             liveUrl:(nonnull NSString *)liveUrl
                              status:(int32_t)status;
+ (nonnull instancetype)VPLIVEPublishLiveRspWithUuid:(nonnull NSString *)uuid
                                             pushUrl:(nonnull NSString *)pushUrl
                                             liveUrl:(nonnull NSString *)liveUrl
                                              status:(int32_t)status;

/**
 * @param uuid 直播uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param push_url 直播推流地址
 */
@property (nonatomic, nonnull) NSString * pushUrl;

/**
 * @param live_url 直播推流地址
 */
@property (nonatomic, nonnull) NSString * liveUrl;

/**
 * @param status 直播状态
 */
@property (nonatomic) int32_t status;

@end
/* optimized_djinni_generated_objc_file */