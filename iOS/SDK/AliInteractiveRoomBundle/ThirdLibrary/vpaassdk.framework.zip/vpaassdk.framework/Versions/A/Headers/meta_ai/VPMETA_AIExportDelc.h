#if defined(VPMETA_AI_OBJECTC_EXPORT_ENABLE)
#define VPMETA_AI_OBJECTC_EXPORT  __attribute__((visibility("default")))
#else
#define VPMETA_AI_OBJECTC_EXPORT 
#endif/* optimized_djinni_generated_objc_file */