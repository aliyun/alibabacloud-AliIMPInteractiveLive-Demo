// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 禁音消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCMuteMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId
                            userList:(nonnull NSArray<NSString *> *)userList
                                open:(BOOL)open;
+ (nonnull instancetype)VPRTCMuteMessageWithType:(int32_t)type
                                         version:(int64_t)version
                                          confId:(nonnull NSString *)confId
                                        userList:(nonnull NSArray<NSString *> *)userList
                                            open:(BOOL)open;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_list 被禁用用户ID列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * userList;

/**
 * @param open true:不禁音;false:禁音
 */
@property (nonatomic) BOOL open;

@end
/* optimized_djinni_generated_objc_file */