// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 开始白板录制响应
 */
VPWB_OBJECTC_EXPORT
@interface VPWBStartWhiteboardRecordingRsp : NSObject
- (nonnull instancetype)initWithRequestId:(nonnull NSString *)requestId
                                startTime:(nonnull NSString *)startTime
                                 recordId:(nonnull NSString *)recordId;
+ (nonnull instancetype)VPWBStartWhiteboardRecordingRspWithRequestId:(nonnull NSString *)requestId
                                                           startTime:(nonnull NSString *)startTime
                                                            recordId:(nonnull NSString *)recordId;

/**
 * @param request_id 请求白板OpenAPI的请求ID（建议保留方便后续问题排查）
 */
@property (nonatomic, nonnull) NSString * requestId;

/**
 * @param start_time 录制操作时间戳（UNIX毫秒格式）
 */
@property (nonatomic, nonnull) NSString * startTime;

/**
 * @param record_id 录制唯一标识
 */
@property (nonatomic, nonnull) NSString * recordId;

@end
/* optimized_djinni_generated_objc_file */