// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 禁言用户信息
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATBanCommentUser : NSObject
- (nonnull instancetype)initWithUserId:(nonnull NSString *)userId;
+ (nonnull instancetype)VPCHATBanCommentUserWithUserId:(nonnull NSString *)userId;

/**
 * @param user_id 禁言的用户id
 */
@property (nonatomic, nonnull) NSString * userId;

@end
/* optimized_djinni_generated_objc_file */