// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, VPMonitorhubReportModel)
{
    VPMonitorhubReportModelSlsWebtracking = 1,
    VPMonitorhubReportModelSlsSdk = 2,
};
/* optimized_djinni_generated_objc_file */