#if defined(VPDOC_OBJECTC_EXPORT_ENABLE)
#define VPDOC_OBJECTC_EXPORT  __attribute__((visibility("default")))
#else
#define VPDOC_OBJECTC_EXPORT 
#endif/* optimized_djinni_generated_objc_file */