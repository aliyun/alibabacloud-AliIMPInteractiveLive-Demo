// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATSendCommentRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 发送弹幕
 * 完成持久化存储，并推送给在线客户端回调
 */
@protocol VPCHATSendCommentCb

- (void)onSuccess:(nonnull VPCHATSendCommentRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */