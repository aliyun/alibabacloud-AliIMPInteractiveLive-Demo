// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取入会token响应
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCGetTokenRsp : NSObject
- (nonnull instancetype)initWithMediaConfig:(nonnull NSString *)mediaConfig
                                      token:(nonnull NSString *)token
                                       gslb:(nonnull NSString *)gslb
                                      appId:(nonnull NSString *)appId
                                  timestamp:(int64_t)timestamp
                                      nonce:(nonnull NSString *)nonce;
+ (nonnull instancetype)VPRTCGetTokenRspWithMediaConfig:(nonnull NSString *)mediaConfig
                                                  token:(nonnull NSString *)token
                                                   gslb:(nonnull NSString *)gslb
                                                  appId:(nonnull NSString *)appId
                                              timestamp:(int64_t)timestamp
                                                  nonce:(nonnull NSString *)nonce;

/**
 * @param media_config 媒体配置，json格式
 */
@property (nonatomic, nonnull) NSString * mediaConfig;

/**
 * @param token 以下是alirtc专用的信息
 */
@property (nonatomic, nonnull) NSString * token;

@property (nonatomic, nonnull) NSString * gslb;

@property (nonatomic, nonnull) NSString * appId;

@property (nonatomic) int64_t timestamp;

@property (nonatomic, nonnull) NSString * nonce;

@end
/* optimized_djinni_generated_objc_file */