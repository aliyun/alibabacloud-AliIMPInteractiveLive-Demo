// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 停止响铃消息
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCStopRingingMessage : NSObject
- (nonnull instancetype)initWithType:(int32_t)type
                             version:(int64_t)version
                              confId:(nonnull NSString *)confId;
+ (nonnull instancetype)VPRTCStopRingingMessageWithType:(int32_t)type
                                                version:(int64_t)version
                                                 confId:(nonnull NSString *)confId;

/**
 * @param type 消息类型
 */
@property (nonatomic) int32_t type;

/**
 * @param version 消息版本
 */
@property (nonatomic) int64_t version;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

@end
/* optimized_djinni_generated_objc_file */