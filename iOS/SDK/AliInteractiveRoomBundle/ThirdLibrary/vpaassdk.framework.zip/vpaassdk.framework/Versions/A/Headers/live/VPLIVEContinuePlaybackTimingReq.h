// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 直播回放观看继续上报请求
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEContinuePlaybackTimingReq : NSObject
- (nonnull instancetype)initWithUuid:(nonnull NSString *)uuid
                             transId:(nonnull NSString *)transId;
+ (nonnull instancetype)VPLIVEContinuePlaybackTimingReqWithUuid:(nonnull NSString *)uuid
                                                        transId:(nonnull NSString *)transId;

/**
 * @param uuid 直播id
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param trans_id 观看直播回放标识
 */
@property (nonatomic, nonnull) NSString * transId;

@end
/* optimized_djinni_generated_objc_file */