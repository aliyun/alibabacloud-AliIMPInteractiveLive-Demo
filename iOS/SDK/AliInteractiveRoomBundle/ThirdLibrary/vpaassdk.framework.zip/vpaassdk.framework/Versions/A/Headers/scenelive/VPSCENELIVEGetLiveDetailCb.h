// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVESceneGetLiveDetailRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 查询直播详情回调
 */
@protocol VPSCENELIVEGetLiveDetailCb

- (void)onSuccess:(nonnull VPSCENELIVESceneGetLiveDetailRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */