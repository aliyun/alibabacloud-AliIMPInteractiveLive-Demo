// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIAnswerUploadReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIAnswerUploadRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AICreateModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AICreateModelRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIDownloadModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIDownloadModelRsp.h>
#import <vpaassdk/meta_ai/VPMETA_AIListModelReq.h>
#import <vpaassdk/meta_ai/VPMETA_AIListModelRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>
@protocol VPMETA_AIAnswerUploadCb;
@protocol VPMETA_AICreateCb;
@protocol VPMETA_AIDownloadCb;
@protocol VPMETA_AIListCb;


@interface VPMETA_AIMetaAiRpcInterface : NSObject

/**
 * @brief 创建商品任务
 */
- (void)create:(nonnull VPMETA_AICreateModelReq *)req
      callback:(nullable id<VPMETA_AICreateCb>)callback;

- (void)createWithBlock:(nonnull VPMETA_AICreateModelReq *) req
              onSuccess:(nullable void(^)(VPMETA_AICreateModelRsp * _Nonnull rsp))onSuccess
              onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 拉取商品
 */
- (void)list:(nonnull VPMETA_AIListModelReq *)req
    callback:(nullable id<VPMETA_AIListCb>)callback;

- (void)listWithBlock:(nonnull VPMETA_AIListModelReq *) req
            onSuccess:(nullable void(^)(VPMETA_AIListModelRsp * _Nonnull rsp))onSuccess
            onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 上传反馈任务
 */
- (void)answerUpload:(nonnull VPMETA_AIAnswerUploadReq *)req
            callback:(nullable id<VPMETA_AIAnswerUploadCb>)callback;

- (void)answerUploadWithBlock:(nonnull VPMETA_AIAnswerUploadReq *) req
                    onSuccess:(nullable void(^)(VPMETA_AIAnswerUploadRsp * _Nonnull rsp))onSuccess
                    onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

/**
 * @brief 下载任务
 */
- (void)download:(nonnull VPMETA_AIDownloadModelReq *)req
        callback:(nullable id<VPMETA_AIDownloadCb>)callback;

- (void)downloadWithBlock:(nonnull VPMETA_AIDownloadModelReq *) req
                onSuccess:(nullable void(^)(VPMETA_AIDownloadModelRsp * _Nonnull rsp))onSuccess
                onFailure:(nullable void(^)(DPSError * _Nonnull error))onFailure;

@end
/* optimized_djinni_generated_objc_file */