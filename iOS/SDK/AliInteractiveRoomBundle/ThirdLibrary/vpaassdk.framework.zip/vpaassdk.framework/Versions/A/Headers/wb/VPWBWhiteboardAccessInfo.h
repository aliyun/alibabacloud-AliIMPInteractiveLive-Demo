// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <vpaassdk/wb/VPWBWhiteboardUserInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 白板连接信息
 */
VPWB_OBJECTC_EXPORT
@interface VPWBWhiteboardAccessInfo : NSObject
- (nonnull instancetype)initWithAccessToken:(nonnull NSString *)accessToken
                                 collabHost:(nonnull NSString *)collabHost
                                 permission:(int32_t)permission
                                   userInfo:(nonnull VPWBWhiteboardUserInfo *)userInfo
                                   wsDomain:(nonnull NSString *)wsDomain;
+ (nonnull instancetype)VPWBWhiteboardAccessInfoWithAccessToken:(nonnull NSString *)accessToken
                                                     collabHost:(nonnull NSString *)collabHost
                                                     permission:(int32_t)permission
                                                       userInfo:(nonnull VPWBWhiteboardUserInfo *)userInfo
                                                       wsDomain:(nonnull NSString *)wsDomain;

/**
 * @param access_token 白板长连接Token
 */
@property (nonatomic, nonnull) NSString * accessToken;

/**
 * @param collab_host 白板长连接（协同引擎）Host
 */
@property (nonatomic, nonnull) NSString * collabHost;

/**
 * @param permission 白板权限码（0:无权限;1:只读;2:读写）
 */
@property (nonatomic) int32_t permission;

/**
 * @param user_info 白板用户信息
 */
@property (nonatomic, nonnull) VPWBWhiteboardUserInfo * userInfo;

/**
 * @param ws_domain 长连接性能增强Host
 */
@property (nonatomic, nonnull) NSString * wsDomain;

@end
/* optimized_djinni_generated_objc_file */