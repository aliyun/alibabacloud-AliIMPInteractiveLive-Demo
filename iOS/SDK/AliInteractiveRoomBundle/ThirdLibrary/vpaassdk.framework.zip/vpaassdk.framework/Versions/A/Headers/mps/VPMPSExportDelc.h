#if defined(VPMPS_OBJECTC_EXPORT_ENABLE)
#define VPMPS_OBJECTC_EXPORT  __attribute__((visibility("default")))
#else
#define VPMPS_OBJECTC_EXPORT 
#endif/* optimized_djinni_generated_objc_file */