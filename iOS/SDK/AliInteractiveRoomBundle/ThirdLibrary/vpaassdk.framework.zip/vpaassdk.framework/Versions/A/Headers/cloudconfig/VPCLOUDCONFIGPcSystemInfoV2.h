// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief PC端参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGPcSystemInfoV2 : NSObject
- (nonnull instancetype)initWithPhysicalCores:(int32_t)physicalCores
                                 logicalCores:(int32_t)logicalCores
                                 cpuFrequency:(int32_t)cpuFrequency
                           isDiscreteGraphics:(BOOL)isDiscreteGraphics
                                 graphicsName:(nonnull NSString *)graphicsName
                                        width:(int32_t)width
                                       height:(int32_t)height
                                processorName:(nonnull NSString *)processorName;
+ (nonnull instancetype)VPCLOUDCONFIGPcSystemInfoV2WithPhysicalCores:(int32_t)physicalCores
                                                        logicalCores:(int32_t)logicalCores
                                                        cpuFrequency:(int32_t)cpuFrequency
                                                  isDiscreteGraphics:(BOOL)isDiscreteGraphics
                                                        graphicsName:(nonnull NSString *)graphicsName
                                                               width:(int32_t)width
                                                              height:(int32_t)height
                                                       processorName:(nonnull NSString *)processorName;

/**
 * @param physical_cores 物理核数
 */
@property (nonatomic) int32_t physicalCores;

/**
 * @param logical_cores 逻辑核数
 */
@property (nonatomic) int32_t logicalCores;

/**
 * @param cpu_frequency MHZ
 */
@property (nonatomic) int32_t cpuFrequency;

/**
 * @param is_discrete_graphics 是否独立显卡
 */
@property (nonatomic) BOOL isDiscreteGraphics;

/**
 * @param graphics_name 显卡型号
 */
@property (nonatomic, nonnull) NSString * graphicsName;

/**
 * @param width 主播屏幕宽度(用于后续屏幕分享模式的分辨率控制)
 */
@property (nonatomic) int32_t width;

/**
 * @param height 主播屏幕高度
 */
@property (nonatomic) int32_t height;

/**
 * @param processor_name 处理器名
 */
@property (nonatomic, nonnull) NSString * processorName;

@end
/* optimized_djinni_generated_objc_file */