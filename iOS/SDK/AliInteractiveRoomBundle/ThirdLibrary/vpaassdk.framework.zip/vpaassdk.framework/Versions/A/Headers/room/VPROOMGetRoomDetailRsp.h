// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <vpaassdk/room/VPROOMPluginInstance.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取房间详细信息响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomDetailRsp : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                 title:(nonnull NSString *)title
                                notice:(nonnull NSString *)notice
                               ownerId:(nonnull NSString *)ownerId
                                    uv:(int32_t)uv
                           onlineCount:(int32_t)onlineCount
               pluginInstanceModelList:(nonnull NSArray<VPROOMPluginInstance *> *)pluginInstanceModelList
                                    pv:(int32_t)pv
                             extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                           adminIdList:(nonnull NSArray<NSString *> *)adminIdList;
+ (nonnull instancetype)VPROOMGetRoomDetailRspWithRoomId:(nonnull NSString *)roomId
                                                   title:(nonnull NSString *)title
                                                  notice:(nonnull NSString *)notice
                                                 ownerId:(nonnull NSString *)ownerId
                                                      uv:(int32_t)uv
                                             onlineCount:(int32_t)onlineCount
                                 pluginInstanceModelList:(nonnull NSArray<VPROOMPluginInstance *> *)pluginInstanceModelList
                                                      pv:(int32_t)pv
                                               extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                             adminIdList:(nonnull NSArray<NSString *> *)adminIdList;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param title 房间标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 房间公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param owner_id 房主Id
 */
@property (nonatomic, nonnull) NSString * ownerId;

/**
 * @param uv uv
 */
@property (nonatomic) int32_t uv;

/**
 * @param online_count 在线人数
 */
@property (nonatomic) int32_t onlineCount;

/**
 * @param plugin_instance_model_list 房间活跃的插件列表
 */
@property (nonatomic, nonnull) NSArray<VPROOMPluginInstance *> * pluginInstanceModelList;

/**
 * @param pv 房间用户访问人次
 */
@property (nonatomic) int32_t pv;

/**
 * @param extension 房间扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param admin_id_list 管理员id列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * adminIdList;

@end
/* optimized_djinni_generated_objc_file */