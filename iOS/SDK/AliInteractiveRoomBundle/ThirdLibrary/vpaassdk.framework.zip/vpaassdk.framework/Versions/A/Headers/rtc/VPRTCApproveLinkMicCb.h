// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCApproveLinkMicRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 同意/拒绝申请连麦回调
 */
@protocol VPRTCApproveLinkMicCb

- (void)onSuccess:(nonnull VPRTCApproveLinkMicRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */