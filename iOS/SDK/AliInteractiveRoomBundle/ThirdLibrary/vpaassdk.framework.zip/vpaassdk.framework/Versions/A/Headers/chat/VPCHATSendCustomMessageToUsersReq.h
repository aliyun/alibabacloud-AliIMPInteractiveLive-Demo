// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 指定房间用户发送普通自定义消息请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendCustomMessageToUsersReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                                   body:(nonnull NSString *)body
                           receiverList:(nonnull NSArray<NSString *> *)receiverList;
+ (nonnull instancetype)VPCHATSendCustomMessageToUsersReqWithTopicId:(nonnull NSString *)topicId
                                                                body:(nonnull NSString *)body
                                                        receiverList:(nonnull NSArray<NSString *> *)receiverList;

/**
 * @param topic_id 话题id,聊天插件实例id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param body 消息体
 */
@property (nonatomic, nonnull) NSString * body;

/**
 * @param receiver_list 接收者用户ID列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * receiverList;

@end
/* optimized_djinni_generated_objc_file */