// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// live_Bridging_Header.h
// live_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for liveBridgingHeader.
FOUNDATION_EXPORT double liveBridgingHeaderVersionNumber;

//! Project version string for liveBridgingHeader.
FOUNDATION_EXPORT const unsigned char liveBridgingHeaderVersionString[];

#import <vpaassdk/live/VPLIVELiveModule.h>
#import <vpaassdk/live/VPLIVELiveExtInterface.h>
#import <vpaassdk/live/VPLIVEPublishLiveCb.h>
#import <vpaassdk/live/VPLIVEGetLiveDetailCb.h>
#import <vpaassdk/live/VPLIVEUpdateLiveCb.h>
#import <vpaassdk/live/VPLIVEStartLiveTimingCb.h>
#import <vpaassdk/live/VPLIVEEndLiveTimingCb.h>
#import <vpaassdk/live/VPLIVEStartPlaybackTimingCb.h>
#import <vpaassdk/live/VPLIVEContinuePlaybackTimingCb.h>
#import <vpaassdk/live/VPLIVEEndPlaybackTimingCb.h>
#import <vpaassdk/live/VPLIVEGetLiveStatisticsCb.h>
#import <vpaassdk/live/VPLIVEGetLiveUserStatisticsCb.h>
#import <vpaassdk/live/VPLIVELiveRpcInterface.h>
#import <vpaassdk/live/VPLIVEPublishLiveReq.h>
#import <vpaassdk/live/VPLIVEPublishLiveRsp.h>
#import <vpaassdk/live/VPLIVELive.h>
#import <vpaassdk/live/VPLIVEArtcInfo.h>
#import <vpaassdk/live/VPLIVEGetLiveDetailReq.h>
#import <vpaassdk/live/VPLIVEGetLiveDetailRsp.h>
#import <vpaassdk/live/VPLIVELivePluginCreateReq.h>
#import <vpaassdk/live/VPLIVELivePluginCreateRsp.h>
#import <vpaassdk/live/VPLIVEPlayUrl.h>
#import <vpaassdk/live/VPLIVEUpdateLiveReq.h>
#import <vpaassdk/live/VPLIVEUpdateLiveRsp.h>
#import <vpaassdk/live/VPLIVEStartLiveTimingReq.h>
#import <vpaassdk/live/VPLIVEStartLiveTimingRsp.h>
#import <vpaassdk/live/VPLIVEEndLiveTimingReq.h>
#import <vpaassdk/live/VPLIVEEndLiveTimingRsp.h>
#import <vpaassdk/live/VPLIVEStartPlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEStartPlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEContinuePlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEContinuePlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEEndPlaybackTimingReq.h>
#import <vpaassdk/live/VPLIVEEndPlaybackTimingRsp.h>
#import <vpaassdk/live/VPLIVEGetLiveStatisticsReq.h>
#import <vpaassdk/live/VPLIVEGetLiveStatisticsRsp.h>
#import <vpaassdk/live/VPLIVEGetLiveUserStatisticsReq.h>
#import <vpaassdk/live/VPLIVEGetLiveUserStatisticsRsp.h>
#import <vpaassdk/live/VPLIVEUserLiveStatistics.h>
/* optimized_djinni_generated_objc_file */