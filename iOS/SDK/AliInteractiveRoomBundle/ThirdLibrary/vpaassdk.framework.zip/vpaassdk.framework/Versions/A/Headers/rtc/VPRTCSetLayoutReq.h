// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 设置布局请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCSetLayoutReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                               userIds:(nonnull NSArray<NSString *> *)userIds
                                 model:(int32_t)model;
+ (nonnull instancetype)VPRTCSetLayoutReqWithConfId:(nonnull NSString *)confId
                                            userIds:(nonnull NSArray<NSString *> *)userIds
                                              model:(int32_t)model;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param user_ids 用户ID列表:从左上到右下依次排序
 */
@property (nonatomic, nonnull) NSArray<NSString *> * userIds;

/**
 * @param model 3:九宫格
 */
@property (nonatomic) int32_t model;

@end
/* optimized_djinni_generated_objc_file */