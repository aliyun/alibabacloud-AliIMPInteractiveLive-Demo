// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief sls基本参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGSlsConfig : NSObject
- (nonnull instancetype)initWithEndpoint:(nonnull NSString *)endpoint
                                 project:(nonnull NSString *)project
                                logStore:(nonnull NSString *)logStore;
+ (nonnull instancetype)VPCLOUDCONFIGSlsConfigWithEndpoint:(nonnull NSString *)endpoint
                                                   project:(nonnull NSString *)project
                                                  logStore:(nonnull NSString *)logStore;

/**
 * @param endpoint 接入点
 */
@property (nonatomic, nonnull) NSString * endpoint;

/**
 * @param project 项目名
 */
@property (nonatomic, nonnull) NSString * project;

/**
 * @param log_store 日志仓库
 */
@property (nonatomic, nonnull) NSString * logStore;

@end
/* optimized_djinni_generated_objc_file */