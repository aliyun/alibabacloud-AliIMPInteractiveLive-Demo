// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 上报上传状态请求
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCReportUploadStatusReq : NSObject
- (nonnull instancetype)initWithDocId:(nonnull NSString *)docId
                         uploadStatus:(int32_t)uploadStatus
                               roomId:(nonnull NSString *)roomId;
+ (nonnull instancetype)VPDOCReportUploadStatusReqWithDocId:(nonnull NSString *)docId
                                               uploadStatus:(int32_t)uploadStatus
                                                     roomId:(nonnull NSString *)roomId;

/**
 * @param doc_id 必填，文档ID
 */
@property (nonatomic, nonnull) NSString * docId;

/**
 * @param upload_status 必填，上传状态：0:上传中，1:上传成功，2:上传失败
 */
@property (nonatomic) int32_t uploadStatus;

/**
 * @param room_id 可选，房间Id，用于进行房间鉴权和可靠消息发送
 */
@property (nonatomic, nonnull) NSString * roomId;

@end
/* optimized_djinni_generated_objc_file */