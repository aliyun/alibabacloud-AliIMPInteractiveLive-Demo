// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief STSTokencredentials
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCCredentials : NSObject
- (nonnull instancetype)initWithAccessKeyId:(nonnull NSString *)accessKeyId
                            accessKeySecret:(nonnull NSString *)accessKeySecret
                              securityToken:(nonnull NSString *)securityToken;
+ (nonnull instancetype)VPDOCCredentialsWithAccessKeyId:(nonnull NSString *)accessKeyId
                                        accessKeySecret:(nonnull NSString *)accessKeySecret
                                          securityToken:(nonnull NSString *)securityToken;

/**
 * @param access_key_id STS临时AK
 */
@property (nonatomic, nonnull) NSString * accessKeyId;

/**
 * @param access_key_secret STS临时SK
 */
@property (nonatomic, nonnull) NSString * accessKeySecret;

/**
 * @param security_token STS安全Token
 */
@property (nonatomic, nonnull) NSString * securityToken;

@end
/* optimized_djinni_generated_objc_file */