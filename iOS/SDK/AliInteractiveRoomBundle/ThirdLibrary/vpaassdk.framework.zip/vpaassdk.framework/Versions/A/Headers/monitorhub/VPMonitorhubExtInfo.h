// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>


@interface VPMonitorhubExtInfo : NSObject

- (void)setKey:(nonnull NSString *)key
         value:(nonnull NSString *)value;

- (nonnull NSString *)getKey:(nonnull NSString *)key;

- (void)removeKey:(nonnull NSString *)key;

- (void)clear;

@end
/* optimized_djinni_generated_objc_file */