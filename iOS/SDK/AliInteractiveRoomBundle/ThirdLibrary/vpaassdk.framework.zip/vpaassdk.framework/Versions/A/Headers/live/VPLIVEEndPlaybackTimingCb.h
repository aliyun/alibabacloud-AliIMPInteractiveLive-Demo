// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEEndPlaybackTimingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 结束观看回放计时回调
 */
@protocol VPLIVEEndPlaybackTimingCb

- (void)onSuccess:(nonnull VPLIVEEndPlaybackTimingRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */