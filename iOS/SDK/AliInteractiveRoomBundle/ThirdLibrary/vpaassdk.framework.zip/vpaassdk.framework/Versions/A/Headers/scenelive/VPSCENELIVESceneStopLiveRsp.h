// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 关闭直播响应
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneStopLiveRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPSCENELIVESceneStopLiveRsp;

@end
/* optimized_djinni_generated_objc_file */