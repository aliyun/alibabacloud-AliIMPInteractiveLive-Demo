// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCConfUserModel.h>
#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 邀请人请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCAddMembersReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                       addedCalleeList:(nonnull NSArray<VPRTCConfUserModel *> *)addedCalleeList;
+ (nonnull instancetype)VPRTCAddMembersReqWithConfId:(nonnull NSString *)confId
                                     addedCalleeList:(nonnull NSArray<VPRTCConfUserModel *> *)addedCalleeList;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param added_callee_list 加人列表
 */
@property (nonatomic, nonnull) NSArray<VPRTCConfUserModel *> * addedCalleeList;

@end
/* optimized_djinni_generated_objc_file */