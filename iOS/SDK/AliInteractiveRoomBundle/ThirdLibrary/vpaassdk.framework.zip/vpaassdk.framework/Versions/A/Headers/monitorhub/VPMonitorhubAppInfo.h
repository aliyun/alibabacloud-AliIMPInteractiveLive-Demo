// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>


/**
 * 传入公共字段信息
 */
@interface VPMonitorhubAppInfo : NSObject

- (void)setAppName:(nonnull NSString *)appName;

- (void)setAppVersion:(nonnull NSString *)appVersion;

- (void)setOsName:(nonnull NSString *)osName;

- (void)setOsVersion:(nonnull NSString *)osVersion;

- (void)setDeviceName:(nonnull NSString *)deviceName;

- (void)setDeviceType:(nonnull NSString *)deviceType;

- (void)setDeviceId:(nonnull NSString *)deviceId;

- (void)setAppId:(nonnull NSString *)appId;

- (void)setUid:(nonnull NSString *)uid;

- (void)setPaasSdkVersion:(nonnull NSString *)paassdkVersion;

- (void)setRoomId:(nonnull NSString *)roomId;

- (void)setBizId:(nonnull NSString *)bizId;

- (void)setBizType:(nonnull NSString *)bizType;

- (void)setNetType:(nonnull NSString *)netType;

- (nonnull NSString *)getAppName;

- (nonnull NSString *)getAppVersion;

- (nonnull NSString *)getOsName;

- (nonnull NSString *)getOsVersion;

- (nonnull NSString *)getDeviceName;

- (nonnull NSString *)getDeviceType;

- (nonnull NSString *)getDeviceId;

- (nonnull NSString *)getAppId;

- (nonnull NSString *)getUid;

- (nonnull NSString *)getPaasSdkVersion;

- (nonnull NSString *)getRoomId;

- (nonnull NSString *)getBizType;

- (nonnull NSString *)getBizId;

- (nonnull NSString *)getNetType;

@end
/* optimized_djinni_generated_objc_file */