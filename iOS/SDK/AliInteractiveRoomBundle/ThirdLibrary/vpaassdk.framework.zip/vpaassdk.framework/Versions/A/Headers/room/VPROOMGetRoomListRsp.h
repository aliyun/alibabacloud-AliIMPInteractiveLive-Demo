// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <vpaassdk/room/VPROOMRoomBasicInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 分页获取房间的在线列表响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMGetRoomListRsp : NSObject
- (nonnull instancetype)initWithRoomInfoList:(nonnull NSArray<VPROOMRoomBasicInfo *> *)roomInfoList
                                       total:(int32_t)total
                                     hasMore:(BOOL)hasMore;
+ (nonnull instancetype)VPROOMGetRoomListRspWithRoomInfoList:(nonnull NSArray<VPROOMRoomBasicInfo *> *)roomInfoList
                                                       total:(int32_t)total
                                                     hasMore:(BOOL)hasMore;

/**
 * @param room_info_list 租户下的房间列表基础信息
 */
@property (nonatomic, nonnull) NSArray<VPROOMRoomBasicInfo *> * roomInfoList;

/**
 * @param total 租户下的房间列表总数
 */
@property (nonatomic) int32_t total;

/**
 * @param has_more 租户下的房间列表总数
 */
@property (nonatomic) BOOL hasMore;

@end
/* optimized_djinni_generated_objc_file */