// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 申请/取消申请连麦请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCApplyLinkMicReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId
                                 apply:(BOOL)apply;
+ (nonnull instancetype)VPRTCApplyLinkMicReqWithConfId:(nonnull NSString *)confId
                                                 apply:(BOOL)apply;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param apply true:申请连麦，false：取消申请连麦
 */
@property (nonatomic) BOOL apply;

@end
/* optimized_djinni_generated_objc_file */