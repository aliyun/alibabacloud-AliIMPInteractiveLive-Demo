// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBStopWhiteboardRecordingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 结束白板录制回调
 */
@protocol VPWBStopWhiteboardRecordingCb

- (void)onSuccess:(nonnull VPWBStopWhiteboardRecordingRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */