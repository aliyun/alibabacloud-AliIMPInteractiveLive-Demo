// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 参会者核心模型
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCConfUserModel : NSObject
- (nonnull instancetype)initWithUserId:(nonnull NSString *)userId
                              nickname:(nonnull NSString *)nickname
                             extension:(nonnull NSString *)extension
                                status:(int32_t)status
                             errorCode:(nonnull NSString *)errorCode
                          cameraStatus:(int32_t)cameraStatus
                        micphoneStatus:(int32_t)micphoneStatus
                                source:(int32_t)source
                              sourceId:(nonnull NSString *)sourceId
                              deviceId:(nonnull NSString *)deviceId
                             enterTime:(int64_t)enterTime
                             leaveTime:(int64_t)leaveTime
                              tenantId:(nonnull NSString *)tenantId
                              duration:(int64_t)duration
                           passiveMute:(BOOL)passiveMute
                          positiveMute:(BOOL)positiveMute;
+ (nonnull instancetype)VPRTCConfUserModelWithUserId:(nonnull NSString *)userId
                                            nickname:(nonnull NSString *)nickname
                                           extension:(nonnull NSString *)extension
                                              status:(int32_t)status
                                           errorCode:(nonnull NSString *)errorCode
                                        cameraStatus:(int32_t)cameraStatus
                                      micphoneStatus:(int32_t)micphoneStatus
                                              source:(int32_t)source
                                            sourceId:(nonnull NSString *)sourceId
                                            deviceId:(nonnull NSString *)deviceId
                                           enterTime:(int64_t)enterTime
                                           leaveTime:(int64_t)leaveTime
                                            tenantId:(nonnull NSString *)tenantId
                                            duration:(int64_t)duration
                                         passiveMute:(BOOL)passiveMute
                                        positiveMute:(BOOL)positiveMute;

/**
 * @param user_id 用户ID
 */
@property (nonatomic, nonnull) NSString * userId;

/**
 * @param nickname 用户昵称
 */
@property (nonatomic, nonnull) NSString * nickname;

/**
 * @param extension 扩展信息
 */
@property (nonatomic, nonnull) NSString * extension;

/**
 * @param status 入会状态1：初始状态2：呼叫状态3：会议中4：入会失败5：被踢出6：离会
 */
@property (nonatomic) int32_t status;

/**
 * @param error_code 入会失败错误码
 */
@property (nonatomic, nonnull) NSString * errorCode;

/**
 * @param camera_status camera状态，服务端透传，0：关闭，1：打开
 */
@property (nonatomic) int32_t cameraStatus;

/**
 * @param micphone_status mic状态，服务端透传，0：关闭，1：打开
 */
@property (nonatomic) int32_t micphoneStatus;

/**
 * @param source 媒体引擎类型，0:alirtc1:mcs
 */
@property (nonatomic) int32_t source;

/**
 * @param source_id 媒体引擎用户ID
 */
@property (nonatomic, nonnull) NSString * sourceId;

/**
 * @param device_id 设备ID
 */
@property (nonatomic, nonnull) NSString * deviceId;

/**
 * @param enter_time 会话开始时间戳，utc，毫秒
 */
@property (nonatomic) int64_t enterTime;

/**
 * @param leave_time 会话结束时间戳，utc，毫秒
 */
@property (nonatomic) int64_t leaveTime;

/**
 * @param tenant_id 租户ID
 */
@property (nonatomic, nonnull) NSString * tenantId;

/**
 * @param duration 累计入会时长（秒）
 */
@property (nonatomic) int64_t duration;

/**
 * @param passive_mute 被静音状态，true:被静音，false：没有被静音
 */
@property (nonatomic) BOOL passiveMute;

/**
 * @param positive_mute 主动禁音，true:主动禁音，false:没有禁音
 */
@property (nonatomic) BOOL positiveMute;

@end
/* optimized_djinni_generated_objc_file */