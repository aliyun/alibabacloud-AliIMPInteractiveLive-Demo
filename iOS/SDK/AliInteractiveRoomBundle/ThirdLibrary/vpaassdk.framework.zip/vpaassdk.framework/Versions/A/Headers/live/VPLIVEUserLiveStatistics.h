// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 用户观看直播信息统计
 */
VPLIVE_OBJECTC_EXPORT
@interface VPLIVEUserLiveStatistics : NSObject
- (nonnull instancetype)initWithWatchLiveTime:(int64_t)watchLiveTime
                            watchPlaybackTime:(int64_t)watchPlaybackTime
                                          uid:(nonnull NSString *)uid;
+ (nonnull instancetype)VPLIVEUserLiveStatisticsWithWatchLiveTime:(int64_t)watchLiveTime
                                                watchPlaybackTime:(int64_t)watchPlaybackTime
                                                              uid:(nonnull NSString *)uid;

/**
 * @param watch_live_time 观看直播时长
 */
@property (nonatomic) int64_t watchLiveTime;

/**
 * @param watch_playback_time 观看回放时长
 */
@property (nonatomic) int64_t watchPlaybackTime;

/**
 * @param uid 用户id
 */
@property (nonatomic, nonnull) NSString * uid;

@end
/* optimized_djinni_generated_objc_file */