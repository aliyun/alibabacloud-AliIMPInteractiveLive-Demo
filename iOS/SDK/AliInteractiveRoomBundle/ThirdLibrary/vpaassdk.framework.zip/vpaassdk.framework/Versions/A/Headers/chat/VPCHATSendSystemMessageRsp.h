// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 发送系统消息响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendSystemMessageRsp : NSObject
- (nonnull instancetype)initWithMessageId:(nonnull NSString *)messageId;
+ (nonnull instancetype)VPCHATSendSystemMessageRspWithMessageId:(nonnull NSString *)messageId;

/**
 * @param message_id 消息唯一ID标识
 */
@property (nonatomic, nonnull) NSString * messageId;

@end
/* optimized_djinni_generated_objc_file */