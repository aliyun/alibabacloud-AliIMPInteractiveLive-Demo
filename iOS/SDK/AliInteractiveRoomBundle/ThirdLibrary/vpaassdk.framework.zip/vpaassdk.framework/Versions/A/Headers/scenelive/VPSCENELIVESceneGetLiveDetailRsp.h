// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEArtcInfo.h>
#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <vpaassdk/scenelive/VPSCENELIVEPluginInstanceInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询直播详情响应
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneGetLiveDetailRsp : NSObject
- (nonnull instancetype)initWithAppId:(nonnull NSString *)appId
                               liveId:(nonnull NSString *)liveId
                               status:(int32_t)status
                               roomId:(nonnull NSString *)roomId
                               chatId:(nonnull NSString *)chatId
                                title:(nonnull NSString *)title
                               notice:(nonnull NSString *)notice
                             coverUrl:(nonnull NSString *)coverUrl
                             anchorId:(nonnull NSString *)anchorId
                                   uv:(int32_t)uv
                          onlineCount:(int32_t)onlineCount
                          playbackUrl:(nonnull NSString *)playbackUrl
                           createTime:(int64_t)createTime
                              endTime:(int64_t)endTime
                              pushUrl:(nonnull NSString *)pushUrl
                              liveUrl:(nonnull NSString *)liveUrl
               pluginInstanceInfoList:(nonnull NSArray<VPSCENELIVEPluginInstanceInfo *> *)pluginInstanceInfoList
                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                           anchorNick:(nonnull NSString *)anchorNick
                               hlsUrl:(nonnull NSString *)hlsUrl
                             artcInfo:(nonnull VPSCENELIVEArtcInfo *)artcInfo
                          adminIdList:(nonnull NSArray<NSString *> *)adminIdList
                        enableLinkMic:(BOOL)enableLinkMic
                               confId:(nonnull NSString *)confId
                                   pv:(int32_t)pv;
+ (nonnull instancetype)VPSCENELIVESceneGetLiveDetailRspWithAppId:(nonnull NSString *)appId
                                                           liveId:(nonnull NSString *)liveId
                                                           status:(int32_t)status
                                                           roomId:(nonnull NSString *)roomId
                                                           chatId:(nonnull NSString *)chatId
                                                            title:(nonnull NSString *)title
                                                           notice:(nonnull NSString *)notice
                                                         coverUrl:(nonnull NSString *)coverUrl
                                                         anchorId:(nonnull NSString *)anchorId
                                                               uv:(int32_t)uv
                                                      onlineCount:(int32_t)onlineCount
                                                      playbackUrl:(nonnull NSString *)playbackUrl
                                                       createTime:(int64_t)createTime
                                                          endTime:(int64_t)endTime
                                                          pushUrl:(nonnull NSString *)pushUrl
                                                          liveUrl:(nonnull NSString *)liveUrl
                                           pluginInstanceInfoList:(nonnull NSArray<VPSCENELIVEPluginInstanceInfo *> *)pluginInstanceInfoList
                                                        extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                                       anchorNick:(nonnull NSString *)anchorNick
                                                           hlsUrl:(nonnull NSString *)hlsUrl
                                                         artcInfo:(nonnull VPSCENELIVEArtcInfo *)artcInfo
                                                      adminIdList:(nonnull NSArray<NSString *> *)adminIdList
                                                    enableLinkMic:(BOOL)enableLinkMic
                                                           confId:(nonnull NSString *)confId
                                                               pv:(int32_t)pv;

/**
 * @param app_id 应用id
 */
@property (nonatomic, nonnull) NSString * appId;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param status 直播状态，0-在播1-下播
 */
@property (nonatomic) int32_t status;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param chat_id 聊天id
 */
@property (nonatomic, nonnull) NSString * chatId;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param cover_url 封面
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param anchor_id 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param uv 访问数
 */
@property (nonatomic) int32_t uv;

/**
 * @param online_count 在线数
 */
@property (nonatomic) int32_t onlineCount;

/**
 * @param playback_url 回放地址
 */
@property (nonatomic, nonnull) NSString * playbackUrl;

/**
 * @param create_time 创建时间，单位：毫秒
 */
@property (nonatomic) int64_t createTime;

/**
 * @param end_time 结束时间，单位：毫秒
 */
@property (nonatomic) int64_t endTime;

/**
 * @param push_url 推流地址
 */
@property (nonatomic, nonnull) NSString * pushUrl;

/**
 * @param live_url 拉流地址
 */
@property (nonatomic, nonnull) NSString * liveUrl;

/**
 * @param plugin_instance_info_list 插件列表
 */
@property (nonatomic, nonnull) NSArray<VPSCENELIVEPluginInstanceInfo *> * pluginInstanceInfoList;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param anchor_nick 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNick;

/**
 * @param hls_url hls播放地址
 */
@property (nonatomic, nonnull) NSString * hlsUrl;

/**
 * @param artc_info artc播放地址
 */
@property (nonatomic, nonnull) VPSCENELIVEArtcInfo * artcInfo;

/**
 * @param admin_id_list 管理员id列表
 */
@property (nonatomic, nonnull) NSArray<NSString *> * adminIdList;

/**
 * @param enable_link_mic 是否启用连麦
 */
@property (nonatomic) BOOL enableLinkMic;

/**
 * @param conf_id RTC/会议id
 */
@property (nonatomic, nonnull) NSString * confId;

/**
 * @param pv pv
 */
@property (nonatomic) int32_t pv;

@end
/* optimized_djinni_generated_objc_file */