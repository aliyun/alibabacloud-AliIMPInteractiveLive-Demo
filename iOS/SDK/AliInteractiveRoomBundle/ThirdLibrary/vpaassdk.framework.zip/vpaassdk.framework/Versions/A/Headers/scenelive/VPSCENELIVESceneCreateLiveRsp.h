// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEArtcInfo.h>
#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <vpaassdk/scenelive/VPSCENELIVEPluginInstanceInfo.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建直播响应
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneCreateLiveRsp : NSObject
- (nonnull instancetype)initWithAppId:(nonnull NSString *)appId
                               liveId:(nonnull NSString *)liveId
                               roomId:(nonnull NSString *)roomId
                               chatId:(nonnull NSString *)chatId
                                title:(nonnull NSString *)title
                               notice:(nonnull NSString *)notice
                             coverUrl:(nonnull NSString *)coverUrl
                             anchorId:(nonnull NSString *)anchorId
                          playbackUrl:(nonnull NSString *)playbackUrl
                              pushUrl:(nonnull NSString *)pushUrl
                              liveUrl:(nonnull NSString *)liveUrl
               pluginInstanceInfoList:(nonnull NSArray<VPSCENELIVEPluginInstanceInfo *> *)pluginInstanceInfoList
                            extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                           anchorNick:(nonnull NSString *)anchorNick
                               hlsUrl:(nonnull NSString *)hlsUrl
                             artcInfo:(nonnull VPSCENELIVEArtcInfo *)artcInfo
                        enableLinkMic:(BOOL)enableLinkMic;
+ (nonnull instancetype)VPSCENELIVESceneCreateLiveRspWithAppId:(nonnull NSString *)appId
                                                        liveId:(nonnull NSString *)liveId
                                                        roomId:(nonnull NSString *)roomId
                                                        chatId:(nonnull NSString *)chatId
                                                         title:(nonnull NSString *)title
                                                        notice:(nonnull NSString *)notice
                                                      coverUrl:(nonnull NSString *)coverUrl
                                                      anchorId:(nonnull NSString *)anchorId
                                                   playbackUrl:(nonnull NSString *)playbackUrl
                                                       pushUrl:(nonnull NSString *)pushUrl
                                                       liveUrl:(nonnull NSString *)liveUrl
                                        pluginInstanceInfoList:(nonnull NSArray<VPSCENELIVEPluginInstanceInfo *> *)pluginInstanceInfoList
                                                     extension:(nonnull NSDictionary<NSString *, NSString *> *)extension
                                                    anchorNick:(nonnull NSString *)anchorNick
                                                        hlsUrl:(nonnull NSString *)hlsUrl
                                                      artcInfo:(nonnull VPSCENELIVEArtcInfo *)artcInfo
                                                 enableLinkMic:(BOOL)enableLinkMic;

/**
 * @param app_id 应用id
 */
@property (nonatomic, nonnull) NSString * appId;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param room_id 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param chat_id 聊天id
 */
@property (nonatomic, nonnull) NSString * chatId;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param cover_url 封面图
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param anchor_id 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param playback_url 直播回放地址
 */
@property (nonatomic, nonnull) NSString * playbackUrl;

/**
 * @param push_url 推流地址
 */
@property (nonatomic, nonnull) NSString * pushUrl;

/**
 * @param live_url 拉流地址
 */
@property (nonatomic, nonnull) NSString * liveUrl;

/**
 * @param plugin_instance_info_list 插件列表
 */
@property (nonatomic, nonnull) NSArray<VPSCENELIVEPluginInstanceInfo *> * pluginInstanceInfoList;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

/**
 * @param anchor_nick 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNick;

/**
 * @param hls_url hlsUrl播放地址
 */
@property (nonatomic, nonnull) NSString * hlsUrl;

/**
 * @param artc_info artc播放地址
 */
@property (nonatomic, nonnull) VPSCENELIVEArtcInfo * artcInfo;

/**
 * @param enable_link_mic 是否启用连麦
 */
@property (nonatomic) BOOL enableLinkMic;

@end
/* optimized_djinni_generated_objc_file */