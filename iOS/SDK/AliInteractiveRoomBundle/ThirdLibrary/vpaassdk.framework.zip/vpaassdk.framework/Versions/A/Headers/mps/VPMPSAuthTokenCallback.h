// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>
#import <libdps/DPSAuthTokenExpiredReason.h>
#import <libdps/DPSAuthTokenGotCallback.h>


/**
 * 请求获取Token回调
 */
@protocol VPMPSAuthTokenCallback

- (void)onCallback:(nonnull NSString *)userId
             onGot:(nullable DPSAuthTokenGotCallback *)onGot
            reason:(DPSAuthTokenExpiredReason)reason;

@end
/* optimized_djinni_generated_objc_file */