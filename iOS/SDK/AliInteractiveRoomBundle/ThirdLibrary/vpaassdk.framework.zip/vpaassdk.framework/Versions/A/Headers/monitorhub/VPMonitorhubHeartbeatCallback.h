// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <Foundation/Foundation.h>


/**
 * 定时心跳回调
 * 只需要准备数据，不需要调用发送
 */
@protocol VPMonitorhubHeartbeatCallback

- (nonnull NSDictionary<NSString *, NSString *> *)onHeartbeatProcess;

@end
/* optimized_djinni_generated_objc_file */