// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.// sceneclass_Bridging_Header.h
// sceneclass_Bridging_Header

#import <Foundation/Foundation.h>

//! Project version number for sceneclassBridgingHeader.
FOUNDATION_EXPORT double sceneclassBridgingHeaderVersionNumber;

//! Project version string for sceneclassBridgingHeader.
FOUNDATION_EXPORT const unsigned char sceneclassBridgingHeaderVersionString[];

#import <vpaassdk/sceneclass/VPSCENECLASSSceneclassModule.h>
#import <vpaassdk/sceneclass/VPSCENECLASSSceneclassExtInterface.h>
#import <vpaassdk/sceneclass/VPSCENECLASSCreateClassCb.h>
#import <vpaassdk/sceneclass/VPSCENECLASSGetClassDetailCb.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStartClassCb.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStopClassCb.h>
#import <vpaassdk/sceneclass/VPSCENECLASSSceneclassRpcInterface.h>
#import <vpaassdk/sceneclass/VPSCENECLASSCreateClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSCreateClassRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSGetClassDetailReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSGetClassDetailRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStartClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStartClassRsp.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStopClassReq.h>
#import <vpaassdk/sceneclass/VPSCENECLASSStopClassRsp.h>
/* optimized_djinni_generated_objc_file */