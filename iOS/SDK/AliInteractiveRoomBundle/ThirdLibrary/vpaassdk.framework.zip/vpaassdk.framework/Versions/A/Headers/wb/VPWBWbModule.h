// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPWBWbExtInterface;
@class VPWBWbModule;
@class VPWBWbRpcInterface;


VPWB_OBJECTC_EXPORT
@interface VPWBWbModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPWBWbModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPWBWbRpcInterface *)getRpcInterface;

- (nullable VPWBWbExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */