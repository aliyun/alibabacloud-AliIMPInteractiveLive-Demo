// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/sceneclass/VPSCENECLASSExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建课
 */
VPSCENECLASS_OBJECTC_EXPORT
@interface VPSCENECLASSCreateClassReq : NSObject
- (nonnull instancetype)initWithTitle:(nonnull NSString *)title
                       createNickname:(nonnull NSString *)createNickname;
+ (nonnull instancetype)VPSCENECLASSCreateClassReqWithTitle:(nonnull NSString *)title
                                             createNickname:(nonnull NSString *)createNickname;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param create_nickname 创建人昵称
 */
@property (nonatomic, nonnull) NSString * createNickname;

@end
/* optimized_djinni_generated_objc_file */