// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEStartLiveTimingRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 开始观看直播计时回调
 */
@protocol VPLIVEStartLiveTimingCb

- (void)onSuccess:(nonnull VPLIVEStartLiveTimingRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */