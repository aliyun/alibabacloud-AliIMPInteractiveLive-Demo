// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 更新直播信息请求
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneUpdateLiveReq : NSObject
- (nonnull instancetype)initWithLiveId:(nonnull NSString *)liveId
                                 title:(nonnull NSString *)title
                                notice:(nonnull NSString *)notice
                              coverUrl:(nonnull NSString *)coverUrl
                              anchorId:(nonnull NSString *)anchorId
                            anchorNick:(nonnull NSString *)anchorNick
                             extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;
+ (nonnull instancetype)VPSCENELIVESceneUpdateLiveReqWithLiveId:(nonnull NSString *)liveId
                                                          title:(nonnull NSString *)title
                                                         notice:(nonnull NSString *)notice
                                                       coverUrl:(nonnull NSString *)coverUrl
                                                       anchorId:(nonnull NSString *)anchorId
                                                     anchorNick:(nonnull NSString *)anchorNick
                                                      extension:(nonnull NSDictionary<NSString *, NSString *> *)extension;

/**
 * @param live_id 直播id
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * @param title 标题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * @param notice 公告
 */
@property (nonatomic, nonnull) NSString * notice;

/**
 * @param cover_url 封面
 */
@property (nonatomic, nonnull) NSString * coverUrl;

/**
 * @param anchor_id 主播id
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * @param anchor_nick 主播昵称
 */
@property (nonatomic, nonnull) NSString * anchorNick;

/**
 * @param extension 扩展字段
 */
@property (nonatomic, nonnull) NSDictionary<NSString *, NSString *> * extension;

@end
/* optimized_djinni_generated_objc_file */