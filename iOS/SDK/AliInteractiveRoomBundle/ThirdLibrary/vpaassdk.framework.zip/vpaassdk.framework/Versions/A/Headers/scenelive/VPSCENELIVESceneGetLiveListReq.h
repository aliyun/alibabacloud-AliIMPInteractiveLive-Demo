// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/scenelive/VPSCENELIVEExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询直播列表请求
 */
VPSCENELIVE_OBJECTC_EXPORT
@interface VPSCENELIVESceneGetLiveListReq : NSObject
- (nonnull instancetype)initWithStatus:(int32_t)status
                            pageNumber:(int32_t)pageNumber
                              pageSize:(int32_t)pageSize;
+ (nonnull instancetype)VPSCENELIVESceneGetLiveListReqWithStatus:(int32_t)status
                                                      pageNumber:(int32_t)pageNumber
                                                        pageSize:(int32_t)pageSize;

/**
 * @param status 直播状态，0-直播中1-关闭，传空返回所有状态
 */
@property (nonatomic) int32_t status;

/**
 * @param page_number 页码，从1开始
 */
@property (nonatomic) int32_t pageNumber;

/**
 * @param page_size 请求房间数量
 */
@property (nonatomic) int32_t pageSize;

@end
/* optimized_djinni_generated_objc_file */