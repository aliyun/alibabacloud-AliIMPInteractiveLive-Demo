// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/meta_ai/VPMETA_AIExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建商品响应
 */
VPMETA_AI_OBJECTC_EXPORT
@interface VPMETA_AICreateModelRsp : NSObject
- (nonnull instancetype)initWithOssObject:(nonnull NSString *)ossObject
                                     uuid:(nonnull NSString *)uuid
                              accessKeyId:(nonnull NSString *)accessKeyId
                          accessKeySecret:(nonnull NSString *)accessKeySecret
                            securityToken:(nonnull NSString *)securityToken
                                 endpoint:(nonnull NSString *)endpoint
                                   bucket:(nonnull NSString *)bucket
                                  success:(BOOL)success
                             errorMessage:(nonnull NSString *)errorMessage;
+ (nonnull instancetype)VPMETA_AICreateModelRspWithOssObject:(nonnull NSString *)ossObject
                                                        uuid:(nonnull NSString *)uuid
                                                 accessKeyId:(nonnull NSString *)accessKeyId
                                             accessKeySecret:(nonnull NSString *)accessKeySecret
                                               securityToken:(nonnull NSString *)securityToken
                                                    endpoint:(nonnull NSString *)endpoint
                                                      bucket:(nonnull NSString *)bucket
                                                     success:(BOOL)success
                                                errorMessage:(nonnull NSString *)errorMessage;

/**
 * @param oss_object bucket下object路径
 */
@property (nonatomic, nonnull) NSString * ossObject;

/**
 * @param uuid 商品uuid
 */
@property (nonatomic, nonnull) NSString * uuid;

/**
 * @param access_key_id 临时accessKeyId
 */
@property (nonatomic, nonnull) NSString * accessKeyId;

/**
 * @param access_key_secret 临时accessKeySecret
 */
@property (nonatomic, nonnull) NSString * accessKeySecret;

/**
 * @param security_token 临时securityToken
 */
@property (nonatomic, nonnull) NSString * securityToken;

/**
 * @param endpoint ossendpoint
 */
@property (nonatomic, nonnull) NSString * endpoint;

/**
 * @param bucket bucket
 */
@property (nonatomic, nonnull) NSString * bucket;

/**
 * @param success 创建成功
 */
@property (nonatomic) BOOL success;

/**
 * @param error_message 错误码
 */
@property (nonatomic, nonnull) NSString * errorMessage;

@end
/* optimized_djinni_generated_objc_file */