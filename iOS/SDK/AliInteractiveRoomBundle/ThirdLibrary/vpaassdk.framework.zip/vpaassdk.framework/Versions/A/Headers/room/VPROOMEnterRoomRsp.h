// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 用户进入房间响应
 */
VPROOM_OBJECTC_EXPORT
@interface VPROOMEnterRoomRsp : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPROOMEnterRoomRsp;

@end
/* optimized_djinni_generated_objc_file */