// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 指定房间用户发送普通自定义消息响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATSendCustomMessageToUsersRsp : NSObject
- (nonnull instancetype)initWithMessageId:(nonnull NSString *)messageId;
+ (nonnull instancetype)VPCHATSendCustomMessageToUsersRspWithMessageId:(nonnull NSString *)messageId;

/**
 * @param message_id 消息唯一ID标识
 */
@property (nonatomic, nonnull) NSString * messageId;

@end
/* optimized_djinni_generated_objc_file */