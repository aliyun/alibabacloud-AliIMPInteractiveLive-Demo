// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMCreateLiveRsp : NSObject
- (nonnull instancetype)initWithAnchorId:(nonnull NSString *)anchorId
                                  liveId:(nonnull NSString *)liveId
                                   title:(nonnull NSString *)title
                                 playUrl:(nonnull NSString *)playUrl
                              createDate:(int64_t)createDate
                                 endDate:(int64_t)endDate
                            preStartDate:(int64_t)preStartDate
                              preEndDate:(int64_t)preEndDate
                                duration:(int64_t)duration
                                 pushUrl:(nonnull NSString *)pushUrl
                                 liveUrl:(nonnull NSString *)liveUrl
                                  status:(int32_t)status
                            introduction:(nonnull NSString *)introduction;
+ (nonnull instancetype)VPROOMCreateLiveRspWithAnchorId:(nonnull NSString *)anchorId
                                                 liveId:(nonnull NSString *)liveId
                                                  title:(nonnull NSString *)title
                                                playUrl:(nonnull NSString *)playUrl
                                             createDate:(int64_t)createDate
                                                endDate:(int64_t)endDate
                                           preStartDate:(int64_t)preStartDate
                                             preEndDate:(int64_t)preEndDate
                                               duration:(int64_t)duration
                                                pushUrl:(nonnull NSString *)pushUrl
                                                liveUrl:(nonnull NSString *)liveUrl
                                                 status:(int32_t)status
                                           introduction:(nonnull NSString *)introduction;

/**
 * 主播ID
 */
@property (nonatomic, nonnull) NSString * anchorId;

/**
 * 直播uuid
 */
@property (nonatomic, nonnull) NSString * liveId;

/**
 * 主题
 */
@property (nonatomic, nonnull) NSString * title;

/**
 * 播放url
 */
@property (nonatomic, nonnull) NSString * playUrl;

/**
 * 创建日期，utc时间
 */
@property (nonatomic) int64_t createDate;

/**
 * 结束日期，utc时间
 */
@property (nonatomic) int64_t endDate;

/**
 * 预计开始日期，utc时间
 */
@property (nonatomic) int64_t preStartDate;

/**
 * 预计结束日期，utc时间
 */
@property (nonatomic) int64_t preEndDate;

/**
 * 视频时长
 */
@property (nonatomic) int64_t duration;

/**
 * 推流url
 */
@property (nonatomic, nonnull) NSString * pushUrl;

/**
 * 拉流url
 */
@property (nonatomic, nonnull) NSString * liveUrl;

/**
 * 直播状态 0：未开始 1：直播中 2：直播结束
 */
@property (nonatomic) int32_t status;

/**
 * 直播简介
 */
@property (nonatomic, nonnull) NSString * introduction;

@end
/* optimized_djinni_generated_objc_file */