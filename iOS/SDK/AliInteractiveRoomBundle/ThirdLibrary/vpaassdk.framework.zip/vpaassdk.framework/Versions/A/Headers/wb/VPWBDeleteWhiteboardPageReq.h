// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 删除白板单页请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBDeleteWhiteboardPageReq : NSObject
- (nonnull instancetype)initWithWhiteboardId:(nonnull NSString *)whiteboardId
                               deletePageNum:(int32_t)deletePageNum;
+ (nonnull instancetype)VPWBDeleteWhiteboardPageReqWithWhiteboardId:(nonnull NSString *)whiteboardId
                                                      deletePageNum:(int32_t)deletePageNum;

/**
 * @param whiteboard_id 白板Id
 */
@property (nonatomic, nonnull) NSString * whiteboardId;

/**
 * @param delete_page_num 删除页码
 */
@property (nonatomic) int32_t deletePageNum;

@end
/* optimized_djinni_generated_objc_file */