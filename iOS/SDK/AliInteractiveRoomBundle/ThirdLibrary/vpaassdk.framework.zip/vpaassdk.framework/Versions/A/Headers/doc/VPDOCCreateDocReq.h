// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/doc/VPDOCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 创建文档请求
 */
VPDOC_OBJECTC_EXPORT
@interface VPDOCCreateDocReq : NSObject
- (nonnull instancetype)initWithDocName:(nonnull NSString *)docName
                                docType:(nonnull NSString *)docType
                                 roomId:(nonnull NSString *)roomId
                             permission:(nonnull NSString *)permission;
+ (nonnull instancetype)VPDOCCreateDocReqWithDocName:(nonnull NSString *)docName
                                             docType:(nonnull NSString *)docType
                                              roomId:(nonnull NSString *)roomId
                                          permission:(nonnull NSString *)permission;

/**
 * @param doc_name 必填，文档名称
 */
@property (nonatomic, nonnull) NSString * docName;

/**
 * @param doc_type 可选，文档类型，为空则从文档名称提取文件后缀，举例：ppt,pptx,pdf,png,jpg
 */
@property (nonatomic, nonnull) NSString * docType;

/**
 * @param room_id 可选，房间Id，用于进行房间鉴权和可靠消息发送
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 * @param permission 可选，用户oss权限，private-私有，public-共有
 */
@property (nonatomic, nonnull) NSString * permission;

@end
/* optimized_djinni_generated_objc_file */