// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/cloudconfig/VPCLOUDCONFIGExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief web端参数
 */
VPCLOUDCONFIG_OBJECTC_EXPORT
@interface VPCLOUDCONFIGWebSystemInfoV2 : NSObject
- (nonnull instancetype)initWithPlatform:(nonnull NSString *)platform;
+ (nonnull instancetype)VPCLOUDCONFIGWebSystemInfoV2WithPlatform:(nonnull NSString *)platform;

@property (nonatomic, nonnull) NSString * platform;

@end
/* optimized_djinni_generated_objc_file */