// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/monitorhub/VPMONITORHUBExportDelc.h>
#import <Foundation/Foundation.h>

VPMONITORHUB_OBJECTC_EXPORT
@interface VPMonitorhubNetType : NSObject
- (nonnull instancetype)init;
+ (nonnull instancetype)VPMonitorhubNetType;

@end

extern NSString * __nonnull const VPMonitorhubNetTypeNetNoWire;
extern NSString * __nonnull const VPMonitorhubNetTypeNetWire;
extern NSString * __nonnull const VPMonitorhubNetTypeNet3G;
extern NSString * __nonnull const VPMonitorhubNetTypeNet4G;
extern NSString * __nonnull const VPMonitorhubNetTypeNet5G;
extern NSString * __nonnull const VPMonitorhubNetTypeNetWiFi;
extern NSString * __nonnull const VPMonitorhubNetTypeNetUnknown;
/* optimized_djinni_generated_objc_file */