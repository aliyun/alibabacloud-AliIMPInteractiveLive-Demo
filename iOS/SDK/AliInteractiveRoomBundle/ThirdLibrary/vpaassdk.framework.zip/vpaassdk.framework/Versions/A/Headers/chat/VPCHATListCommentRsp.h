// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATCommentModel.h>
#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询弹幕响应
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATListCommentRsp : NSObject
- (nonnull instancetype)initWithTotal:(int32_t)total
                     commentModelList:(nonnull NSArray<VPCHATCommentModel *> *)commentModelList
                              hasMore:(BOOL)hasMore;
+ (nonnull instancetype)VPCHATListCommentRspWithTotal:(int32_t)total
                                     commentModelList:(nonnull NSArray<VPCHATCommentModel *> *)commentModelList
                                              hasMore:(BOOL)hasMore;

/**
 * @param total 总数
 */
@property (nonatomic) int32_t total;

/**
 * @param comment_model_list 返回的弹幕消息列表
 */
@property (nonatomic, nonnull) NSArray<VPCHATCommentModel *> * commentModelList;

/**
 * @param has_more 是否还剩数据
 */
@property (nonatomic) BOOL hasMore;

@end
/* optimized_djinni_generated_objc_file */