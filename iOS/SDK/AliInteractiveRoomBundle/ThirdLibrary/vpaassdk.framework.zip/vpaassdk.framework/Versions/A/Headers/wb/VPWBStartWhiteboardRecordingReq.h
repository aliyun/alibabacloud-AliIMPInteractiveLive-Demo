// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/wb/VPWBExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 开始白板录制请求
 */
VPWB_OBJECTC_EXPORT
@interface VPWBStartWhiteboardRecordingReq : NSObject
- (nonnull instancetype)initWithDocKey:(nonnull NSString *)docKey;
+ (nonnull instancetype)VPWBStartWhiteboardRecordingReqWithDocKey:(nonnull NSString *)docKey;

/**
 * @param doc_key 需要录制的白板文档标识符
 */
@property (nonatomic, nonnull) NSString * docKey;

@end
/* optimized_djinni_generated_objc_file */