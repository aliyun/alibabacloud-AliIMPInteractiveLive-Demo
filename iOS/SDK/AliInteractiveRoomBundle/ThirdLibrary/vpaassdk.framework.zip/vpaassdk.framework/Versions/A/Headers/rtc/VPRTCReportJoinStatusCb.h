// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCReportJoinStatusRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 上报入会状态回调
 */
@protocol VPRTCReportJoinStatusCb

- (void)onSuccess:(nonnull VPRTCReportJoinStatusRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */