// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMExportDelc.h>
#import <Foundation/Foundation.h>

VPROOM_OBJECTC_EXPORT
@interface VPROOMDestroyChatReq : NSObject
- (nonnull instancetype)initWithRoomId:(nonnull NSString *)roomId
                                chatId:(nonnull NSString *)chatId;
+ (nonnull instancetype)VPROOMDestroyChatReqWithRoomId:(nonnull NSString *)roomId
                                                chatId:(nonnull NSString *)chatId;

/**
 * 房间id
 */
@property (nonatomic, nonnull) NSString * roomId;

/**
 *chat id
 */
@property (nonatomic, nonnull) NSString * chatId;

@end
/* optimized_djinni_generated_objc_file */