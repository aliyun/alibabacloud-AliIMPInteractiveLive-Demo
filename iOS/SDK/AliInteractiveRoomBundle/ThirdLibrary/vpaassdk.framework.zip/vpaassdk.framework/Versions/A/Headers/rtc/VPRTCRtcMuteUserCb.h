// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCRtcMuteUserRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 命令单人禁音/取消禁音回调
 */
@protocol VPRTCRtcMuteUserCb

- (void)onSuccess:(nonnull VPRTCRtcMuteUserRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */