// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/room/VPROOMGetRoomListRsp.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSError.h>


/**
 * @brief 分页获取房间的在线列表回调
 */
@protocol VPROOMGetRoomListCb

- (void)onSuccess:(nonnull VPROOMGetRoomListRsp *)rsp;

- (void)onFailure:(nonnull DPSError *)error;

@end
/* optimized_djinni_generated_objc_file */