// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/chat/VPCHATExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 查询弹幕请求
 */
VPCHAT_OBJECTC_EXPORT
@interface VPCHATListCommentReq : NSObject
- (nonnull instancetype)initWithTopicId:(nonnull NSString *)topicId
                               sortType:(int32_t)sortType
                                pageNum:(int32_t)pageNum
                               pageSize:(int32_t)pageSize;
+ (nonnull instancetype)VPCHATListCommentReqWithTopicId:(nonnull NSString *)topicId
                                               sortType:(int32_t)sortType
                                                pageNum:(int32_t)pageNum
                                               pageSize:(int32_t)pageSize;

/**
 * @param topic_id 话题Id
 */
@property (nonatomic, nonnull) NSString * topicId;

/**
 * @param sort_type 排序方式,0-时间递增顺序，1-时间递减顺序
 */
@property (nonatomic) int32_t sortType;

/**
 * @param page_num 分页拉取的索引下标,第一次调用传1，后续调用+1
 */
@property (nonatomic) int32_t pageNum;

/**
 * @param page_size 分页拉取的大小
 */
@property (nonatomic) int32_t pageSize;

@end
/* optimized_djinni_generated_objc_file */