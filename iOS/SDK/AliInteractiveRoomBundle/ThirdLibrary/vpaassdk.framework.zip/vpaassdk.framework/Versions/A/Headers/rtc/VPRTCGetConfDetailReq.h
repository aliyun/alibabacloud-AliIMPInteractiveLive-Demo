// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/rtc/VPRTCExportDelc.h>
#import <Foundation/Foundation.h>

/**
 * @brief 获取会议详情请求
 */
VPRTC_OBJECTC_EXPORT
@interface VPRTCGetConfDetailReq : NSObject
- (nonnull instancetype)initWithConfId:(nonnull NSString *)confId;
+ (nonnull instancetype)VPRTCGetConfDetailReqWithConfId:(nonnull NSString *)confId;

/**
 * @param conf_id 会议ID
 */
@property (nonatomic, nonnull) NSString * confId;

@end
/* optimized_djinni_generated_objc_file */