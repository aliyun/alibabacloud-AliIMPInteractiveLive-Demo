// Copyright (c) 2019 The Alibaba DingTalk Authors. All rights reserved.

#import <vpaassdk/live/VPLIVEExportDelc.h>
#import <Foundation/Foundation.h>
#import <libdps/DPSModuleInfo.h>
@class VPLIVELiveExtInterface;
@class VPLIVELiveModule;
@class VPLIVELiveRpcInterface;


VPLIVE_OBJECTC_EXPORT
@interface VPLIVELiveModule : NSObject

/**
 * 静态方法
 */
+ (nullable VPLIVELiveModule *)getModule:(nonnull NSString *)uid;

+ (nullable DPSModuleInfo *)getModuleInfo;

- (nonnull NSString *)getUid;

- (nullable VPLIVELiveRpcInterface *)getRpcInterface;

- (nullable VPLIVELiveExtInterface *)getExtInterface;

@end
/* optimized_djinni_generated_objc_file */